import React from 'react';
import { useAuth } from '../../context/AuthContext';
import { useApp } from '../../context/AppContext';
import { Home, PlaySquare, Plus, MessageCircle, User } from 'lucide-react';

export const BottomNav: React.FC = () => {
  const { darkMode } = useAuth();
  const { activeTab, setActiveTab, setIsCreateModalOpen } = useApp();

  return (
    <div
      className={`md:hidden fixed bottom-0 left-0 right-0 z-40 border-t backdrop-blur-lg px-4 py-2 transition-colors duration-200 ${
        darkMode ? 'bg-[#0B0F19]/95 border-slate-800 text-white' : 'bg-white/95 border-slate-200 text-slate-900 shadow-lg'
      }`}
    >
      <div className="flex items-center justify-around max-w-md mx-auto">
        {/* Home */}
        <button
          onClick={() => setActiveTab('home')}
          className={`flex flex-col items-center gap-1 py-1 px-3 rounded-xl cursor-pointer ${
            activeTab === 'home' ? 'text-blue-500 font-bold' : 'text-slate-400'
          }`}
        >
          <Home className="w-5 h-5" />
          <span className="text-[10px]">Home</span>
        </button>

        {/* Videos / Shorts */}
        <button
          onClick={() => setActiveTab('videos')}
          className={`flex flex-col items-center gap-1 py-1 px-3 rounded-xl cursor-pointer ${
            activeTab === 'videos' ? 'text-blue-500 font-bold' : 'text-slate-400'
          }`}
        >
          <PlaySquare className="w-5 h-5" />
          <span className="text-[10px]">Shorts</span>
        </button>

        {/* Center Create Button */}
        <button
          onClick={() => setIsCreateModalOpen(true)}
          className="w-12 h-12 -mt-4 rounded-full bg-gradient-to-r from-blue-600 via-indigo-600 to-teal-400 text-white flex items-center justify-center shadow-lg shadow-blue-500/30 cursor-pointer active:scale-95 transition-transform"
        >
          <Plus className="w-6 h-6 stroke-[2.5]" />
        </button>

        {/* Messages */}
        <button
          onClick={() => setActiveTab('messages')}
          className={`flex flex-col items-center gap-1 py-1 px-3 rounded-xl cursor-pointer relative ${
            activeTab === 'messages' ? 'text-blue-500 font-bold' : 'text-slate-400'
          }`}
        >
          <MessageCircle className="w-5 h-5" />
          <span className="text-[10px]">Chats</span>
          <span className="absolute top-0 right-2 w-2 h-2 rounded-full bg-emerald-500 ring-2 ring-[#0B0F19]"></span>
        </button>

        {/* Profile */}
        <button
          onClick={() => setActiveTab('profile')}
          className={`flex flex-col items-center gap-1 py-1 px-3 rounded-xl cursor-pointer ${
            activeTab === 'profile' ? 'text-blue-500 font-bold' : 'text-slate-400'
          }`}
        >
          <User className="w-5 h-5" />
          <span className="text-[10px]">Profile</span>
        </button>
      </div>
    </div>
  );
};
