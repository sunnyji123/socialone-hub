import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useApp } from '../../context/AppContext';
import {
  Search,
  Moon,
  Sun,
  Bell,
  Plus,
  PhoneCall,
  ShieldCheck,
  LogOut,
  User,
  Check,
  ChevronDown,
  Wallet,
  Sparkles,
  Coins,
  Fuel,
} from 'lucide-react';

export const Navbar: React.FC = () => {
  const { userProfile, logout, loginAsFounder, loginAsDemoUser, darkMode, toggleDarkMode, isAdmin } = useAuth();
  const {
    activeTab,
    setActiveTab,
    searchQuery,
    setSearchQuery,
    notifications,
    markNotificationsAsRead,
    unreadNotificationsCount,
    triggerDemoIncomingCall,
    setIsCreateModalOpen,
    ownerPlatformRevenue,
    setIsCoinStoreOpen,
    setIsTikTokIdModalOpen,
    setIsCreatorCashoutOpen,
    setIsPrivacyModalOpen,
  } = useApp();

  const [showNotifications, setShowNotifications] = useState(false);
  const [showProfileMenu, setShowProfileMenu] = useState(false);

  return (
    <nav
      className={`sticky top-0 z-40 border-b backdrop-blur-md transition-colors duration-200 ${
        darkMode
          ? 'bg-[#0B0F19]/90 border-slate-800 text-white'
          : 'bg-white/95 border-slate-200 text-slate-900 shadow-xs'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-4">
        {/* Brand Logo */}
        <div
          onClick={() => setActiveTab('home')}
          className="flex items-center gap-3 cursor-pointer shrink-0 select-none group"
        >
          <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-blue-600 via-indigo-600 to-teal-400 flex items-center justify-center shadow-md shadow-blue-500/20 group-hover:scale-105 transition-transform duration-200">
            <span className="text-white font-black text-xl tracking-tighter">S1</span>
          </div>
          <div className="hidden sm:block">
            <span className="text-xl font-black tracking-tight bg-gradient-to-r from-blue-500 via-indigo-500 to-teal-400 bg-clip-text text-transparent">
              SocialOne
            </span>
            <span className="block text-[10px] text-slate-400 -mt-1 font-medium">
              Intekhab Alam — Founder & CEO
            </span>
          </div>
        </div>

        {/* Global Search Bar */}
        <div className="flex-1 max-w-md relative hidden md:block">
          <div className="relative flex items-center">
            <Search className="w-4 h-4 absolute left-3.5 text-slate-400 pointer-events-none" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => {
                setSearchQuery(e.target.value);
                if (e.target.value.trim() && activeTab !== 'explore') {
                  setActiveTab('explore');
                }
              }}
              placeholder="Search posts, shorts, creators, hashtags #..."
              className={`w-full pl-10 pr-4 py-2 rounded-full text-xs transition-all border outline-none ${
                darkMode
                  ? 'bg-slate-900/80 border-slate-800 text-white placeholder-slate-500 focus:border-blue-500 focus:bg-slate-900'
                  : 'bg-slate-100 border-slate-200 text-slate-800 placeholder-slate-400 focus:border-blue-500 focus:bg-white'
              }`}
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3 text-xs text-slate-400 hover:text-slate-200 cursor-pointer"
              >
                Clear
              </button>
            )}
          </div>
        </div>

        {/* Right Action Icons */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Founder Treasury Shortcut (Admin / Owner) */}
          {isAdmin && (
            <button
              onClick={() => setActiveTab('admin')}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-bold text-amber-300 bg-gradient-to-r from-amber-500/20 to-rose-500/20 border border-amber-500/40 hover:border-amber-400 hover:bg-amber-500/30 transition-all cursor-pointer shadow-sm active:scale-95"
              title="Founder & CEO 25% Live Revenue Treasury (JazzCash / EasyPaisa)"
            >
              <Wallet className="w-3.5 h-3.5 text-amber-400" />
              <span className="hidden sm:inline font-bold">Treasury</span>
              <span className="px-1.5 py-0.2 rounded-md bg-amber-400/20 text-[10px] text-amber-200">
                ${ownerPlatformRevenue.toFixed(0)}
              </span>
            </button>
          )}

          {/* Coins Store Shortcut (JazzCash / EasyPaisa / Card Top-up) */}
          <button
            onClick={() => setIsCoinStoreOpen(true)}
            className="flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 rounded-full text-xs font-bold text-amber-300 bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/30 transition-all cursor-pointer shadow-xs active:scale-95"
            title="SocialOne Coins Store / Sikka Kharidein (JazzCash & EasyPaisa)"
          >
            <Coins className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />
            <span className="font-mono text-white text-[11px] sm:text-xs">
              {(userProfile?.coinsBalance || 0).toLocaleString()}
            </span>
            <span className="hidden sm:inline text-[10px] text-amber-400 font-semibold">+ Buy</span>
          </button>

          {/* Create Button */}
          <button
            onClick={() => setIsCreateModalOpen(true)}
            className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-full text-xs font-semibold text-white bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 shadow-md shadow-blue-500/20 cursor-pointer transition-all active:scale-95"
            title="Create Post, Short, Story or Group"
          >
            <Plus className="w-4 h-4" />
            <span className="hidden sm:inline">Create</span>
          </button>

          {/* Test Incoming Call button */}
          <button
            onClick={triggerDemoIncomingCall}
            className={`p-2 rounded-full border text-xs flex items-center gap-1.5 transition-colors cursor-pointer ${
              darkMode
                ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-400 hover:bg-emerald-500/20'
                : 'bg-emerald-50 border-emerald-200 text-emerald-600 hover:bg-emerald-100'
            }`}
            title="Simulate WebRTC Incoming Video Call from Founder"
          >
            <PhoneCall className="w-4 h-4" />
            <span className="hidden lg:inline font-medium">Test Call</span>
          </button>

          {/* Theme Toggle */}
          <button
            onClick={toggleDarkMode}
            className={`p-2 rounded-full border cursor-pointer transition-colors ${
              darkMode
                ? 'bg-slate-900 border-slate-800 text-slate-300 hover:text-white'
                : 'bg-slate-100 border-slate-200 text-slate-600 hover:text-slate-900'
            }`}
            title={darkMode ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
          >
            {darkMode ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4" />}
          </button>

          {/* Notifications Dropdown */}
          <div className="relative">
            <button
              onClick={() => {
                setShowNotifications(!showNotifications);
                setShowProfileMenu(false);
                if (!showNotifications && unreadNotificationsCount > 0) {
                  markNotificationsAsRead();
                }
              }}
              className={`p-2 rounded-full border relative cursor-pointer transition-colors ${
                darkMode
                  ? 'bg-slate-900 border-slate-800 text-slate-300 hover:text-white'
                  : 'bg-slate-100 border-slate-200 text-slate-600 hover:text-slate-900'
              }`}
            >
              <Bell className="w-4 h-4" />
              {unreadNotificationsCount > 0 && (
                <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-rose-500 text-white text-[10px] font-bold flex items-center justify-center animate-pulse">
                  {unreadNotificationsCount}
                </span>
              )}
            </button>

            {/* Notifications Menu */}
            {showNotifications && (
              <div
                className={`absolute right-0 mt-2 w-80 sm:w-96 rounded-2xl border shadow-2xl p-4 z-50 ${
                  darkMode ? 'bg-slate-900 border-slate-800 text-white' : 'bg-white border-slate-200 text-slate-900'
                }`}
              >
                <div className="flex items-center justify-between pb-3 border-b border-slate-800/40">
                  <div className="font-bold text-sm">Notifications</div>
                  <button
                    onClick={markNotificationsAsRead}
                    className="text-xs text-blue-500 hover:underline flex items-center gap-1 cursor-pointer"
                  >
                    <Check className="w-3.5 h-3.5" />
                    Mark all read
                  </button>
                </div>

                <div className="divide-y divide-slate-800/20 max-h-80 overflow-y-auto mt-2">
                  {notifications.map((notif) => (
                    <div key={notif.id} className="py-2.5 flex items-start gap-3 text-xs">
                      <img
                        src={notif.senderPhoto}
                        alt={notif.senderName}
                        className="w-8 h-8 rounded-full object-cover shrink-0"
                      />
                      <div className="flex-1">
                        <p>
                          <strong className="font-semibold">{notif.senderName}</strong>{' '}
                          {notif.message}
                        </p>
                        <span className="text-[10px] text-slate-400 mt-0.5 block">
                          {new Date(notif.createdAt).toLocaleTimeString([], {
                            hour: '2-digit',
                            minute: '2-digit',
                          })}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* User Profile Menu */}
          <div className="relative">
            <button
              onClick={() => {
                setShowProfileMenu(!showProfileMenu);
                setShowNotifications(false);
              }}
              className="flex items-center gap-2 p-1 pl-1.5 rounded-full border border-transparent hover:border-slate-700 cursor-pointer transition-all"
            >
              <img
                src={userProfile?.photoURL || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&auto=format&fit=crop&q=80'}
                alt={userProfile?.displayName || 'User'}
                className="w-8 h-8 rounded-full object-cover ring-2 ring-blue-500/30"
              />
              <ChevronDown className="w-3.5 h-3.5 text-slate-400 hidden sm:block" />
            </button>

            {showProfileMenu && (
              <div
                className={`absolute right-0 mt-2 w-56 rounded-2xl border shadow-2xl p-2 z-50 ${
                  darkMode ? 'bg-slate-900 border-slate-800 text-white' : 'bg-white border-slate-200 text-slate-900'
                }`}
              >
                <div className="px-3 py-2 border-b border-slate-800/40 mb-1">
                  <p className="font-bold text-xs truncate">{userProfile?.displayName}</p>
                  <p className="text-[11px] text-slate-400 truncate">@{userProfile?.username}</p>
                  {isAdmin && (
                    <span className="inline-flex items-center gap-1 mt-1 text-[10px] font-semibold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-full">
                      <ShieldCheck className="w-3 h-3" />
                      Administrator
                    </span>
                  )}
                </div>

                <button
                  onClick={() => {
                    setActiveTab('profile');
                    setShowProfileMenu(false);
                  }}
                  className="w-full text-left px-3 py-2 rounded-xl text-xs hover:bg-slate-800/40 flex items-center gap-2 cursor-pointer"
                >
                  <User className="w-4 h-4 text-slate-400" />
                  My Profile & Settings
                </button>

                <button
                  onClick={() => {
                    setIsTikTokIdModalOpen(true);
                    setShowProfileMenu(false);
                  }}
                  className="w-full text-left px-3 py-2 rounded-xl text-xs hover:bg-slate-800/40 flex items-center gap-2 text-rose-400 font-semibold cursor-pointer"
                >
                  <Sparkles className="w-4 h-4 text-rose-400" />
                  Create / Switch TikTok ID
                </button>

                <button
                  onClick={() => {
                    setIsCoinStoreOpen(true);
                    setShowProfileMenu(false);
                  }}
                  className="w-full text-left px-3 py-2 rounded-xl text-xs hover:bg-slate-800/40 flex items-center gap-2 text-amber-300 font-semibold cursor-pointer"
                >
                  <Coins className="w-4 h-4 text-amber-400 fill-amber-400" />
                  Coins Store (Sikka Kharidein)
                </button>

                <button
                  onClick={() => {
                    setIsCreatorCashoutOpen(true);
                    setShowProfileMenu(false);
                  }}
                  className="w-full text-left px-3 py-2 rounded-xl text-xs hover:bg-slate-800/40 flex items-center gap-2 text-emerald-400 font-semibold cursor-pointer"
                >
                  <Fuel className="w-4 h-4 text-emerald-400" />
                  Creator Payout (Petrol Lena)
                </button>

                <button
                  onClick={() => {
                    setIsPrivacyModalOpen(true);
                    setShowProfileMenu(false);
                  }}
                  className="w-full text-left px-3 py-2 rounded-xl text-xs hover:bg-slate-800/40 flex items-center gap-2 text-teal-400 font-semibold cursor-pointer"
                >
                  <ShieldCheck className="w-4 h-4 text-teal-400" />
                  Privacy Settings (WhatsApp & TikTok)
                </button>

                {isAdmin ? (
                  <>
                    <button
                      onClick={() => {
                        setActiveTab('admin');
                        setShowProfileMenu(false);
                      }}
                      className="w-full text-left px-3 py-2 rounded-xl text-xs hover:bg-slate-800/40 flex items-center gap-2 text-indigo-400 font-medium cursor-pointer"
                    >
                      <ShieldCheck className="w-4 h-4" />
                      Admin Control & Treasury
                    </button>
                    <button
                      onClick={async () => {
                        await loginAsDemoUser();
                        setShowProfileMenu(false);
                      }}
                      className="w-full text-left px-3 py-2 rounded-xl text-xs hover:bg-slate-800/40 flex items-center gap-2 text-slate-400 hover:text-white cursor-pointer"
                    >
                      <Sparkles className="w-4 h-4 text-teal-400" />
                      Switch to Demo Creator View
                    </button>
                  </>
                ) : (
                  <button
                    onClick={async () => {
                      await loginAsFounder();
                      setShowProfileMenu(false);
                    }}
                    className="w-full text-left px-3 py-2 rounded-xl text-xs bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 font-bold flex items-center gap-2 cursor-pointer border border-amber-500/30"
                  >
                    <ShieldCheck className="w-4 h-4 text-amber-400" />
                    Switch to Founder Intekhab Alam
                  </button>
                )}

                <div className="border-t border-slate-800/40 mt-1 pt-1">
                  <button
                    onClick={async () => {
                      setShowProfileMenu(false);
                      await logout();
                    }}
                    className="w-full text-left px-3 py-2 rounded-xl text-xs text-rose-400 hover:bg-rose-500/10 flex items-center gap-2 cursor-pointer font-medium"
                  >
                    <LogOut className="w-4 h-4" />
                    Sign Out
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
};
