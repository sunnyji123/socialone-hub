import React from 'react';
import { useAuth } from '../../context/AuthContext';
import { useApp } from '../../context/AppContext';
import {
  Home,
  PlaySquare,
  Flame,
  MessageCircle,
  Users,
  Compass,
  ShieldCheck,
  User,
  PlusCircle,
  Sparkles,
} from 'lucide-react';

export const Sidebar: React.FC = () => {
  const { userProfile, isAdmin, darkMode } = useAuth();
  const { activeTab, setActiveTab, setIsCreateModalOpen } = useApp();

  const navItems = [
    { id: 'home', label: 'Home Feed', icon: Home, badge: null },
    { id: 'videos', label: 'Shorts & Reels', icon: PlaySquare, badge: 'Viral' },
    { id: 'stories', label: 'Stories & Photos', icon: Flame, badge: null },
    { id: 'messages', label: 'Chats & Calls', icon: MessageCircle, badge: 'Live' },
    { id: 'groups', label: 'Communities', icon: Users, badge: null },
    { id: 'explore', label: 'Explore & Search', icon: Compass, badge: null },
    { id: 'profile', label: 'My Profile', icon: User, badge: null },
  ];

  return (
    <aside
      className={`hidden md:flex flex-col w-64 lg:w-72 shrink-0 p-4 border-r min-h-[calc(100vh-4rem)] transition-colors duration-200 select-none ${
        darkMode ? 'bg-[#0B0F19]/50 border-slate-800/80' : 'bg-slate-50/50 border-slate-200'
      }`}
    >
      {/* Navigation links */}
      <div className="space-y-1.5 flex-1">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id as any)}
              className={`w-full flex items-center justify-between px-4 py-3 rounded-2xl text-sm font-semibold transition-all cursor-pointer group ${
                isActive
                  ? 'bg-gradient-to-r from-blue-600/15 via-indigo-600/10 to-teal-500/10 text-blue-500 font-bold border border-blue-500/20 shadow-xs'
                  : darkMode
                  ? 'text-slate-400 hover:text-white hover:bg-slate-900/60'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              <div className="flex items-center gap-3.5">
                <Icon
                  className={`w-5 h-5 transition-transform group-hover:scale-110 ${
                    isActive ? 'text-blue-500 fill-blue-500/10' : 'text-slate-400'
                  }`}
                />
                <span>{item.label}</span>
              </div>

              {item.badge && (
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-gradient-to-r from-rose-500 to-amber-500 text-white shadow-xs">
                  {item.badge}
                </span>
              )}
            </button>
          );
        })}

        {/* Admin Link if authorized */}
        {isAdmin && (
          <button
            onClick={() => setActiveTab('admin')}
            className={`w-full flex items-center justify-between px-4 py-3 rounded-2xl text-sm font-semibold transition-all cursor-pointer group mt-2 ${
              activeTab === 'admin'
                ? 'bg-indigo-500/20 text-indigo-400 border border-indigo-500/30 font-bold'
                : darkMode
                ? 'text-indigo-400/80 hover:text-indigo-300 hover:bg-indigo-500/10'
                : 'text-indigo-600 hover:bg-indigo-50'
            }`}
          >
            <div className="flex items-center gap-3.5">
              <ShieldCheck className="w-5 h-5 text-indigo-400 group-hover:scale-110 transition-transform" />
              <span>Admin Center</span>
            </div>
            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-indigo-500/20 text-indigo-400 border border-indigo-500/30">
              CEO
            </span>
          </button>
        )}

        {/* Quick Post Creator CTA */}
        <div className="pt-4">
          <button
            onClick={() => setIsCreateModalOpen(true)}
            className="w-full py-3 px-4 rounded-2xl font-bold text-sm text-white bg-gradient-to-r from-blue-600 via-indigo-600 to-teal-500 hover:opacity-95 shadow-lg shadow-blue-500/20 flex items-center justify-center gap-2 cursor-pointer transition-all active:scale-[0.98]"
          >
            <PlusCircle className="w-5 h-5" />
            <span>Create New Content</span>
          </button>
        </div>
      </div>

      {/* Founder Recognition & Platform Card */}
      <div
        className={`p-4 rounded-2xl border text-xs space-y-2 mt-4 ${
          darkMode
            ? 'bg-gradient-to-br from-slate-900 to-slate-900/60 border-slate-800'
            : 'bg-white border-slate-200 shadow-xs'
        }`}
      >
        <div className="flex items-center gap-2 text-indigo-400 font-semibold">
          <Sparkles className="w-4 h-4" />
          <span>Platform Founder</span>
        </div>
        <div className="flex items-center gap-2.5 pt-1">
          <img
            src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&auto=format&fit=crop&q=80"
            alt="Intekhab Alam"
            className="w-9 h-9 rounded-full object-cover ring-2 ring-indigo-500/40"
          />
          <div>
            <p className="font-bold text-xs">Intekhab Alam</p>
            <p className="text-[10px] text-slate-400">Founder & CEO, SocialOne</p>
          </div>
        </div>
        <p className="text-[11px] text-slate-400 leading-relaxed pt-1">
          Uniting TikTok video energy, Facebook communities, Instagram visuals & WhatsApp conversations.
        </p>
      </div>
    </aside>
  );
};
