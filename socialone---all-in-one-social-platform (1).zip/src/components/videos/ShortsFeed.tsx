import React, { useState, useRef, useEffect, useCallback } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useApp } from '../../context/AppContext';
import {
  Heart,
  MessageCircle,
  Share2,
  Volume2,
  VolumeX,
  Play,
  Pause,
  Music,
  Plus,
  Check,
  Camera,
  FolderOpen,
  X,
  Sparkles,
  Send,
  Radio,
  Users,
  ChevronUp,
  ChevronDown,
  AlertCircle,
  CheckCircle2,
} from 'lucide-react';
import confetti from 'canvas-confetti';

export const ShortsFeed: React.FC = () => {
  const { userProfile, toggleFollowUser, darkMode, isAdmin, gainFollowers } = useAuth();
  const {
    videos,
    toggleLikeVideo,
    incrementVideoView,
    setIsCreateModalOpen,
    setIsTikTokStudioOpen,
    liveStreams,
    setActiveLiveStream,
    setIsLiveModalOpen,
    setIsLiveHostMode,
    startLiveStream,
  } = useApp();

  const [currentIndex, setCurrentIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(true);
  const [isMuted, setIsMuted] = useState(true);
  const [showComments, setShowComments] = useState(false);
  const [commentsList, setCommentsList] = useState<{ [id: string]: { user: string; text: string }[] }>({
    'video-1': [
      { user: 'Elena Vance', text: 'Love this all-in-one vision! Super clean execution.' },
      { user: 'Marcus Chen', text: 'The video feed is buttery smooth!' },
    ],
  });
  const [newComment, setNewComment] = useState('');
  const [copied, setCopied] = useState(false);
  const [showFollowerRequirementModal, setShowFollowerRequirementModal] = useState(false);
  const [boostedNotice, setBoostedNotice] = useState(false);

  // Touch gesture & wheel scroll trackers
  const touchStartY = useRef<number | null>(null);
  const touchEndY = useRef<number | null>(null);
  const isScrollingRef = useRef(false);
  const videoRefs = useRef<{ [index: number]: HTMLVideoElement | null }>({});

  const currentVideo = videos[currentIndex] || videos[0];
  const followersCount = userProfile?.followersCount || 1;
  const isEligibleForLive = followersCount >= 100 || isAdmin;

  // Video playback management
  useEffect(() => {
    Object.entries(videoRefs.current).forEach(([idxStr, vid]) => {
      const idx = Number(idxStr);
      if (vid) {
        if (idx === currentIndex) {
          vid.currentTime = 0;
          vid.play().catch(() => {});
          if (currentVideo?.id) {
            incrementVideoView(currentVideo.id);
          }
        } else {
          vid.pause();
        }
      }
    });
    setIsPlaying(true);
  }, [currentIndex, currentVideo?.id, incrementVideoView]);

  // Next / Prev video navigation handlers
  const handleNextVideo = useCallback(() => {
    if (currentIndex < videos.length - 1) {
      setCurrentIndex((prev) => prev + 1);
    }
  }, [currentIndex, videos.length]);

  const handlePrevVideo = useCallback(() => {
    if (currentIndex > 0) {
      setCurrentIndex((prev) => prev - 1);
    }
  }, [currentIndex]);

  // Touch swipe gesture handlers (TikTok mobile style)
  const handleTouchStart = (e: React.TouchEvent) => {
    touchStartY.current = e.touches[0].clientY;
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    touchEndY.current = e.touches[0].clientY;
  };

  const handleTouchEnd = () => {
    if (touchStartY.current !== null && touchEndY.current !== null) {
      const diffY = touchStartY.current - touchEndY.current;
      const minSwipeDistance = 45;
      if (diffY > minSwipeDistance) {
        // Swiped UP -> Next video
        handleNextVideo();
      } else if (diffY < -minSwipeDistance) {
        // Swiped DOWN -> Prev video
        handlePrevVideo();
      }
    }
    touchStartY.current = null;
    touchEndY.current = null;
  };

  // Wheel scroll with throttle (TikTok desktop web style)
  const handleWheel = (e: React.WheelEvent) => {
    if (isScrollingRef.current) return;
    if (Math.abs(e.deltaY) < 25) return;

    isScrollingRef.current = true;
    if (e.deltaY > 0) {
      handleNextVideo();
    } else {
      handlePrevVideo();
    }

    setTimeout(() => {
      isScrollingRef.current = false;
    }, 450);
  };

  // Keyboard navigation (Arrow keys)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'ArrowDown') {
        e.preventDefault();
        handleNextVideo();
      } else if (e.key === 'ArrowUp') {
        e.preventDefault();
        handlePrevVideo();
      } else if (e.key === ' ') {
        e.preventDefault();
        togglePlay();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [handleNextVideo, handlePrevVideo]);

  const togglePlay = () => {
    const vid = videoRefs.current[currentIndex];
    if (!vid) return;
    if (isPlaying) {
      vid.pause();
      setIsPlaying(false);
    } else {
      vid.play().catch(() => {});
      setIsPlaying(true);
    }
  };

  const handleLike = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!currentVideo) return;
    toggleLikeVideo(currentVideo.id);
    confetti({
      particleCount: 30,
      spread: 60,
      origin: { y: 0.7 },
    });
  };

  const handleShare = (e: React.MouseEvent) => {
    e.stopPropagation();
    navigator.clipboard?.writeText(window.location.origin + `?video=${currentVideo?.id}`);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleAddComment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newComment.trim() || !currentVideo) return;
    setCommentsList((prev) => ({
      ...prev,
      [currentVideo.id]: [
        ...(prev[currentVideo.id] || []),
        { user: userProfile?.displayName || 'You', text: newComment.trim() },
      ],
    }));
    setNewComment('');
  };

  const handleGoLiveClick = async () => {
    if (isEligibleForLive) {
      await startLiveStream(`${userProfile?.displayName || 'Creator'}'s TikTok Live 🔴`);
    } else {
      setShowFollowerRequirementModal(true);
    }
  };

  const handleBoostFollowers = async () => {
    await gainFollowers(25);
    setBoostedNotice(true);
    setTimeout(() => setBoostedNotice(false), 2000);
  };

  if (!currentVideo) {
    return (
      <div className="flex flex-col items-center justify-center p-12 text-center">
        <p className="text-base font-bold">No Short Videos yet</p>
        <button
          onClick={() => setIsCreateModalOpen(true)}
          className="mt-4 px-6 py-2.5 rounded-full bg-blue-600 text-white text-xs font-bold"
        >
          Upload First Short
        </button>
      </div>
    );
  }

  const isLiked = currentVideo.likedBy?.includes(userProfile?.uid || '');
  const isFollowing = userProfile?.followingIds?.includes(currentVideo.creatorId);

  return (
    <div
      onWheel={handleWheel}
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
      className="max-w-md mx-auto w-full h-[calc(100vh-6.5rem)] flex flex-col items-center justify-center relative select-none pb-12 sm:pb-4"
    >
      {/* 100 Follower Requirement Modal */}
      {showFollowerRequirementModal && (
        <div className="absolute inset-0 z-50 bg-black/85 backdrop-blur-md rounded-3xl flex items-center justify-center p-6 text-white text-center">
          <div className="space-y-4 max-w-sm">
            <div className="w-16 h-16 rounded-full bg-rose-500/20 text-rose-500 mx-auto flex items-center justify-center">
              <Radio className="w-8 h-8 animate-pulse" />
            </div>

            <h3 className="text-lg font-black tracking-tight">TikTok Live Requires 100 Followers</h3>

            <p className="text-xs text-slate-300 leading-relaxed">
              To host a Live Stream and earn money with 75% Creator / 25% Owner (Intekhab Alam) gifting, you must have at least <strong className="text-rose-400">100 Followers</strong>.
            </p>

            <div className="bg-slate-900/80 p-3.5 rounded-2xl border border-slate-800 space-y-2">
              <div className="flex justify-between text-xs font-bold">
                <span className="text-slate-400">Your Followers:</span>
                <span className="text-rose-400">{followersCount} / 100</span>
              </div>
              <div className="w-full h-2 rounded-full bg-slate-800 overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-rose-500 to-indigo-500 rounded-full transition-all duration-300"
                  style={{ width: `${Math.min(100, (followersCount / 100) * 100)}%` }}
                />
              </div>
            </div>

            <div className="flex flex-col gap-2 pt-1">
              <button
                onClick={handleBoostFollowers}
                className="w-full py-2.5 rounded-2xl bg-gradient-to-r from-rose-600 to-indigo-600 hover:from-rose-500 hover:to-indigo-500 text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-lg cursor-pointer"
              >
                <Sparkles className="w-4 h-4" />
                <span>Boost Followers (+25)</span>
              </button>

              {boostedNotice && (
                <p className="text-xs text-emerald-400 font-bold flex items-center justify-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  Added 25 Followers! ({followersCount} total)
                </p>
              )}

              <button
                onClick={() => setShowFollowerRequirementModal(false)}
                className="w-full py-2 rounded-2xl bg-slate-800 text-slate-300 font-semibold text-xs cursor-pointer"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Top Header Floating Overlay */}
      <div className="absolute top-2 left-3 right-3 z-30 flex flex-col gap-1.5 text-white drop-shadow">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-1.5">
            <span className="font-black text-sm tracking-tight bg-gradient-to-r from-blue-400 via-indigo-300 to-teal-300 bg-clip-text text-transparent">
              SocialOne Shorts
            </span>
          </div>

          <div className="flex items-center gap-1.5">
            {/* Go LIVE Button (100 followers check) */}
            <button
              onClick={handleGoLiveClick}
              className={`px-3 py-1 rounded-full text-xs font-black flex items-center gap-1.5 shadow-lg active:scale-95 transition-all cursor-pointer ${
                isEligibleForLive
                  ? 'bg-gradient-to-r from-rose-600 to-red-600 text-white animate-pulse'
                  : 'bg-black/60 border border-rose-500/40 text-rose-300'
              }`}
              title={isEligibleForLive ? 'Broadcast Live (100+ Followers Unlocked!)' : 'Requires 100 Followers to Go LIVE'}
            >
              <Radio className="w-3.5 h-3.5" />
              <span>{isEligibleForLive ? 'Go LIVE 🔴' : `Go LIVE (${followersCount}/100)`}</span>
            </button>

            {/* Record Studio Button */}
            <button
              onClick={() => setIsTikTokStudioOpen(true)}
              className="px-2.5 py-1 rounded-full text-xs font-bold bg-white/20 hover:bg-white/30 backdrop-blur-md text-white flex items-center gap-1 cursor-pointer shadow-md active:scale-95 transition-all"
              title="Open Camera Studio (18+ Filters & Sounds)"
            >
              <Camera className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Record</span>
            </button>

            {/* Gallery Upload Button */}
            <button
              onClick={() => setIsCreateModalOpen(true)}
              className="px-2.5 py-1 rounded-full text-xs font-bold bg-white/20 hover:bg-white/30 backdrop-blur-md text-white flex items-center gap-1 cursor-pointer shadow-md active:scale-95 transition-all"
              title="Upload from Phone/PC Gallery"
            >
              <FolderOpen className="w-3.5 h-3.5 text-teal-300" />
              <span className="hidden sm:inline">Gallery</span>
            </button>
          </div>
        </div>

        {/* Watch Active LIVEs Ticker Bar */}
        {liveStreams.length > 0 && (
          <div className="flex items-center gap-2 overflow-x-auto scrollbar-none py-1">
            <span className="text-[10px] font-black uppercase text-rose-400 flex items-center gap-1 shrink-0">
              <span className="w-1.5 h-1.5 rounded-full bg-rose-500 animate-ping" />
              Watch LIVE:
            </span>
            {liveStreams.map((stream) => (
              <button
                key={stream.id}
                onClick={() => {
                  setActiveLiveStream(stream);
                  setIsLiveHostMode(false);
                  setIsLiveModalOpen(true);
                }}
                className="flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-black/60 hover:bg-rose-950/60 border border-rose-500/50 backdrop-blur-md text-[10px] font-bold text-white shrink-0 cursor-pointer shadow-sm transition-all"
              >
                <img
                  src={stream.hostPhoto}
                  alt={stream.hostName}
                  className="w-4 h-4 rounded-full object-cover ring-1 ring-rose-500"
                />
                <span className="truncate max-w-[90px]">{stream.hostName}</span>
                <span className="text-rose-400">({stream.viewersCount})</span>
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Main Video Reel Card with Vertical Scroll / Swipe Indicator */}
      <div
        onClick={togglePlay}
        className="relative w-full h-full max-h-[820px] rounded-3xl overflow-hidden bg-black shadow-2xl flex items-center justify-center cursor-pointer group"
      >
        {(() => {
          const isImageMedia =
            currentVideo.videoUrl?.match(/\.(jpeg|jpg|gif|png|webp)($|\?)/i) ||
            currentVideo.videoUrl?.startsWith('data:image/') ||
            (currentVideo as any).mediaType === 'image';

          if (isImageMedia) {
            return (
              <div className="relative w-full h-full flex items-center justify-center overflow-hidden bg-slate-950">
                <img
                  src={currentVideo.videoUrl}
                  alt={currentVideo.caption}
                  className="w-full h-full object-cover transition-transform duration-1000 ease-out transform scale-105"
                />
                <div className="absolute top-16 left-4 z-20 px-2.5 py-1 rounded-full bg-black/60 backdrop-blur-md text-[10px] font-bold text-teal-300 border border-teal-500/30 flex items-center gap-1">
                  <Sparkles className="w-3 h-3" />
                  <span>TikTok Photo Reel</span>
                </div>
              </div>
            );
          }

          return (
            <video
              ref={(el) => {
                videoRefs.current[currentIndex] = el;
              }}
              src={currentVideo.videoUrl}
              loop
              playsInline
              muted={isMuted}
              className="w-full h-full object-cover transition-opacity duration-300"
            />
          );
        })()}

        {/* Center Pause/Play Flash */}
        {!isPlaying && (
          <div className="absolute inset-0 flex items-center justify-center bg-black/30 pointer-events-none">
            <div className="p-4 rounded-full bg-black/60 text-white backdrop-blur-md animate-scale-up">
              <Play className="w-10 h-10 fill-current ml-1" />
            </div>
          </div>
        )}

        {/* Mute/Unmute Floating Button */}
        <button
          onClick={(e) => {
            e.stopPropagation();
            setIsMuted(!isMuted);
          }}
          className="absolute top-20 right-4 z-30 p-2.5 rounded-full bg-black/40 hover:bg-black/60 text-white backdrop-blur-md cursor-pointer transition-colors"
        >
          {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
        </button>

        {/* Next / Prev Video Arrows (TikTok Scroll helper) */}
        <div className="absolute left-3 top-1/2 -translate-y-1/2 z-30 flex flex-col gap-2">
          {currentIndex > 0 && (
            <button
              onClick={(e) => {
                e.stopPropagation();
                handlePrevVideo();
              }}
              className="p-2 rounded-full bg-black/50 hover:bg-black/80 text-white backdrop-blur-md cursor-pointer transition-all hover:scale-110"
              title="Previous Video (Swipe Down / Arrow Up)"
            >
              <ChevronUp className="w-4 h-4" />
            </button>
          )}
          {currentIndex < videos.length - 1 && (
            <button
              onClick={(e) => {
                e.stopPropagation();
                handleNextVideo();
              }}
              className="p-2 rounded-full bg-black/50 hover:bg-black/80 text-white backdrop-blur-md cursor-pointer transition-all hover:scale-110"
              title="Next Video (Swipe Up / Arrow Down)"
            >
              <ChevronDown className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Floating Right Interaction Bar */}
        <div className="absolute right-3 bottom-16 z-30 flex flex-col items-center gap-4">
          {/* Creator Avatar with Follow Button */}
          <div className="relative flex flex-col items-center">
            <img
              src={currentVideo.creatorPhoto}
              alt={currentVideo.creatorName}
              className="w-11 h-11 rounded-full object-cover ring-2 ring-white/80 shadow-md"
            />
            {currentVideo.creatorId !== userProfile?.uid && !isFollowing && (
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  toggleFollowUser(currentVideo.creatorId);
                }}
                className="absolute -bottom-2 w-5 h-5 rounded-full bg-rose-500 hover:bg-rose-400 text-white flex items-center justify-center shadow-lg ring-2 ring-black cursor-pointer"
                title="Follow Creator"
              >
                <Plus className="w-3.5 h-3.5 stroke-[3]" />
              </button>
            )}
          </div>

          {/* Like Button */}
          <button
            onClick={handleLike}
            className="flex flex-col items-center gap-1 text-white cursor-pointer group/btn"
          >
            <div
              className={`p-3 rounded-full backdrop-blur-md transition-all ${
                isLiked ? 'bg-rose-500/20 text-rose-500' : 'bg-black/40 group-hover/btn:bg-black/60'
              }`}
            >
              <Heart className={`w-6 h-6 ${isLiked ? 'fill-rose-500 text-rose-500' : ''}`} />
            </div>
            <span className="text-[11px] font-bold drop-shadow">{currentVideo.likesCount}</span>
          </button>

          {/* Comment Button */}
          <button
            onClick={(e) => {
              e.stopPropagation();
              setShowComments(true);
            }}
            className="flex flex-col items-center gap-1 text-white cursor-pointer group/btn"
          >
            <div className="p-3 rounded-full bg-black/40 group-hover/btn:bg-black/60 backdrop-blur-md transition-all">
              <MessageCircle className="w-6 h-6" />
            </div>
            <span className="text-[11px] font-bold drop-shadow">
              {(commentsList[currentVideo.id] || []).length + currentVideo.commentsCount}
            </span>
          </button>

          {/* Share Button */}
          <button
            onClick={handleShare}
            className="flex flex-col items-center gap-1 text-white cursor-pointer group/btn"
          >
            <div className="p-3 rounded-full bg-black/40 group-hover/btn:bg-black/60 backdrop-blur-md transition-all">
              {copied ? <Check className="w-6 h-6 text-emerald-400" /> : <Share2 className="w-6 h-6" />}
            </div>
            <span className="text-[11px] font-bold drop-shadow">
              {copied ? 'Copied' : currentVideo.sharesCount}
            </span>
          </button>

          {/* Spinning Vinyl Record for Music */}
          <div className="w-9 h-9 rounded-full p-1 bg-black/60 ring-2 ring-white/20 flex items-center justify-center animate-spin [animation-duration:5s] shadow-lg">
            <div className="w-full h-full rounded-full bg-gradient-to-tr from-blue-500 via-indigo-500 to-teal-400 flex items-center justify-center">
              <Music className="w-3.5 h-3.5 text-white" />
            </div>
          </div>
        </div>

        {/* Floating Bottom Creator & Caption Info */}
        <div className="absolute bottom-4 left-4 right-20 z-30 text-white drop-shadow space-y-1.5">
          <div className="flex items-center gap-2">
            <span className="font-bold text-sm tracking-wide">@{currentVideo.creatorUsername}</span>
            {currentVideo.creatorId === 'intekhab-alam-founder' && (
              <span className="inline-flex items-center gap-1 text-[9px] font-bold text-white bg-blue-600 px-2 py-0.5 rounded-full">
                <Sparkles className="w-2.5 h-2.5" />
                Founder
              </span>
            )}
          </div>

          <p className="text-xs text-white/95 line-clamp-2 leading-relaxed font-normal">
            {currentVideo.caption}
          </p>

          <div className="flex items-center gap-2 text-[11px] text-white/80 pt-0.5">
            <Music className="w-3.5 h-3.5 shrink-0" />
            <span className="truncate">
              {currentVideo.musicTitle} • {currentVideo.musicArtist}
            </span>
          </div>
        </div>

        {/* Video progress line */}
        <div className="absolute bottom-0 left-0 right-0 h-1 bg-white/20">
          <div className="h-full bg-blue-500 w-full" />
        </div>
      </div>

      {/* Sliding Comments Drawer */}
      {showComments && (
        <div
          onClick={(e) => e.stopPropagation()}
          className={`absolute bottom-0 left-0 right-0 max-h-[60%] rounded-t-3xl border-t z-40 p-4 flex flex-col shadow-2xl backdrop-blur-xl ${
            darkMode ? 'bg-slate-900/95 border-slate-800 text-white' : 'bg-white/95 border-slate-200 text-slate-900'
          }`}
        >
          <div className="flex items-center justify-between pb-3 border-b border-slate-800/40">
            <h4 className="font-bold text-xs">Comments</h4>
            <button
              onClick={() => setShowComments(false)}
              className="p-1 rounded-full text-slate-400 hover:text-white cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <div className="flex-1 overflow-y-auto py-3 space-y-2.5">
            {(commentsList[currentVideo.id] || []).map((comm, idx) => (
              <div key={idx} className="text-xs flex items-start gap-2">
                <div className="w-6 h-6 rounded-full bg-blue-500/20 text-blue-400 font-bold flex items-center justify-center shrink-0 text-[10px]">
                  {comm.user.charAt(0)}
                </div>
                <div>
                  <span className="font-bold text-slate-300">{comm.user}</span>
                  <p className="text-slate-400 mt-0.5">{comm.text}</p>
                </div>
              </div>
            ))}
          </div>

          <form onSubmit={handleAddComment} className="flex items-center gap-2 pt-2 border-t border-slate-800/40">
            <input
              type="text"
              value={newComment}
              onChange={(e) => setNewComment(e.target.value)}
              placeholder="Add a comment on this short..."
              className={`flex-1 px-4 py-2 rounded-full text-xs outline-none border ${
                darkMode ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-100 border-slate-300 text-slate-900'
              }`}
            />
            <button
              type="submit"
              className="p-2 rounded-full bg-blue-600 hover:bg-blue-500 text-white cursor-pointer shadow-sm"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
        </div>
      )}
    </div>
  );
};
