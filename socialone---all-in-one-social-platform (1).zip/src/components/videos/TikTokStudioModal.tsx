import React, { useState, useRef, useEffect, useCallback } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useApp } from '../../context/AppContext';
import {
  X,
  Camera,
  RefreshCw,
  Sparkles,
  Music,
  Timer,
  RotateCcw,
  Check,
  Film,
  Zap,
  AlertCircle,
  Play,
  Pause,
  Volume2,
  VolumeX,
  Sliders,
  Type,
  Palette,
  Layers,
  Flame,
  CheckCircle2,
  FolderPlus,
  Headphones,
  Upload,
} from 'lucide-react';
import { SOUND_TRACKS, soundEngine, SoundTrack } from '../../lib/soundPlayer';

export interface TikTokFilter {
  id: string;
  name: string;
  category: 'beauty' | 'vibe' | 'greenscreen' | 'fx';
  css: string;
  color: string;
  bgUrl?: string;
  overlayType?: 'sparkles' | 'vhs' | 'glitch';
}

const FILTERS: TikTokFilter[] = [
  { id: 'normal', name: 'Normal', category: 'vibe', css: 'none', color: '#94A3B8' },
  // Beauty
  {
    id: 'beauty-glow',
    name: 'Beauty Glow',
    category: 'beauty',
    css: 'contrast(106%) brightness(116%) saturate(112%) blur(0.2px)',
    color: '#FB7185',
  },
  {
    id: 'porcelain',
    name: 'Porcelain Skin',
    category: 'beauty',
    css: 'contrast(102%) brightness(118%) saturate(106%) blur(0.35px)',
    color: '#F472B6',
  },
  {
    id: 'caramel',
    name: 'Caramel Tan',
    category: 'beauty',
    css: 'sepia(0.3) saturate(1.4) contrast(1.1) brightness(1.08) hue-rotate(-15deg)',
    color: '#F59E0B',
  },
  {
    id: 'natural-glam',
    name: 'Natural Glam',
    category: 'beauty',
    css: 'contrast(108%) brightness(110%) saturate(115%)',
    color: '#EC4899',
  },
  // Vibe / Aesthetic
  {
    id: 'vhs-1990',
    name: 'Vintage VHS 90s',
    category: 'vibe',
    css: 'sepia(0.4) contrast(1.25) brightness(0.95) saturate(1.2)',
    color: '#EAB308',
    overlayType: 'vhs',
  },
  {
    id: 'cyber-neon',
    name: 'Cyberpunk Neon',
    category: 'vibe',
    css: 'hue-rotate(285deg) contrast(1.45) saturate(1.75) brightness(1.05)',
    color: '#A855F7',
  },
  {
    id: 'golden-hour',
    name: 'Golden Hour Sun',
    category: 'vibe',
    css: 'sepia(0.5) saturate(1.8) contrast(1.18) hue-rotate(345deg)',
    color: '#F97316',
  },
  {
    id: 'tokyo-night',
    name: 'Tokyo Midnight',
    category: 'vibe',
    css: 'hue-rotate(185deg) contrast(1.35) saturate(1.3) brightness(0.92)',
    color: '#3B82F6',
  },
  {
    id: 'anime-pop',
    name: 'Anime Pop Cel',
    category: 'vibe',
    css: 'saturate(2.2) contrast(1.35) brightness(1.1)',
    color: '#06B6D4',
  },
  {
    id: 'noir-film',
    name: 'Dramatic B&W Noir',
    category: 'vibe',
    css: 'grayscale(1) contrast(1.6) brightness(0.92)',
    color: '#64748B',
  },
  // Green Screen Presets
  {
    id: 'gs-studio',
    name: 'Studio Penthouse',
    category: 'greenscreen',
    css: 'contrast(1.05) brightness(1.05)',
    color: '#10B981',
    bgUrl: 'https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?w=1200&auto=format&fit=crop&q=80',
  },
  {
    id: 'gs-cyber',
    name: 'Neon Cyber City',
    category: 'greenscreen',
    css: 'hue-rotate(20deg) contrast(1.2)',
    color: '#8B5CF6',
    bgUrl: 'https://images.unsplash.com/photo-1508739773434-c26b3d09e071?w=1200&auto=format&fit=crop&q=80',
  },
  {
    id: 'gs-beach',
    name: 'Tropical Sunset',
    category: 'greenscreen',
    css: 'sepia(0.2) saturate(1.3)',
    color: '#F59E0B',
    bgUrl: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=1200&auto=format&fit=crop&q=80',
  },
  {
    id: 'gs-space',
    name: 'Deep Cosmos Space',
    category: 'greenscreen',
    css: 'contrast(1.3) brightness(1.05)',
    color: '#6366F1',
    bgUrl: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=1200&auto=format&fit=crop&q=80',
  },
  // FX Overlays
  {
    id: 'fx-glitter',
    name: 'Bling & Sparkles ✨',
    category: 'fx',
    css: 'brightness(1.1) saturate(1.2) contrast(1.05)',
    color: '#FACC15',
    overlayType: 'sparkles',
  },
  {
    id: 'fx-glitch',
    name: 'Glitch RGB Wave ⚡',
    category: 'fx',
    css: 'contrast(1.4) saturate(1.5)',
    color: '#EC4899',
    overlayType: 'glitch',
  },
];

export const TikTokStudioModal: React.FC = () => {
  const { userProfile } = useAuth();
  const { isTikTokStudioOpen, setIsTikTokStudioOpen, uploadShortVideo, setActiveTab } = useApp();

  // Mode: 'camera' | 'preview'
  const [mode, setMode] = useState<'camera' | 'preview'>('camera');
  const [facingMode, setFacingMode] = useState<'user' | 'environment'>('user');
  const [selectedDuration, setSelectedDuration] = useState<15 | 60>(15);
  const [activeFilter, setActiveFilter] = useState<TikTokFilter>(FILTERS[0]);
  const [filterIntensity, setFilterIntensity] = useState<number>(100);
  const [activeFilterCategory, setActiveFilterCategory] = useState<'all' | 'beauty' | 'vibe' | 'greenscreen' | 'fx'>('all');
  const [countdown, setCountdown] = useState<0 | 3 | 10>(0);
  const [countdownValue, setCountdownValue] = useState<number | null>(null);
  const [speed, setSpeed] = useState<number>(1);
  const [customGreenScreenUrl, setCustomGreenScreenUrl] = useState<string | null>(null);

  // Sound & Music Library States
  const [customSounds, setCustomSounds] = useState<SoundTrack[]>([]);
  const [selectedSound, setSelectedSound] = useState<SoundTrack>(SOUND_TRACKS[0]);
  const [soundCategory, setSoundCategory] = useState<'all' | 'custom' | 'trending' | 'desi' | 'lofi' | 'pop' | 'edm'>('all');
  const [showSoundsPicker, setShowSoundsPicker] = useState(false);
  const [isPlayingSoundPreview, setIsPlayingSoundPreview] = useState(false);
  const [soundVolume, setSoundVolume] = useState(0.8);
  const [micVolume, setMicVolume] = useState(1.0);
  const audioGalleryInputRef = useRef<HTMLInputElement | null>(null);

  // Video Editing States
  const [showEditorTools, setShowEditorTools] = useState(false);
  const [activeEditorTab, setActiveEditorTab] = useState<'audio' | 'text' | 'filter'>('audio');
  const [textSticker, setTextSticker] = useState('');
  const [textStickerStyle, setTextStickerStyle] = useState<'pink' | 'white' | 'dark' | 'neon'>('pink');
  const [textStickerPos, setTextStickerPos] = useState<'top' | 'center' | 'bottom'>('top');

  const [showFiltersPicker, setShowFiltersPicker] = useState(false);

  // Camera & Stream states
  const [cameraActive, setCameraActive] = useState(false);
  const [cameraError, setCameraError] = useState<string | null>(null);

  // Recording states
  const [isRecording, setIsRecording] = useState(false);
  const [recordingSeconds, setRecordingSeconds] = useState(0);
  const [recordedVideoUrl, setRecordedVideoUrl] = useState<string | null>(null);
  const [isImageReel, setIsImageReel] = useState(false);

  // Post form states
  const [caption, setCaption] = useState('');
  const [tags, setTags] = useState('socialone, viral, tiktokstyle, foryou');

  const videoPreviewRef = useRef<HTMLVideoElement | null>(null);
  const liveVideoRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const recordedChunksRef = useRef<Blob[]>([]);
  const streamRef = useRef<MediaStream | null>(null);
  const galleryInputRef = useRef<HTMLInputElement | null>(null);
  const animationFrameRef = useRef<number | null>(null);

  // Fallback interactive canvas generator for browsers/iframes without camera permission
  const drawCanvasFallback = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let tick = 0;
    const render = () => {
      tick += 0.04;
      const w = canvas.width;
      const h = canvas.height;

      // Dynamic vibrant camera background
      const grad = ctx.createLinearGradient(0, 0, w, h);
      grad.addColorStop(0, '#0F172A');
      grad.addColorStop(0.5, '#1E1B4B');
      grad.addColorStop(1, '#020617');
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, w, h);

      // Studio grid lines
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.05)';
      ctx.lineWidth = 1;
      for (let x = 0; x < w; x += 40) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, h);
        ctx.stroke();
      }
      for (let y = 0; y < h; y += 40) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(w, y);
        ctx.stroke();
      }

      // Animated glowing studio orb / avatar
      const centerX = w / 2;
      const centerY = h / 2 - 40;
      const radius = 60 + Math.sin(tick * 2) * 8;

      ctx.save();
      ctx.shadowBlur = 30;
      ctx.shadowColor = '#6366F1';
      ctx.beginPath();
      ctx.arc(centerX, centerY, radius, 0, Math.PI * 2);
      ctx.fillStyle = '#4F46E5';
      ctx.fill();
      ctx.restore();

      // Inner creator initial
      ctx.fillStyle = '#FFFFFF';
      ctx.font = 'bold 36px sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(userProfile?.displayName?.charAt(0) || 'S', centerX, centerY);

      // Studio HUD overlay
      ctx.font = '14px sans-serif';
      ctx.fillStyle = '#38BDF8';
      ctx.fillText('TikTok Studio Canvas', centerX, centerY + radius + 40);

      ctx.font = '12px sans-serif';
      ctx.fillStyle = 'rgba(255, 255, 255, 0.6)';
      ctx.fillText('Live Recording Viewfinder', centerX, centerY + radius + 65);

      animationFrameRef.current = requestAnimationFrame(render);
    };

    render();
  };

  // Camera stream starter with fallback waterfall
  const startCamera = useCallback(async () => {
    setCameraError(null);
    let stream: MediaStream | null = null;

    try {
      stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode },
        audio: true,
      });
    } catch {
      try {
        stream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode },
          audio: false,
        });
      } catch {
        try {
          stream = await navigator.mediaDevices.getUserMedia({
            video: true,
            audio: false,
          });
        } catch (err: any) {
          console.warn('Physical camera unavailable:', err?.message);
          setCameraError(
            'Camera permission is blocked or unavailable in this iframe. Canvas Camera, Gallery upload, and Demo clips are ready to record!'
          );
        }
      }
    }

    if (stream) {
      streamRef.current = stream;
      setCameraActive(true);
      if (liveVideoRef.current) {
        liveVideoRef.current.srcObject = stream;
        liveVideoRef.current.play().catch(() => {});
      }
    } else {
      setCameraActive(false);
      drawCanvasFallback();
    }
  }, [facingMode]);

  // Launch camera when modal opens
  useEffect(() => {
    if (isTikTokStudioOpen && mode === 'camera') {
      startCamera();
    } else {
      if (streamRef.current) {
        streamRef.current.getTracks().forEach((t) => t.stop());
        streamRef.current = null;
      }
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
    }

    return () => {
      soundEngine.stop();
      if (streamRef.current) {
        streamRef.current.getTracks().forEach((t) => t.stop());
      }
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
    };
  }, [isTikTokStudioOpen, mode, startCamera]);

  // Recording timer countdown
  useEffect(() => {
    let timer: any;
    if (isRecording) {
      timer = setInterval(() => {
        setRecordingSeconds((prev) => {
          if (prev >= selectedDuration - 1) {
            handleStopRecording();
            return selectedDuration;
          }
          return prev + 1;
        });
      }, 1000);
    }
    return () => clearInterval(timer);
  }, [isRecording, selectedDuration]);

  // Update volume in sound engine
  useEffect(() => {
    soundEngine.setVolume(soundVolume);
  }, [soundVolume]);

  // Supported MimeType finder
  const getSupportedMimeType = () => {
    if (typeof MediaRecorder === 'undefined' || !MediaRecorder.isTypeSupported) {
      return '';
    }
    const candidates = [
      'video/webm;codecs=vp9,opus',
      'video/webm;codecs=vp8,opus',
      'video/webm',
      'video/mp4;codecs=avc1,mp4a.40.2',
      'video/mp4',
    ];
    for (const c of candidates) {
      if (MediaRecorder.isTypeSupported(c)) return c;
    }
    return '';
  };

  // Sound Playback Toggle
  const handleToggleSoundPreview = (track?: SoundTrack) => {
    const targetTrack = track || selectedSound;
    if (isPlayingSoundPreview && soundEngine.getCurrentTrack()?.id === targetTrack.id) {
      soundEngine.stop();
      setIsPlayingSoundPreview(false);
    } else {
      setSelectedSound(targetTrack);
      soundEngine.playTrack(targetTrack);
      setIsPlayingSoundPreview(true);
    }
  };

  // Start Recording
  const handleStartRecording = () => {
    recordedChunksRef.current = [];
    setRecordingSeconds(0);
    setIsRecording(true);

    // PLAY SOUND ALOUD THROUGH SPEAKERS IN REAL-TIME!
    soundEngine.playTrack(selectedSound);
    setIsPlayingSoundPreview(true);

    let recordingStream: MediaStream | null = streamRef.current;

    // If physical camera stream wasn't granted, record from the animated canvas!
    if (!recordingStream && canvasRef.current) {
      try {
        recordingStream = canvasRef.current.captureStream(30);
      } catch (e) {
        console.warn('Canvas stream capture error:', e);
      }
    }

    if (recordingStream) {
      try {
        // Merge Web Audio synthesizer stream track so the recorded video file HAS real sound!
        const audioStreamTrack = soundEngine.getAudioStreamTrack();
        let finalStream = recordingStream;
        if (audioStreamTrack) {
          const tracks = [...recordingStream.getVideoTracks()];
          const mic = recordingStream.getAudioTracks()[0];
          if (mic && micVolume > 0) {
            tracks.push(mic);
          }
          tracks.push(audioStreamTrack);
          finalStream = new MediaStream(tracks);
        }

        const mimeType = getSupportedMimeType();
        const options: MediaRecorderOptions = mimeType ? { mimeType } : {};
        const recorder = new MediaRecorder(finalStream, options);
        mediaRecorderRef.current = recorder;

        recorder.ondataavailable = (event) => {
          if (event.data && event.data.size > 0) {
            recordedChunksRef.current.push(event.data);
          }
        };

        recorder.onstop = () => {
          const type = mimeType || 'video/webm';
          const blob = new Blob(recordedChunksRef.current, { type });
          if (blob.size > 0) {
            const url = URL.createObjectURL(blob);
            setRecordedVideoUrl(url);
          } else {
            setRecordedVideoUrl(
              'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4'
            );
          }
          setMode('preview');
        };

        recorder.start(250);
      } catch (err) {
        console.warn('MediaRecorder error:', err);
      }
    }
  };

  const handleTriggerRecord = () => {
    if (isRecording) {
      handleStopRecording();
      return;
    }

    if (countdown > 0) {
      setCountdownValue(countdown);
      let count = countdown;
      const interval = setInterval(() => {
        count -= 1;
        if (count <= 0) {
          clearInterval(interval);
          setCountdownValue(null);
          handleStartRecording();
        } else {
          setCountdownValue(count);
        }
      }, 1000);
    } else {
      handleStartRecording();
    }
  };

  // Stop Recording
  const handleStopRecording = () => {
    setIsRecording(false);
    soundEngine.stop();
    setIsPlayingSoundPreview(false);

    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      try {
        mediaRecorderRef.current.stop();
      } catch {
        setRecordedVideoUrl(
          'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4'
        );
        setMode('preview');
      }
    } else {
      setRecordedVideoUrl(
        'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4'
      );
      setMode('preview');
    }
  };

  // Pick picture or video directly from Gallery
  const handleGalleryVideoSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const isImage = file.type.startsWith('image/');
    setIsImageReel(isImage);
    const fileUrl = URL.createObjectURL(file);
    setRecordedVideoUrl(fileUrl);
    setCaption(file.name.replace(/\.[^/.]+$/, ''));
    setMode('preview');
  };

  // Upload Custom MP3 or Audio Song directly from Gallery / Files
  const handleCustomAudioUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const url = URL.createObjectURL(file);
    const cleanName = file.name.replace(/\.[^/.]+$/, '');
    const newTrack: SoundTrack = {
      id: `custom-sound-${Date.now()}`,
      title: cleanName || 'Gallery Custom Song',
      artist: 'Uploaded from Gallery MP3 🎵',
      category: 'custom',
      bpm: 120,
      durationSec: 60,
      tags: ['gallery', 'mp3', 'custom'],
      vibeColor: '#10B981',
      customAudioUrl: url,
    };

    setCustomSounds((prev) => [newTrack, ...prev]);
    setSelectedSound(newTrack);
    soundEngine.playTrack(newTrack);
    setIsPlayingSoundPreview(true);
    setShowSoundsPicker(false);
  };

  const handleRetake = () => {
    soundEngine.stop();
    setIsPlayingSoundPreview(false);
    if (recordedVideoUrl && recordedVideoUrl.startsWith('blob:')) {
      URL.revokeObjectURL(recordedVideoUrl);
    }
    setRecordedVideoUrl(null);
    setIsImageReel(false);
    setMode('camera');
    setRecordingSeconds(0);
    setIsRecording(false);
  };

  const handlePublish = async () => {
    soundEngine.stop();
    if (!recordedVideoUrl) return;
    const cleanTags = tags
      .split(',')
      .map((t) => t.trim().replace(/^#/, ''))
      .filter(Boolean);

    await uploadShortVideo(
      recordedVideoUrl,
      caption || 'Check out my new TikTok video reel on SocialOne! ✨🔥 #shorts #socialone',
      cleanTags,
      selectedSound.title
    );

    setIsTikTokStudioOpen(false);
    setIsImageReel(false);
    setMode('camera');
    setActiveTab('videos');
  };

  if (!isTikTokStudioOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black flex items-center justify-center p-0 sm:p-4 select-none">
      {/* Hidden Gallery Input (Accepts both Videos and Pictures/Photos) */}
      <input
        ref={galleryInputRef}
        type="file"
        accept="video/*,image/*"
        onChange={handleGalleryVideoSelect}
        className="hidden"
      />

      {/* Hidden Audio/MP3 Gallery Input (Upload Song from Device) */}
      <input
        ref={audioGalleryInputRef}
        type="file"
        accept="audio/*,.mp3,.wav,.m4a,.aac,.ogg"
        onChange={handleCustomAudioUpload}
        className="hidden"
      />

      {/* Main TikTok Viewfinder Container */}
      <div className="relative w-full max-w-sm sm:max-w-md h-full sm:h-[92vh] sm:rounded-3xl overflow-hidden bg-slate-950 flex flex-col justify-between shadow-2xl border border-white/10">
        {/* Live Top Progress Bar during recording */}
        {isRecording && (
          <div className="absolute top-0 left-0 right-0 h-2 bg-white/20 z-40">
            <div
              className="h-full bg-gradient-to-r from-rose-500 to-red-600 transition-all duration-300 ease-linear"
              style={{ width: `${(recordingSeconds / selectedDuration) * 100}%` }}
            />
          </div>
        )}

        {/* Top Sound & Controls Bar */}
        <div className="absolute top-4 left-4 right-4 z-30 flex items-center justify-between text-white drop-shadow">
          <button
            onClick={() => {
              soundEngine.stop();
              setIsTikTokStudioOpen(false);
              setMode('camera');
            }}
            className="p-2.5 rounded-full bg-black/50 hover:bg-black/70 backdrop-blur-md cursor-pointer transition-colors"
          >
            <X className="w-5 h-5" />
          </button>

          {/* Center Add Sound / Music Bar with Equalizer Animation */}
          <button
            onClick={() => setShowSoundsPicker(!showSoundsPicker)}
            className={`px-3.5 py-1.5 rounded-full backdrop-blur-md text-xs font-semibold flex items-center gap-2 cursor-pointer border max-w-[210px] transition-all ${
              isPlayingSoundPreview
                ? 'bg-rose-600/80 border-rose-400 text-white shadow-lg shadow-rose-500/25 ring-2 ring-rose-400/40'
                : 'bg-black/50 hover:bg-black/70 border-white/20 text-white'
            }`}
          >
            <Music className={`w-3.5 h-3.5 ${isPlayingSoundPreview ? 'animate-bounce text-yellow-300' : 'text-blue-400'}`} />
            <span className="truncate">{selectedSound.title}</span>
            {isPlayingSoundPreview && (
              <span className="flex items-center gap-0.5">
                <span className="w-0.5 h-2.5 bg-yellow-300 animate-pulse" />
                <span className="w-0.5 h-3.5 bg-yellow-300 animate-bounce" />
                <span className="w-0.5 h-2 bg-yellow-300 animate-pulse" />
              </span>
            )}
          </button>

          {/* Duration Badge */}
          <button
            onClick={() => setSelectedDuration((prev) => (prev === 15 ? 60 : 15))}
            className="px-2.5 py-1.5 rounded-full bg-black/50 hover:bg-black/70 backdrop-blur-md text-[11px] font-bold text-white border border-white/20 cursor-pointer"
          >
            {selectedDuration}s
          </button>
        </div>

        {/* EXPANDED SOUNDS & MUSIC LIBRARY PICKER MODAL */}
        {showSoundsPicker && (
          <div className="absolute top-16 left-3 right-3 z-40 p-4 rounded-3xl bg-slate-950/95 backdrop-blur-2xl border border-rose-500/30 text-white shadow-2xl space-y-3 max-h-[75vh] flex flex-col">
            <div className="flex items-center justify-between pb-2 border-b border-white/10 shrink-0">
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-lg bg-gradient-to-tr from-rose-500 to-indigo-600 flex items-center justify-center text-white">
                  <Music className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="font-bold text-xs">TikTok Music Library & Audio Sounds</h4>
                  <p className="text-[10px] text-slate-400">Real Web Audio Beats & Melodies</p>
                </div>
              </div>
              <button
                onClick={() => setShowSoundsPicker(false)}
                className="px-2.5 py-1 rounded-lg bg-white/10 hover:bg-white/20 text-xs font-semibold cursor-pointer"
              >
                Done
              </button>
            </div>

            {/* Gallery Audio Upload Card */}
            <div className="p-3 rounded-2xl bg-gradient-to-r from-emerald-950/90 via-slate-900 to-indigo-950/90 border border-emerald-500/40 flex items-center justify-between gap-3 shrink-0 shadow-lg">
              <div className="flex items-center gap-2.5 min-w-0">
                <div className="w-9 h-9 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center shrink-0 border border-emerald-500/30">
                  <Headphones className="w-5 h-5" />
                </div>
                <div className="min-w-0">
                  <p className="text-xs font-bold text-white truncate flex items-center gap-1.5">
                    <span>Gallery MP3 / Music Upload</span>
                    <span className="px-1.5 py-0.5 rounded text-[9px] bg-emerald-500/30 text-emerald-300 font-semibold uppercase">Device</span>
                  </p>
                  <p className="text-[10px] text-slate-300 truncate">Select any MP3/song from your phone gallery or files</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => audioGalleryInputRef.current?.click()}
                className="px-3 py-1.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold text-xs flex items-center gap-1.5 cursor-pointer shadow-md shrink-0 transition-transform active:scale-95"
              >
                <Upload className="w-3.5 h-3.5" />
                <span>Upload MP3</span>
              </button>
            </div>

            {/* Sound Categories */}
            <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none text-[11px] shrink-0">
              {[
                { id: 'all', label: 'All Sounds' },
                { id: 'custom', label: `📂 My Gallery (${customSounds.length})` },
                { id: 'trending', label: '🔥 Trending' },
                { id: 'desi', label: '🥁 Desi Drill' },
                { id: 'lofi', label: '☕ Lo-Fi Chill' },
                { id: 'pop', label: '💃 Pop Dance' },
                { id: 'edm', label: '⚡ EDM Trap' },
              ].map((c) => (
                <button
                  key={c.id}
                  onClick={() => setSoundCategory(c.id as any)}
                  className={`px-3 py-1 rounded-full whitespace-nowrap cursor-pointer transition-colors ${
                    soundCategory === c.id
                      ? 'bg-rose-600 text-white font-bold'
                      : 'bg-white/10 text-slate-300 hover:bg-white/20'
                  }`}
                >
                  {c.label}
                </button>
              ))}
            </div>

            {/* Sound Volume Slider */}
            <div className="flex items-center justify-between gap-3 px-3 py-2 rounded-xl bg-white/5 border border-white/10 text-xs shrink-0">
              <div className="flex items-center gap-1.5 text-slate-300">
                <Volume2 className="w-3.5 h-3.5 text-teal-400" />
                <span className="text-[11px]">Music Volume:</span>
              </div>
              <input
                type="range"
                min="0"
                max="1"
                step="0.05"
                value={soundVolume}
                onChange={(e) => setSoundVolume(Number(e.target.value))}
                className="flex-1 accent-rose-500 cursor-pointer h-1.5 bg-slate-700 rounded-lg"
              />
              <span className="text-[11px] font-bold text-rose-400 w-8 text-right">
                {Math.round(soundVolume * 100)}%
              </span>
            </div>

            {/* Sound Tracks List */}
            <div className="space-y-1.5 overflow-y-auto flex-1 pr-1">
              {[...customSounds, ...SOUND_TRACKS]
                .filter((s) => soundCategory === 'all' || s.category === soundCategory)
                .map((sound) => {
                  const isSelected = selectedSound.id === sound.id;
                  const isThisPlaying = isPlayingSoundPreview && isSelected;
                  const isCustom = sound.category === 'custom';
                  return (
                    <div
                      key={sound.id}
                      className={`p-2.5 rounded-2xl text-xs flex items-center justify-between cursor-pointer transition-all border ${
                        isSelected
                          ? 'bg-rose-500/20 border-rose-500 text-white font-semibold'
                          : isCustom
                          ? 'bg-emerald-950/30 hover:bg-emerald-950/50 border-emerald-500/30 text-emerald-100'
                          : 'bg-white/5 hover:bg-white/10 border-transparent text-slate-300'
                      }`}
                    >
                      <div
                        className="flex items-center gap-2.5 flex-1 min-w-0"
                        onClick={() => handleToggleSoundPreview(sound)}
                      >
                        <button
                          type="button"
                          className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 transition-colors cursor-pointer ${
                            isThisPlaying
                              ? 'bg-rose-500 text-white'
                              : isCustom
                              ? 'bg-emerald-500/20 text-emerald-400 hover:bg-emerald-500/30'
                              : 'bg-white/10 text-slate-200 hover:bg-white/20'
                          }`}
                        >
                          {isThisPlaying ? (
                            <Pause className="w-4 h-4 fill-current" />
                          ) : (
                            <Play className="w-4 h-4 fill-current ml-0.5" />
                          )}
                        </button>

                        <div className="min-w-0 flex-1">
                          <div className="flex items-center gap-1.5">
                            <p className="font-bold truncate text-white">{sound.title}</p>
                            {isCustom && (
                              <span className="px-1.5 py-0.5 rounded text-[9px] bg-emerald-500/20 text-emerald-300 font-bold border border-emerald-500/30 shrink-0">
                                Gallery Audio
                              </span>
                            )}
                          </div>
                          <div className="flex items-center gap-2 text-[10px] text-slate-400">
                            <span>{sound.artist}</span>
                            <span>•</span>
                            <span className="text-amber-400 font-medium">{sound.bpm} BPM</span>
                            <span>•</span>
                            <span>{sound.durationSec}s</span>
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center gap-2 pl-2 shrink-0">
                        <button
                          type="button"
                          onClick={() => {
                            setSelectedSound(sound);
                            setShowSoundsPicker(false);
                          }}
                          className={`px-3 py-1.5 rounded-xl text-[11px] font-bold cursor-pointer transition-colors ${
                            isSelected
                              ? 'bg-rose-500 text-white shadow-sm'
                              : isCustom
                              ? 'bg-emerald-600 hover:bg-emerald-500 text-white'
                              : 'bg-white/15 hover:bg-white/25 text-white'
                          }`}
                        >
                          {isSelected ? 'Selected' : 'Use'}
                        </button>
                      </div>
                    </div>
                  );
                })}
            </div>
          </div>
        )}

        {/* Right TikTok Tool Dock */}
        {mode === 'camera' && !isRecording && (
          <div className="absolute right-3 top-20 z-30 flex flex-col items-center gap-3.5 text-white drop-shadow">
            {/* Flip Camera */}
            <button
              onClick={() => {
                setFacingMode((prev) => (prev === 'user' ? 'environment' : 'user'));
              }}
              className="flex flex-col items-center gap-1 cursor-pointer group"
              title="Flip Camera (Front / Back)"
            >
              <div className="p-2.5 rounded-full bg-black/50 hover:bg-black/70 backdrop-blur-md transition-all group-hover:scale-110">
                <RefreshCw className="w-5 h-5" />
              </div>
              <span className="text-[10px] font-semibold">Flip</span>
            </button>

            {/* Filters Picker Button */}
            <button
              onClick={() => setShowFiltersPicker(!showFiltersPicker)}
              className="flex flex-col items-center gap-1 cursor-pointer group"
              title="Beauty, Vibe & Green Screen Filters"
            >
              <div
                className={`p-2.5 rounded-full backdrop-blur-md transition-all group-hover:scale-110 ${
                  activeFilter.id !== 'normal'
                    ? 'bg-gradient-to-tr from-amber-500 to-rose-500 ring-2 ring-white'
                    : 'bg-black/50 hover:bg-black/70'
                }`}
              >
                <Sparkles className="w-5 h-5 text-amber-300" />
              </div>
              <span className="text-[10px] font-semibold">Filters</span>
            </button>

            {/* Direct Add MP3 from Device Gallery */}
            <button
              onClick={() => audioGalleryInputRef.current?.click()}
              className="flex flex-col items-center gap-1 cursor-pointer group"
              title="Upload MP3 / Audio Song from Device Gallery"
            >
              <div className="p-2.5 rounded-full bg-emerald-600/50 hover:bg-emerald-600/80 ring-1 ring-emerald-400/40 backdrop-blur-md transition-all group-hover:scale-110">
                <Headphones className="w-5 h-5 text-emerald-300" />
              </div>
              <span className="text-[10px] font-semibold text-emerald-300">Add MP3</span>
            </button>

            {/* Direct Gallery Video / Photo Picker */}
            <button
              onClick={() => galleryInputRef.current?.click()}
              className="flex flex-col items-center gap-1 cursor-pointer group"
              title="Pick Video or Photo from Device Gallery"
            >
              <div className="p-2.5 rounded-full bg-cyan-600/50 hover:bg-cyan-600/80 ring-1 ring-cyan-400/40 backdrop-blur-md transition-all group-hover:scale-110">
                <Film className="w-5 h-5 text-cyan-200" />
              </div>
              <span className="text-[10px] font-semibold text-cyan-300">Gallery</span>
            </button>

            {/* Test / Play Sound Directly Button */}
            <button
              onClick={() => handleToggleSoundPreview()}
              className="flex flex-col items-center gap-1 cursor-pointer group"
              title="Listen to Selected Music"
            >
              <div
                className={`p-2.5 rounded-full backdrop-blur-md transition-all group-hover:scale-110 ${
                  isPlayingSoundPreview
                    ? 'bg-rose-600 ring-2 ring-yellow-400 animate-pulse'
                    : 'bg-black/50 hover:bg-black/70'
                }`}
              >
                {isPlayingSoundPreview ? (
                  <Volume2 className="w-5 h-5 text-yellow-300" />
                ) : (
                  <Play className="w-5 h-5 text-teal-300 fill-current" />
                )}
              </div>
              <span className="text-[10px] font-semibold">
                {isPlayingSoundPreview ? 'Sound On' : 'Play'}
              </span>
            </button>

            {/* Speed Toggle (0.5x, 1x, 2x, 3x) */}
            <button
              onClick={() => {
                const speeds = [0.5, 1, 2, 3];
                const nextIdx = (speeds.indexOf(speed) + 1) % speeds.length;
                setSpeed(speeds[nextIdx]);
              }}
              className="flex flex-col items-center gap-1 cursor-pointer group"
              title="Change Speed"
            >
              <div className="p-2.5 rounded-full bg-black/50 hover:bg-black/70 backdrop-blur-md transition-all group-hover:scale-110">
                <span className="w-5 h-5 flex items-center justify-center font-bold text-xs text-rose-400">
                  {speed}x
                </span>
              </div>
              <span className="text-[10px] font-semibold">Speed</span>
            </button>

            {/* Countdown Timer (Off, 3s, 10s) */}
            <button
              onClick={() => {
                setCountdown((prev) => (prev === 0 ? 3 : prev === 3 ? 10 : 0));
              }}
              className="flex flex-col items-center gap-1 cursor-pointer group"
              title="Countdown Timer (3s / 10s)"
            >
              <div
                className={`p-2.5 rounded-full backdrop-blur-md transition-all group-hover:scale-110 ${
                  countdown > 0 ? 'bg-indigo-600 ring-2 ring-white' : 'bg-black/50 hover:bg-black/70'
                }`}
              >
                <Timer className="w-5 h-5 text-teal-300" />
              </div>
              <span className="text-[10px] font-semibold">
                {countdown === 0 ? 'Timer' : `${countdown}s`}
              </span>
            </button>
          </div>
        )}

        {/* Filter Palette Selector Drawer */}
        {showFiltersPicker && (
          <div className="absolute bottom-28 left-3 right-3 z-40 p-3.5 rounded-3xl bg-slate-950/95 backdrop-blur-xl border border-white/20 text-white shadow-2xl space-y-3">
            <div className="flex items-center justify-between border-b border-white/10 pb-2">
              <div className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-amber-400" />
                <span className="font-bold text-xs text-amber-300">
                  TikTok Filters & Studio Effects
                </span>
              </div>
              <button
                onClick={() => setShowFiltersPicker(false)}
                className="text-[11px] text-slate-400 hover:text-white"
              >
                Close
              </button>
            </div>

            {/* Category Filter Pills */}
            <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none text-[11px]">
              {[
                { id: 'all', label: '🔥 All' },
                { id: 'beauty', label: '✨ Beauty & Skin' },
                { id: 'vibe', label: '🎨 Color & Vibe' },
                { id: 'greenscreen', label: '🟩 Green Screen' },
                { id: 'fx', label: '🌟 Special FX' },
              ].map((cat) => (
                <button
                  key={cat.id}
                  onClick={() => setActiveFilterCategory(cat.id as any)}
                  className={`px-3 py-1 rounded-full whitespace-nowrap cursor-pointer transition-colors ${
                    activeFilterCategory === cat.id
                      ? 'bg-rose-600 text-white font-bold'
                      : 'bg-white/10 text-slate-300 hover:bg-white/20'
                  }`}
                >
                  {cat.label}
                </button>
              ))}
            </div>

            {/* Filter Intensity Slider */}
            {activeFilter.id !== 'normal' && (
              <div className="flex items-center justify-between gap-3 px-1 py-1 rounded-xl bg-white/5 border border-white/10 text-xs">
                <span className="text-[11px] text-slate-300 shrink-0">Intensity:</span>
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={filterIntensity}
                  onChange={(e) => setFilterIntensity(Number(e.target.value))}
                  className="w-full accent-rose-500 cursor-pointer h-1.5 bg-slate-700 rounded-lg"
                />
                <span className="text-[11px] font-bold text-rose-400 w-8 text-right">
                  {filterIntensity}%
                </span>
              </div>
            )}

            {/* Filter Circular Selector Horizontal Strip */}
            <div className="overflow-x-auto flex items-center gap-3 pb-1 pt-1 scrollbar-none">
              {FILTERS.filter(
                (f) => activeFilterCategory === 'all' || f.category === activeFilterCategory
              ).map((f) => {
                const isSelected = activeFilter.id === f.id;
                return (
                  <button
                    key={f.id}
                    onClick={() => setActiveFilter(f)}
                    className="flex flex-col items-center gap-1 shrink-0 cursor-pointer group"
                  >
                    <div
                      className={`w-12 h-12 rounded-2xl flex items-center justify-center border-2 transition-all group-hover:scale-105 shadow-md ${
                        isSelected
                          ? 'border-rose-500 ring-2 ring-rose-500/50 scale-105'
                          : 'border-white/30 opacity-80 hover:opacity-100'
                      }`}
                      style={{
                        backgroundColor: f.color + '33',
                        borderColor: isSelected ? '#F43F5E' : f.color,
                      }}
                    >
                      <span className="text-xs font-black text-white">{f.name.slice(0, 2)}</span>
                    </div>
                    <span
                      className={`text-[10px] truncate max-w-[70px] ${
                        isSelected ? 'text-rose-400 font-bold' : 'text-slate-300'
                      }`}
                    >
                      {f.name}
                    </span>
                  </button>
                );
              })}

              {/* Upload Custom Green Screen Background if in greenscreen category */}
              {(activeFilterCategory === 'all' || activeFilterCategory === 'greenscreen') && (
                <label className="flex flex-col items-center gap-1 shrink-0 cursor-pointer group">
                  <div className="w-12 h-12 rounded-2xl border-2 border-dashed border-emerald-400/80 bg-emerald-500/10 flex items-center justify-center hover:bg-emerald-500/20 transition-all">
                    <Film className="w-5 h-5 text-emerald-400" />
                  </div>
                  <span className="text-[10px] text-emerald-400 font-bold">Custom BG</span>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      if (file) {
                        const url = URL.createObjectURL(file);
                        setCustomGreenScreenUrl(url);
                        setActiveFilter({
                          id: 'gs-custom',
                          name: 'Custom Backdrop',
                          category: 'greenscreen',
                          css: 'contrast(1.05) brightness(1.05)',
                          color: '#10B981',
                          bgUrl: url,
                        });
                      }
                    }}
                    className="hidden"
                  />
                </label>
              )}
            </div>
          </div>
        )}

        {/* Viewport Area: Live Camera View, Canvas, or Preview Video Player */}
        <div className="relative w-full h-full flex items-center justify-center overflow-hidden bg-black">
          {/* Green Screen Virtual Studio Background Layer */}
          {activeFilter.category === 'greenscreen' && (activeFilter.bgUrl || customGreenScreenUrl) && (
            <div className="absolute inset-0 z-0">
              <img
                src={customGreenScreenUrl || activeFilter.bgUrl}
                alt="Green screen background"
                className="w-full h-full object-cover filter brightness-95"
              />
            </div>
          )}

          {mode === 'camera' ? (
            <>
              {/* Actual WebRTC Video Element */}
              <video
                ref={liveVideoRef}
                autoPlay
                playsInline
                muted
                style={{
                  filter: activeFilter.id === 'normal' ? 'none' : activeFilter.css,
                  opacity: activeFilter.category === 'greenscreen' ? 0.9 : 1,
                  mixBlendMode: activeFilter.category === 'greenscreen' ? 'screen' : 'normal',
                }}
                className={`w-full h-full object-cover relative z-1 ${cameraActive ? 'block' : 'hidden'} ${
                  facingMode === 'user' ? 'transform scale-x-[-1]' : ''
                }`}
              />

              {/* Interactive Fallback Canvas if webcam is blocked or initializing */}
              <canvas
                ref={canvasRef}
                width={380}
                height={680}
                style={{ filter: activeFilter.id === 'normal' ? 'none' : activeFilter.css }}
                className={`w-full h-full object-cover relative z-1 ${cameraActive ? 'hidden' : 'block'}`}
              />

              {/* Camera status notice if blocked */}
              {cameraError && (
                <div className="absolute top-20 left-4 right-4 z-20 p-3 rounded-2xl bg-black/75 backdrop-blur-md border border-amber-500/40 text-amber-300 text-xs flex items-start gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                  <div className="flex-1">
                    <p className="font-semibold">Webcam notice</p>
                    <p className="text-[11px] text-slate-300 mt-0.5">{cameraError}</p>
                    <button
                      onClick={startCamera}
                      className="mt-2 px-3 py-1 rounded-xl bg-amber-500 text-slate-900 font-bold text-[10px] cursor-pointer"
                    >
                      Retry Camera
                    </button>
                  </div>
                </div>
              )}
            </>
          ) : isImageReel ? (
            <div className="relative w-full h-full flex items-center justify-center overflow-hidden bg-black">
              <img
                src={recordedVideoUrl || ''}
                alt="Reel preview"
                style={{ filter: activeFilter.css }}
                className="w-full h-full object-cover transition-transform duration-700 hover:scale-105"
              />
              <div className="absolute top-16 left-4 z-20 px-2.5 py-1 rounded-full bg-black/60 text-[10px] text-teal-300 backdrop-blur-md flex items-center gap-1 border border-teal-500/30">
                <Sparkles className="w-3 h-3" />
                <span>TikTok Photo Reel</span>
              </div>
            </div>
          ) : (
            <div className="relative w-full h-full">
              <video
                ref={videoPreviewRef}
                src={recordedVideoUrl || ''}
                autoPlay
                loop
                playsInline
                controls
                style={{ filter: activeFilter.css }}
                className="w-full h-full object-cover"
              />
            </div>
          )}

          {/* TEXT STICKER OVERLAY ON VIDEO */}
          {textSticker && (
            <div
              className={`absolute left-4 right-4 z-20 flex justify-center pointer-events-none transition-all ${
                textStickerPos === 'top'
                  ? 'top-24'
                  : textStickerPos === 'center'
                  ? 'top-1/2 -translate-y-1/2'
                  : 'bottom-40'
              }`}
            >
              <div
                className={`px-4 py-2 rounded-2xl font-black text-sm max-w-[85%] text-center shadow-2xl backdrop-blur-md tracking-tight ${
                  textStickerStyle === 'pink'
                    ? 'bg-rose-600 text-white shadow-rose-600/50 border border-rose-400'
                    : textStickerStyle === 'neon'
                    ? 'bg-amber-400 text-slate-950 shadow-amber-400/50 border border-yellow-200'
                    : textStickerStyle === 'dark'
                    ? 'bg-black/85 text-white border border-white/30'
                    : 'bg-white text-slate-900 border border-slate-300'
                }`}
              >
                {textSticker}
              </div>
            </div>
          )}

          {/* VHS Retro 1990 Overlay */}
          {activeFilter.overlayType === 'vhs' && (
            <div className="absolute inset-0 pointer-events-none z-10 flex flex-col justify-between p-6 font-mono select-none">
              <div className="flex justify-between items-center text-xs text-rose-500 font-black tracking-widest animate-pulse">
                <span>REC 🔴</span>
                <span className="text-white text-[11px]">SP 0:00:15</span>
              </div>
              <div className="text-[11px] text-amber-300 font-bold tracking-widest drop-shadow">
                OCT 30 1998 04:20 PM
              </div>
            </div>
          )}

          {/* Shimmering Bling Sparkles Overlay */}
          {activeFilter.overlayType === 'sparkles' && (
            <div className="absolute inset-0 pointer-events-none z-10 overflow-hidden">
              <div className="absolute top-1/4 left-1/4 text-2xl animate-ping text-amber-300">✨</div>
              <div className="absolute top-1/3 right-1/4 text-xl animate-pulse text-yellow-200">⭐</div>
              <div className="absolute bottom-1/3 left-1/3 text-3xl animate-bounce text-pink-300">✨</div>
              <div className="absolute top-2/3 right-1/3 text-2xl animate-pulse text-amber-300">🌟</div>
            </div>
          )}

          {/* Glitch Overlay */}
          {activeFilter.overlayType === 'glitch' && (
            <div className="absolute inset-0 pointer-events-none z-10 mix-blend-color-dodge opacity-30 bg-gradient-to-r from-cyan-500 via-transparent to-rose-500 animate-pulse" />
          )}

          {/* Large Countdown Overlay (3, 2, 1) */}
          {countdownValue !== null && (
            <div className="absolute inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm pointer-events-none">
              <span className="text-9xl font-black text-rose-500 drop-shadow-2xl animate-ping">
                {countdownValue}
              </span>
            </div>
          )}
        </div>

        {/* BOTTOM SECTION: RECORDING CONTROLS VS VIDEO EDITOR / POST SCREEN */}
        {mode === 'camera' ? (
          <div className="absolute bottom-4 left-4 right-4 z-30 flex flex-col items-center gap-3">
            {/* Live recording timer indicator */}
            {isRecording && (
              <div className="flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-rose-600/90 backdrop-blur-md text-white text-xs font-bold animate-pulse shadow-lg">
                <span className="w-2.5 h-2.5 rounded-full bg-white" />
                <span>
                  Recording: 00:{recordingSeconds.toString().padStart(2, '0')} / 00:
                  {selectedDuration}
                </span>
              </div>
            )}

            {/* Record row with Gallery on left */}
            <div className="w-full flex items-center justify-around px-4">
              {/* Gallery Video Button */}
              <button
                onClick={() => galleryInputRef.current?.click()}
                disabled={isRecording}
                className="flex flex-col items-center gap-1 text-white disabled:opacity-40 cursor-pointer group"
                title="Select Video or Photo from Device Gallery"
              >
                <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-cyan-600/70 to-blue-600/70 group-hover:from-cyan-500 group-hover:to-blue-500 backdrop-blur-md flex items-center justify-center ring-2 ring-cyan-400/50 transition-transform group-hover:scale-105 shadow-xl">
                  <Film className="w-6 h-6 text-cyan-200" />
                </div>
                <span className="text-[11px] font-bold text-cyan-300">Gallery Video 🎬</span>
              </button>

              {/* Red TikTok Record Button */}
              <div className="relative flex items-center justify-center">
                <button
                  onClick={handleTriggerRecord}
                  className={`w-20 h-20 rounded-full flex items-center justify-center transition-all cursor-pointer shadow-2xl active:scale-95 ${
                    isRecording
                      ? 'border-4 border-white bg-transparent ring-4 ring-rose-500/50'
                      : 'border-4 border-white bg-gradient-to-tr from-rose-600 to-red-500 hover:scale-105'
                  }`}
                  title={isRecording ? 'Stop Recording' : 'Start Recording Video'}
                >
                  {isRecording ? (
                    <div className="w-7 h-7 rounded-md bg-rose-600 animate-pulse" />
                  ) : (
                    <div className="w-14 h-14 rounded-full bg-rose-600" />
                  )}
                </button>
              </div>

              {/* Demo Clip Trigger */}
              <button
                onClick={() => {
                  setRecordedVideoUrl(
                    'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4'
                  );
                  setMode('preview');
                }}
                disabled={isRecording}
                className="flex flex-col items-center gap-1 text-white disabled:opacity-40 cursor-pointer group"
                title="Use High-Definition Video Clip"
              >
                <div className="w-12 h-12 rounded-2xl bg-white/20 group-hover:bg-white/30 backdrop-blur-md flex items-center justify-center ring-2 ring-white/30 transition-transform group-hover:scale-105 shadow-lg">
                  <Sparkles className="w-6 h-6 text-amber-300" />
                </div>
                <span className="text-[11px] font-bold">Demo Clip</span>
              </button>
            </div>

            <p className="text-[10px] text-white/70">
              {isRecording
                ? 'Recording with live sound track! Tap center to finish'
                : 'Tap red button to record with sound, or choose Gallery / Demo Clip'}
            </p>
          </div>
        ) : (
          /* PREVIEW & VIDEO EDITOR SCREEN (TIKTOK STYLE) */
          <div className="absolute bottom-0 left-0 right-0 z-30 p-4 bg-gradient-to-t from-black via-black/95 to-transparent space-y-3 text-white">
            {/* Top Editor Quick Toggles: Audio Mixer, Text Sticker, Change Filter, Change MP3, Change Gallery Video */}
            <div className="flex items-center justify-between pb-1 border-b border-white/10 text-xs">
              <span className="font-bold text-slate-300 flex items-center gap-1.5">
                <Sliders className="w-3.5 h-3.5 text-rose-400" />
                TikTok Video Editor
              </span>

              <div className="flex items-center gap-1.5 flex-wrap justify-end">
                <button
                  type="button"
                  onClick={() => setShowSoundsPicker(true)}
                  className="px-2.5 py-1 rounded-lg text-[11px] font-semibold bg-emerald-600/80 hover:bg-emerald-600 text-white flex items-center gap-1 cursor-pointer transition-colors"
                  title="Change music or upload MP3 from gallery"
                >
                  <Music className="w-3 h-3 text-emerald-200" />
                  <span>MP3 Song</span>
                </button>

                <button
                  type="button"
                  onClick={() => galleryInputRef.current?.click()}
                  className="px-2.5 py-1 rounded-lg text-[11px] font-semibold bg-cyan-600/80 hover:bg-cyan-600 text-white flex items-center gap-1 cursor-pointer transition-colors"
                  title="Change video from phone gallery"
                >
                  <Film className="w-3 h-3 text-cyan-200" />
                  <span>Gallery Video</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setShowEditorTools(true);
                    setActiveEditorTab('audio');
                  }}
                  className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold flex items-center gap-1 cursor-pointer transition-colors ${
                    showEditorTools && activeEditorTab === 'audio'
                      ? 'bg-rose-600 text-white'
                      : 'bg-white/10 text-slate-300 hover:bg-white/20'
                  }`}
                >
                  <Volume2 className="w-3 h-3" />
                  <span>Audio Mix</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setShowEditorTools(true);
                    setActiveEditorTab('text');
                  }}
                  className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold flex items-center gap-1 cursor-pointer transition-colors ${
                    showEditorTools && activeEditorTab === 'text'
                      ? 'bg-rose-600 text-white'
                      : 'bg-white/10 text-slate-300 hover:bg-white/20'
                  }`}
                >
                  <Type className="w-3 h-3" />
                  <span>Text Sticker</span>
                </button>

                <button
                  type="button"
                  onClick={() => setShowFiltersPicker(!showFiltersPicker)}
                  className="px-2.5 py-1 rounded-lg text-[11px] font-semibold bg-white/10 hover:bg-white/20 text-slate-300 flex items-center gap-1 cursor-pointer"
                >
                  <Sparkles className="w-3 h-3 text-amber-300" />
                  <span>Filter</span>
                </button>
              </div>
            </div>

            {/* EXPANDABLE VIDEO EDITOR PANEL */}
            {showEditorTools && (
              <div className="p-3 rounded-2xl bg-slate-900/90 border border-white/15 space-y-2.5 text-xs">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-white">
                    {activeEditorTab === 'audio' && '🔊 Volume Mixer (Original Mic vs Music)'}
                    {activeEditorTab === 'text' && '✍️ Video Caption & Sticker'}
                  </span>
                  <button
                    onClick={() => setShowEditorTools(false)}
                    className="text-[11px] text-slate-400 hover:text-white"
                  >
                    Done
                  </button>
                </div>

                {/* AUDIO MIXER TAB */}
                {activeEditorTab === 'audio' && (
                  <div className="space-y-2">
                    <div className="flex items-center justify-between gap-3">
                      <span className="text-[11px] text-slate-300">Soundtrack Music:</span>
                      <input
                        type="range"
                        min="0"
                        max="1"
                        step="0.05"
                        value={soundVolume}
                        onChange={(e) => setSoundVolume(Number(e.target.value))}
                        className="w-32 accent-rose-500 cursor-pointer h-1.5 bg-slate-700 rounded-lg"
                      />
                      <span className="text-[11px] font-bold text-rose-400 w-8 text-right">
                        {Math.round(soundVolume * 100)}%
                      </span>
                    </div>

                    <div className="flex items-center justify-between gap-3">
                      <span className="text-[11px] text-slate-300">Original Mic:</span>
                      <input
                        type="range"
                        min="0"
                        max="1"
                        step="0.05"
                        value={micVolume}
                        onChange={(e) => setMicVolume(Number(e.target.value))}
                        className="w-32 accent-indigo-500 cursor-pointer h-1.5 bg-slate-700 rounded-lg"
                      />
                      <span className="text-[11px] font-bold text-indigo-400 w-8 text-right">
                        {Math.round(micVolume * 100)}%
                      </span>
                    </div>
                  </div>
                )}

                {/* TEXT STICKER TAB */}
                {activeEditorTab === 'text' && (
                  <div className="space-y-2">
                    <input
                      type="text"
                      value={textSticker}
                      onChange={(e) => setTextSticker(e.target.value)}
                      placeholder="Add viral sticker text (e.g. Wait for the drop! 😂)"
                      className="w-full px-3 py-1.5 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs outline-none focus:border-rose-500"
                    />

                    <div className="flex items-center justify-between text-[11px]">
                      <div className="flex items-center gap-1.5">
                        <span className="text-slate-400">Style:</span>
                        {(['pink', 'neon', 'dark', 'white'] as const).map((s) => (
                          <button
                            key={s}
                            type="button"
                            onClick={() => setTextStickerStyle(s)}
                            className={`px-2 py-0.5 rounded-md font-bold uppercase text-[10px] cursor-pointer ${
                              textStickerStyle === s
                                ? 'bg-rose-500 text-white'
                                : 'bg-slate-800 text-slate-400'
                            }`}
                          >
                            {s}
                          </button>
                        ))}
                      </div>

                      <div className="flex items-center gap-1">
                        <span className="text-slate-400">Pos:</span>
                        {(['top', 'center', 'bottom'] as const).map((p) => (
                          <button
                            key={p}
                            type="button"
                            onClick={() => setTextStickerPos(p)}
                            className={`px-1.5 py-0.5 rounded-md text-[10px] capitalize cursor-pointer ${
                              textStickerPos === p
                                ? 'bg-indigo-600 text-white font-bold'
                                : 'bg-slate-800 text-slate-400'
                            }`}
                          >
                            {p}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* Caption Input */}
            <div className="space-y-1.5">
              <input
                type="text"
                value={caption}
                onChange={(e) => setCaption(e.target.value)}
                placeholder="Write a catchy caption for your TikTok short..."
                className="w-full px-4 py-2.5 rounded-2xl text-xs bg-white/15 backdrop-blur-md border border-white/20 text-white placeholder-white/60 outline-none focus:bg-white/25"
              />

              {/* Quick Hashtags */}
              <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar py-0.5 text-[11px]">
                {['#foryou', '#viral', '#shorts', '#trending', '#socialone'].map((tag) => (
                  <button
                    key={tag}
                    onClick={() => setCaption((prev) => `${prev} ${tag}`.trim())}
                    className="px-2.5 py-1 rounded-full bg-white/10 hover:bg-white/20 text-blue-300 font-semibold cursor-pointer shrink-0"
                  >
                    {tag}
                  </button>
                ))}
              </div>
            </div>

            {/* Action Buttons: Retake & Post to Shorts */}
            <div className="flex items-center gap-3 pt-1">
              <button
                onClick={handleRetake}
                className="flex-1 py-3 rounded-2xl text-xs font-bold bg-white/20 hover:bg-white/30 text-white flex items-center justify-center gap-1.5 cursor-pointer backdrop-blur-md"
              >
                <RotateCcw className="w-4 h-4" />
                <span>Retake</span>
              </button>

              <button
                onClick={handlePublish}
                className="flex-[2] py-3 rounded-2xl text-xs font-bold text-white bg-gradient-to-r from-rose-600 via-purple-600 to-blue-600 hover:opacity-95 shadow-xl flex items-center justify-center gap-1.5 cursor-pointer active:scale-[0.98]"
              >
                <Zap className="w-4 h-4 fill-current" />
                <span>Post to Shorts Feed</span>
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
