import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { Play, MessageCircle, Users, Sparkles, Shield, CheckCircle2, Video, Globe2 } from 'lucide-react';

import { TikTokIdModal } from '../modals/TikTokIdModal';

export const LoginView: React.FC = () => {
  const { loginWithGoogle, loginAsFounder, loginAsDemoUser, loginWithAdminCredentials, darkMode } = useAuth();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [showTikTokIdModal, setShowTikTokIdModal] = useState(false);

  // Dedicated Admin Login State
  const [showAdminLogin, setShowAdminLogin] = useState(false);
  const [adminEmail, setAdminEmail] = useState('gulamaftab74@gmail.com');
  const [adminPassword, setAdminPassword] = useState('');
  const [adminLoginError, setAdminLoginError] = useState<string | null>(null);

  const handleGoogleSignIn = async () => {
    try {
      setLoading(true);
      setError(null);
      await loginWithGoogle();
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      if (msg.includes('popup-closed-by-user')) {
        setError('Sign-in cancelled. Please click "Continue with Google" to log in.');
      } else {
        setError('Google authentication failed. Please try again or check network connectivity.');
      }
    } finally {
      setLoading(false);
    }
  };

  const handleAdminCredentialsLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setAdminLoginError(null);
    setLoading(true);
    try {
      const ok = await loginWithAdminCredentials(adminEmail, adminPassword);
      if (!ok) {
        setAdminLoginError('Ghalat Email ya Password. Barah-e-karam apna durust password darj karein.');
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className={`min-h-screen flex flex-col justify-between ${darkMode ? 'bg-[#0B0F19] text-white' : 'bg-slate-50 text-slate-900'} transition-colors duration-200`}>
      {/* Top Brand Bar */}
      <header className="px-6 py-5 flex items-center justify-between max-w-7xl mx-auto w-full">
        <div className="flex items-center gap-3">
          <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-blue-600 via-indigo-600 to-teal-400 flex items-center justify-center shadow-lg shadow-blue-500/25 ring-1 ring-white/20">
            <span className="text-white font-black text-2xl tracking-tighter">S1</span>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-2xl font-black tracking-tight bg-gradient-to-r from-blue-500 via-indigo-400 to-teal-400 bg-clip-text text-transparent">
                SocialOne
              </span>
              <span className="px-2 py-0.5 rounded-full text-[11px] font-semibold bg-blue-500/10 text-blue-400 border border-blue-500/20">
                Official
              </span>
            </div>
            <p className="text-xs text-slate-400 font-medium hidden sm:block">
              All-In-One Unified Social Platform
            </p>
          </div>
        </div>

        <div className="text-xs font-medium text-slate-400 flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
          <span>Intekhab Alam — Founder & CEO</span>
        </div>
      </header>

      {/* Main Hero & Login Box */}
      <main className="flex-1 max-w-7xl mx-auto w-full px-6 py-8 flex flex-col lg:flex-row items-center justify-center gap-12 lg:gap-16">
        {/* Left Side: Brand Vision & Pillars */}
        <div className="flex-1 max-w-2xl space-y-8 text-center lg:text-left">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 text-xs font-semibold">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Next Generation Social Ecosystem</span>
          </div>

          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight leading-[1.15]">
            Four Iconic Worlds.{' '}
            <span className="bg-gradient-to-r from-blue-500 via-purple-500 to-teal-400 bg-clip-text text-transparent">
              One Single Home.
            </span>
          </h1>

          <p className="text-base sm:text-lg text-slate-400 leading-relaxed font-normal">
            No more switching between separate apps. SocialOne combines TikTok vertical video feeds, Facebook social communities & posts, Instagram stories & photos, and WhatsApp encrypted direct chats & WebRTC calls.
          </p>

          {/* 4 Pillars Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-left pt-2">
            <div className={`p-4 rounded-2xl border ${darkMode ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200'} backdrop-blur-sm transition-all hover:border-blue-500/40`}>
              <div className="w-10 h-10 rounded-xl bg-blue-500/10 text-blue-500 flex items-center justify-center mb-3">
                <Play className="w-5 h-5 fill-current" />
              </div>
              <h3 className="font-bold text-sm">TikTok Shorts & Reels</h3>
              <p className="text-xs text-slate-400 mt-1">Vertical swipeable video stream, trending music metadata & sound clips.</p>
            </div>

            <div className={`p-4 rounded-2xl border ${darkMode ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200'} backdrop-blur-sm transition-all hover:border-purple-500/40`}>
              <div className="w-10 h-10 rounded-xl bg-purple-500/10 text-purple-500 flex items-center justify-center mb-3">
                <Users className="w-5 h-5" />
              </div>
              <h3 className="font-bold text-sm">Communities & Feed</h3>
              <p className="text-xs text-slate-400 mt-1">Facebook-style interactive posts, groups, creator pages, and discussions.</p>
            </div>

            <div className={`p-4 rounded-2xl border ${darkMode ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200'} backdrop-blur-sm transition-all hover:border-teal-500/40`}>
              <div className="w-10 h-10 rounded-xl bg-teal-500/10 text-teal-400 flex items-center justify-center mb-3">
                <Globe2 className="w-5 h-5" />
              </div>
              <h3 className="font-bold text-sm">Photos & 24h Stories</h3>
              <p className="text-xs text-slate-400 mt-1">Instagram-style photo carousels, gradient story rings, and quick reactions.</p>
            </div>

            <div className={`p-4 rounded-2xl border ${darkMode ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200'} backdrop-blur-sm transition-all hover:border-emerald-500/40`}>
              <div className="w-10 h-10 rounded-xl bg-emerald-500/10 text-emerald-400 flex items-center justify-center mb-3">
                <MessageCircle className="w-5 h-5" />
              </div>
              <h3 className="font-bold text-sm">Chats & WebRTC Calls</h3>
              <p className="text-xs text-slate-400 mt-1">WhatsApp-style direct messaging, voice notes, and real-time audio/video calls.</p>
            </div>
          </div>
        </div>

        {/* Right Side: Mandatory Google Auth Portal */}
        <div className="w-full max-w-md">
          <div className={`p-8 sm:p-10 rounded-3xl border shadow-2xl relative overflow-hidden ${darkMode ? 'bg-slate-900/90 border-slate-800/80 shadow-blue-500/5' : 'bg-white border-slate-200 shadow-slate-200'}`}>
            <div className="absolute top-0 right-0 left-0 h-1.5 bg-gradient-to-r from-blue-500 via-purple-500 to-teal-400" />

            <div className="text-center space-y-2 mb-8">
              <div className="inline-flex p-3 rounded-2xl bg-gradient-to-br from-blue-500/10 to-indigo-500/10 border border-blue-500/20 text-blue-500 mb-2">
                <Shield className="w-7 h-7" />
              </div>
              <h2 className="text-2xl font-bold tracking-tight">Welcome to SocialOne</h2>
              <p className="text-sm text-slate-400">
                Mandatory Google Authentication is required to access your unified feed, videos, private chats, and calls.
              </p>
            </div>

            {error && (
              <div className="mb-6 p-4 rounded-xl bg-rose-500/10 border border-rose-500/20 text-rose-400 text-xs leading-relaxed space-y-2">
                <p>{error}</p>
                <button
                  type="button"
                  onClick={() => loginAsFounder()}
                  className="w-full py-2 px-3 rounded-lg bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 font-bold text-xs border border-amber-500/40 cursor-pointer"
                >
                  🚀 Enter directly as Intekhab Alam (Founder & CEO)
                </button>
              </div>
            )}

            {/* Direct 1-Click Founder & CEO Login */}
            <div className="space-y-3">
              <button
                type="button"
                onClick={() => loginAsFounder()}
                className="w-full py-3.5 px-5 rounded-2xl font-bold text-sm flex items-center justify-center gap-3 transition-all duration-200 shadow-xl cursor-pointer bg-gradient-to-r from-amber-500 via-rose-500 to-indigo-600 hover:opacity-95 text-white ring-2 ring-amber-400/30 hover:scale-[1.01] active:scale-[0.99]"
              >
                <Shield className="w-5 h-5 text-amber-200" />
                <span>Enter as Intekhab Alam (Founder & CEO)</span>
              </button>

              {/* Admin Panel Specific Password Login */}
              <div className="rounded-2xl border border-amber-500/30 bg-amber-500/5 p-3 space-y-2">
                <button
                  type="button"
                  onClick={() => setShowAdminLogin(!showAdminLogin)}
                  className="w-full text-left flex items-center justify-between text-xs font-bold text-amber-300 hover:text-amber-200 cursor-pointer"
                >
                  <span className="flex items-center gap-1.5">
                    <Shield className="w-4 h-4 text-amber-400" />
                    Admin Portal (Secure Login)
                  </span>
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30">
                    {showAdminLogin ? 'Hide' : 'Password Login'}
                  </span>
                </button>

                {showAdminLogin && (
                  <form onSubmit={handleAdminCredentialsLogin} className="space-y-2 pt-1 text-left">
                    {adminLoginError && (
                      <p className="text-[11px] font-bold text-rose-400 bg-rose-500/10 p-2 rounded-lg border border-rose-500/20">
                        {adminLoginError}
                      </p>
                    )}
                    <div>
                      <label className="block text-[10px] font-bold text-slate-300 mb-0.5">Admin Email:</label>
                      <input
                        type="email"
                        value={adminEmail}
                        onChange={(e) => setAdminEmail(e.target.value)}
                        placeholder="Admin Email"
                        className="w-full px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-700 text-white font-mono text-xs outline-none focus:border-amber-400"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold text-slate-300 mb-0.5">Password / PIN:</label>
                      <input
                        type="password"
                        value={adminPassword}
                        onChange={(e) => setAdminPassword(e.target.value)}
                        placeholder="••••••••••••"
                        className="w-full px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-700 text-white font-mono text-xs outline-none focus:border-amber-400 tracking-wider"
                        required
                      />
                    </div>
                    <button
                      type="submit"
                      disabled={loading}
                      className="w-full py-2 px-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs cursor-pointer shadow-md transition-colors"
                    >
                      {loading ? 'Verifying...' : 'Login to Admin Panel'}
                    </button>
                  </form>
                )}
              </div>

              {/* Mobile Phone OTP Login */}
              <button
                type="button"
                onClick={() => setShowTikTokIdModal(true)}
                className="w-full py-3 px-4 rounded-2xl font-bold text-xs flex items-center justify-center gap-2.5 transition-all duration-200 shadow-lg cursor-pointer bg-gradient-to-r from-emerald-600 to-teal-600 hover:opacity-95 text-white ring-2 ring-emerald-500/30 hover:scale-[1.01] active:scale-[0.99]"
              >
                <Sparkles className="w-4 h-4 text-emerald-200" />
                <span>Mobile Number Se ID Banayein (OTP Verification)</span>
              </button>

              {/* 1-Click Create Custom TikTok ID */}
              <button
                type="button"
                onClick={() => setShowTikTokIdModal(true)}
                className="w-full py-3 px-4 rounded-2xl font-bold text-xs flex items-center justify-center gap-2.5 transition-all duration-200 shadow-lg cursor-pointer bg-gradient-to-r from-rose-600 via-pink-600 to-indigo-600 hover:opacity-95 text-white ring-2 ring-rose-500/30 hover:scale-[1.01] active:scale-[0.99]"
              >
                <Sparkles className="w-4 h-4 text-amber-300" />
                <span>Create TikTok Creator ID (+500 Coins)</span>
              </button>

              <button
                type="button"
                onClick={() => loginAsDemoUser()}
                className={`w-full py-2.5 px-4 rounded-2xl font-semibold text-xs flex items-center justify-center gap-2 transition-all cursor-pointer border ${
                  darkMode
                    ? 'bg-slate-800/80 border-slate-700 text-slate-200 hover:bg-slate-700'
                    : 'bg-slate-100 border-slate-300 text-slate-700 hover:bg-slate-200'
                }`}
              >
                <Sparkles className="w-4 h-4 text-teal-400" />
                <span>Explore as Verified Creator Demo</span>
              </button>

              <div className="relative flex items-center justify-center my-3">
                <span className="h-px bg-slate-800 w-full" />
                <span className="px-3 text-[11px] text-slate-400 uppercase font-bold shrink-0">
                  Or Google Account
                </span>
                <span className="h-px bg-slate-800 w-full" />
              </div>

              {/* Official Google Sign-In Button */}
              <button
                onClick={handleGoogleSignIn}
                disabled={loading}
                className="w-full py-3 px-5 rounded-2xl font-semibold text-xs flex items-center justify-center gap-3 transition-all duration-200 shadow-sm cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed bg-white text-slate-800 hover:bg-slate-100 border border-slate-300 hover:scale-[1.01] active:scale-[0.99]"
              >
                {loading ? (
                  <div className="w-4 h-4 border-2 border-slate-400 border-t-blue-600 rounded-full animate-spin" />
                ) : (
                  <svg className="w-4 h-4" viewBox="0 0 24 24">
                    <path
                      fill="#4285F4"
                      d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                    />
                    <path
                      fill="#34A853"
                      d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                    />
                    <path
                      fill="#FBBC05"
                      d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                    />
                    <path
                      fill="#EA4335"
                      d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                    />
                  </svg>
                )}
                <span className="text-slate-800 font-semibold">
                  {loading ? 'Authenticating...' : 'Continue with Google'}
                </span>
              </button>
            </div>

            {/* Privacy and Verification Highlights */}
            <div className="mt-6 pt-6 border-t border-slate-800/60 space-y-2.5 text-xs text-slate-400">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>Zero guest bypass — genuine verified community</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-blue-400 shrink-0" />
                <span>Minimum Google permissions (profile & email only)</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-purple-400 shrink-0" />
                <span>Real-time cloud database & WebRTC calls enabled</span>
              </div>
            </div>

            <div className="mt-6 text-center text-[11px] text-slate-500">
              By continuing, you agree to SocialOne’s Community Guidelines and Privacy Policy. Controlled by Intekhab Alam — Founder & CEO.
            </div>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="px-6 py-6 border-t border-slate-800/40 text-center text-xs text-slate-400 flex flex-col sm:flex-row items-center justify-between max-w-7xl mx-auto w-full gap-4">
        <div>
          © {new Date().getFullYear()} <strong className="text-slate-300">SocialOne</strong>. Owned by Intekhab Alam — Founder & CEO. All rights reserved.
        </div>
        <div className="flex items-center gap-6">
          <span>Shorts</span>
          <span>Community Feed</span>
          <span>Stories</span>
          <span>Encrypted Chat</span>
          <span>WebRTC Calling</span>
        </div>
      </footer>

      {/* TikTok ID Creation Modal */}
      <TikTokIdModal
        isOpen={showTikTokIdModal}
        onClose={() => setShowTikTokIdModal(false)}
      />
    </div>
  );
};
