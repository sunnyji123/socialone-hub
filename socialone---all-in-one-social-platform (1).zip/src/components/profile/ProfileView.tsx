import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useApp } from '../../context/AppContext';
import {
  User,
  Settings,
  Grid,
  Bookmark,
  Heart,
  Share2,
  LogOut,
  Sparkles,
  Download,
  Edit3,
  Check,
  ShieldCheck,
  Radio,
  Gift,
  DollarSign,
  Wallet,
  ArrowUpRight,
  CheckCircle2,
  Coins,
  Fuel,
  Camera,
} from 'lucide-react';
import { AdminPictureModal } from '../admin/AdminPictureModal';

export const ProfileView: React.FC = () => {
  const { userProfile, updateProfileDetails, logout, darkMode, isAdmin, gainFollowers } = useAuth();
  const {
    posts,
    videos,
    setActiveTab,
    startLiveStream,
    setIsLiveModalOpen,
    setIsCoinStoreOpen,
    setIsTikTokIdModalOpen,
    setIsCreatorCashoutOpen,
    setIsPrivacyModalOpen,
  } = useApp();

  const [activeTab, setActiveProfileTab] = useState<'posts' | 'saved' | 'likes' | 'about'>('posts');
  const [isEditing, setIsEditing] = useState(false);
  const [editName, setEditName] = useState(userProfile?.displayName || '');
  const [editBio, setEditBio] = useState(userProfile?.bio || '');
  const [editUsername, setEditUsername] = useState(userProfile?.username || '');
  const [savedSuccess, setSavedSuccess] = useState(false);
  const [boostSuccess, setBoostSuccess] = useState(false);
  const [cashoutModalOpen, setCashoutModalOpen] = useState(false);
  const [cashoutSuccess, setCashoutSuccess] = useState(false);
  const [payoutMethod, setPayoutMethod] = useState<'jazzcash' | 'easypaisa' | 'bank'>('jazzcash');
  const [payoutNumber, setPayoutNumber] = useState('03701220965');
  const [payoutAccountName, setPayoutAccountName] = useState(userProfile?.displayName || 'Intekhab Alam');
  const [payoutAmount, setPayoutAmount] = useState('10');
  const [payoutTrxId, setPayoutTrxId] = useState('');
  const [isPictureModalOpen, setIsPictureModalOpen] = useState(false);

  // User posts
  const myPosts = posts.filter((p) => p.authorId === userProfile?.uid);
  const mySavedPosts = posts.filter((p) => userProfile?.savedPostIds?.includes(p.id));

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    await updateProfileDetails({
      displayName: editName.trim() || userProfile?.displayName,
      bio: editBio.trim(),
      username: editUsername.trim().toLowerCase().replace(/[^a-z0-9_.]/g, '') || userProfile?.username,
    });
    setIsEditing(false);
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 2500);
  };

  const handleInstallPWA = () => {
    alert(
      'SocialOne PWA: To install SocialOne on your device, tap Share / Settings in your browser and select "Add to Home Screen" or click the Install icon in the browser address bar.'
    );
  };

  return (
    <div className="max-w-4xl mx-auto w-full pb-20 space-y-6">
      {/* Profile Header Card */}
      <div
        className={`rounded-3xl border overflow-hidden shadow-xs transition-colors ${
          darkMode ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200'
        }`}
      >
        {/* Cover Photo */}
        <div className="h-44 sm:h-56 w-full relative bg-gradient-to-r from-blue-600 via-indigo-600 to-teal-400">
          <div className="absolute inset-0 bg-black/20" />
        </div>

        {/* Profile Info Row */}
        <div className="px-6 pb-6 pt-0 relative">
          <div className="flex flex-col sm:flex-row items-start sm:items-end justify-between gap-4 -mt-16 sm:-mt-20 mb-4">
            {/* Avatar */}
            <div className="relative group">
              <img
                src={
                  userProfile?.photoURL ||
                  'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&auto=format&fit=crop&q=80'
                }
                alt={userProfile?.displayName}
                className="w-28 h-28 sm:w-32 sm:h-32 rounded-3xl object-cover ring-4 ring-[#0B0F19] shadow-xl bg-slate-800"
              />
              <span className="absolute bottom-2 right-2 w-4 h-4 rounded-full bg-emerald-500 ring-2 ring-[#0B0F19]" />
              <button
                type="button"
                onClick={() => setIsPictureModalOpen(true)}
                className="absolute inset-0 bg-black/40 rounded-3xl opacity-0 group-hover:opacity-100 flex flex-col items-center justify-center gap-1 transition-opacity text-white text-xs font-semibold cursor-pointer backdrop-blur-[2px]"
                title="Change Profile / Admin Picture"
              >
                <Camera className="w-5 h-5 text-white" />
                <span className="text-[10px]">Change Photo</span>
              </button>
            </div>

            {/* Action Buttons */}
            <div className="flex items-center gap-2 w-full sm:w-auto flex-wrap">
              <button
                onClick={() => setIsTikTokIdModalOpen(true)}
                className="px-3.5 py-2 rounded-2xl text-xs font-bold bg-gradient-to-r from-rose-600 to-indigo-600 hover:opacity-95 text-white shadow-sm flex items-center gap-1.5 cursor-pointer"
                title="Create or Switch TikTok ID"
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>TikTok ID</span>
              </button>

              <button
                onClick={() => setIsPrivacyModalOpen(true)}
                className="px-3.5 py-2 rounded-2xl text-xs font-bold bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-300 border border-emerald-500/30 flex items-center gap-1.5 cursor-pointer"
                title="WhatsApp & TikTok Privacy Settings"
              >
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                <span>Privacy</span>
              </button>

              <button
                onClick={() => setIsCoinStoreOpen(true)}
                className="px-3 py-2 rounded-2xl text-xs font-bold bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 flex items-center gap-1.5 cursor-pointer"
                title="Buy / Recharge SocialOne Coins (JazzCash & EasyPaisa)"
              >
                <Coins className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />
                <span>{(userProfile?.coinsBalance || 0).toLocaleString()} Coins</span>
              </button>

              <button
                onClick={() => setIsEditing(!isEditing)}
                className={`flex-1 sm:flex-none px-4 py-2 rounded-2xl text-xs font-bold border transition-colors flex items-center justify-center gap-1.5 cursor-pointer ${
                  darkMode
                    ? 'bg-slate-800 hover:bg-slate-700 border-slate-700 text-white'
                    : 'bg-slate-100 hover:bg-slate-200 border-slate-300 text-slate-800'
                }`}
              >
                <Edit3 className="w-3.5 h-3.5" />
                <span>Edit</span>
              </button>

              <button
                onClick={handleInstallPWA}
                className="px-4 py-2 rounded-2xl text-xs font-bold bg-indigo-600 hover:bg-indigo-500 text-white shadow-sm flex items-center gap-1.5 cursor-pointer"
                title="Install Progressive Web App on iPhone/Android/PC"
              >
                <Download className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Install App</span>
              </button>

              <button
                onClick={() => logout()}
                className="p-2 rounded-2xl text-rose-400 hover:bg-rose-500/10 transition-colors cursor-pointer"
                title="Sign Out"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* User Names & Bio */}
          <div className="space-y-1">
            <div className="flex items-center gap-2 flex-wrap">
              <h2 className="text-xl sm:text-2xl font-black">{userProfile?.displayName}</h2>
              {userProfile?.uid === 'intekhab-alam-founder' && (
                <span className="inline-flex items-center gap-1 text-[10px] font-bold text-white bg-gradient-to-r from-blue-600 to-indigo-600 px-2 py-0.5 rounded-full shadow-xs">
                  <Sparkles className="w-2.5 h-2.5" />
                  Founder & CEO
                </span>
              )}
              {isAdmin && userProfile?.uid !== 'intekhab-alam-founder' && (
                <span className="inline-flex items-center gap-1 text-[10px] font-bold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-full border border-emerald-500/30">
                  <ShieldCheck className="w-2.5 h-2.5" />
                  Admin
                </span>
              )}
            </div>
            <p className="text-xs text-slate-400">@{userProfile?.username}</p>
            <p className="text-xs sm:text-sm text-slate-300 pt-2 font-normal max-w-xl leading-relaxed">
              {userProfile?.bio || 'Exploring SocialOne — the unified all-in-one social platform.'}
            </p>
          </div>

          {/* Followers & Social Metrics */}
          <div className="flex items-center gap-6 pt-4 text-xs">
            <div>
              <strong className="font-bold text-sm text-white">{myPosts.length}</strong>{' '}
              <span className="text-slate-400">Posts</span>
            </div>
            <div>
              <strong className="font-bold text-sm text-white">
                {userProfile?.followersCount || 1}
              </strong>{' '}
              <span className="text-slate-400">Followers</span>
            </div>
            <div>
              <strong className="font-bold text-sm text-white">
                {userProfile?.followingCount || 1}
              </strong>{' '}
              <span className="text-slate-400">Following</span>
            </div>
          </div>
        </div>
      </div>

      {/* TikTok Live Qualification & Creator Wallet Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Card 1: TikTok Live Streaming Eligibility */}
        <div
          className={`p-5 rounded-3xl border space-y-3 transition-colors ${
            darkMode ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200 shadow-xs'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="flex items-center gap-2 font-bold text-xs uppercase tracking-wider text-rose-400">
              <Radio className="w-4 h-4 animate-pulse" />
              TikTok Live Broadcast
            </span>
            {(userProfile?.followersCount || 1) >= 100 || isAdmin ? (
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 flex items-center gap-1">
                <CheckCircle2 className="w-3 h-3" />
                Unlocked
              </span>
            ) : (
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-rose-500/10 text-rose-400 border border-rose-500/30">
                100 Followers Needed
              </span>
            )}
          </div>

          <div className="space-y-1.5">
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-400 font-medium">Follower Goal Progress:</span>
              <strong className="text-white font-bold">{userProfile?.followersCount || 1} / 100</strong>
            </div>
            <div className="w-full h-2 rounded-full bg-slate-800 overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-rose-500 via-indigo-500 to-emerald-400 rounded-full transition-all duration-500"
                style={{ width: `${Math.min(100, ((userProfile?.followersCount || 1) / 100) * 100)}%` }}
              />
            </div>
          </div>

          <p className="text-xs text-slate-400 leading-relaxed">
            {(userProfile?.followersCount || 1) >= 100 || isAdmin
              ? 'Congratulations! You have reached 100 followers. You can broadcast live video and receive real monetary gifts anytime.'
              : 'TikTok Live requires 100 followers before you can broadcast live video and receive gifts.'}
          </p>

          <div className="flex items-center gap-2 pt-1">
            {(userProfile?.followersCount || 1) >= 100 || isAdmin ? (
              <button
                onClick={() => startLiveStream(`${userProfile?.displayName || 'Creator'}'s Live Session 🔴`)}
                className="w-full py-2.5 rounded-2xl bg-gradient-to-r from-rose-600 to-red-600 hover:opacity-90 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-lg cursor-pointer active:scale-95 transition-all"
              >
                <Radio className="w-4 h-4" />
                <span>Start TikTok Live Stream Now</span>
              </button>
            ) : (
              <button
                onClick={async () => {
                  await gainFollowers(25);
                  setBoostSuccess(true);
                  setTimeout(() => setBoostSuccess(false), 2000);
                }}
                className="w-full py-2.5 rounded-2xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-md cursor-pointer active:scale-95 transition-all"
              >
                <Sparkles className="w-4 h-4" />
                <span>{boostSuccess ? 'Added 25 Followers! 🎉' : 'Boost Followers (+25 Test)'}</span>
              </button>
            )}
          </div>
        </div>

        {/* Card 2: Creator Wallet & Gifting Revenue */}
        <div
          className={`p-5 rounded-3xl border space-y-3 transition-colors ${
            darkMode ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200 shadow-xs'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="flex items-center gap-2 font-bold text-xs uppercase tracking-wider text-amber-400">
              <Wallet className="w-4 h-4" />
              Creator Live Wallet
            </span>
            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-500/10 text-amber-300 border border-amber-500/30">
              75% Creator Share
            </span>
          </div>

          <div className="flex items-baseline justify-between pt-1">
            <div>
              <p className="text-[11px] text-slate-400 font-medium">Available Balance</p>
              <h3 className="text-2xl font-black text-emerald-400">
                ${(userProfile?.walletBalance || 0).toFixed(2)}{' '}
                <span className="text-xs text-slate-400 font-normal">USD</span>
              </h3>
            </div>
            <div className="text-right">
              <p className="text-[11px] text-slate-400 font-medium">Total Gifts Earned</p>
              <p className="text-sm font-bold text-slate-200">
                ${(userProfile?.totalGiftsEarned || 0).toFixed(2)} USD
              </p>
            </div>
          </div>

          <p className="text-xs text-slate-400 leading-relaxed">
            Viewers gift Roses, Hearts, Diamonds, Galaxies, & Lions. You receive 75% instantly, and 25% Platform Commission supports platform owner Intekhab Alam.
          </p>

          <div className="pt-1">
            <button
              onClick={() => setIsCreatorCashoutOpen(true)}
              className="w-full py-2.5 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:opacity-90 text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-md cursor-pointer active:scale-95 transition-all"
            >
              <Fuel className="w-4 h-4 text-amber-300" />
              <span>Withdraw / Petrol Le Sakte Hain (JazzCash & EasyPaisa)</span>
            </button>
          </div>
        </div>
      </div>

      {/* Cashout Simulation Modal */}
      {cashoutModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="max-w-md w-full bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-4 shadow-2xl text-white">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <h3 className="font-black text-base flex items-center gap-2">
                <Wallet className="w-5 h-5 text-emerald-400" />
                <span>Withdraw Creator Earnings</span>
              </h3>
              <button
                onClick={() => {
                  setCashoutModalOpen(false);
                  setCashoutSuccess(false);
                }}
                className="text-slate-400 hover:text-white"
              >
                ✕
              </button>
            </div>

            {cashoutSuccess ? (
              <div className="py-4 text-center space-y-3">
                <div
                  className={`w-14 h-14 rounded-full mx-auto flex items-center justify-center ${
                    payoutMethod === 'jazzcash'
                      ? 'bg-rose-500/20 text-rose-400'
                      : 'bg-emerald-500/20 text-emerald-400'
                  }`}
                >
                  <CheckCircle2 className="w-8 h-8" />
                </div>
                <h4 className="text-lg font-bold text-white">Instant Payout Disbursed!</h4>
                <p className="text-xs text-slate-300">
                  Rs. {(parseFloat(payoutAmount || '10') * 280).toLocaleString()} PKR has been successfully transferred
                  to your {payoutMethod === 'jazzcash' ? 'JazzCash' : payoutMethod === 'easypaisa' ? 'EasyPaisa' : 'Bank'}{' '}
                  account ({payoutNumber}).
                </p>
                <div className="p-3 rounded-2xl bg-black/40 border border-white/10 text-left text-xs font-mono space-y-1 text-slate-300">
                  <div className="flex justify-between">
                    <span className="text-slate-400">Trx ID:</span>
                    <span className="text-amber-400 font-bold">{payoutTrxId || 'JC-902849182'}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Account:</span>
                    <span>{payoutNumber}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Status:</span>
                    <span className="text-emerald-400 font-bold">Credited Instantly</span>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    setCashoutModalOpen(false);
                    setCashoutSuccess(false);
                  }}
                  className="w-full py-2.5 rounded-2xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs cursor-pointer"
                >
                  Done
                </button>
              </div>
            ) : (
              <>
                <div className="bg-slate-800/80 p-4 rounded-2xl border border-slate-700/60 space-y-1">
                  <span className="text-xs text-slate-400">Available Creator Balance:</span>
                  <div className="flex items-baseline justify-between">
                    <p className="text-2xl font-black text-emerald-400">
                      ${(userProfile?.walletBalance || 0).toFixed(2)} USD
                    </p>
                    <span className="text-xs font-bold text-emerald-300">
                      ≈ Rs. {Math.round((userProfile?.walletBalance || 0) * 280).toLocaleString()} PKR
                    </span>
                  </div>
                  <p className="text-[10px] text-slate-400">Net payout after 25% owner platform fee</p>
                </div>

                {/* Founder shortcut if applicable */}
                {(isAdmin || userProfile?.uid === 'intekhab-alam-founder') && (
                  <div className="p-3 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-between text-xs">
                    <div>
                      <span className="font-bold text-amber-300 block">Intekhab Alam (Founder &amp; CEO):</span>
                      <span className="text-[10px] text-slate-300">Access your 25% platform live gift treasury.</span>
                    </div>
                    <button
                      type="button"
                      onClick={() => {
                        setCashoutModalOpen(false);
                        setActiveTab('admin');
                      }}
                      className="px-3 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-[11px] cursor-pointer"
                    >
                      Admin Treasury →
                    </button>
                  </div>
                )}

                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-slate-300">Select Payout Wallet:</label>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={() => setPayoutMethod('jazzcash')}
                      className={`p-3 rounded-2xl border text-left text-xs font-bold cursor-pointer transition-colors ${
                        payoutMethod === 'jazzcash'
                          ? 'bg-rose-950/60 border-rose-500 text-white'
                          : 'bg-slate-800 border-slate-700 text-slate-400 hover:bg-slate-750'
                      }`}
                    >
                      <div className="text-base mb-0.5">🔴 JazzCash</div>
                      <span className="text-[10px] font-normal text-slate-400">Instant Mobile Account</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setPayoutMethod('easypaisa')}
                      className={`p-3 rounded-2xl border text-left text-xs font-bold cursor-pointer transition-colors ${
                        payoutMethod === 'easypaisa'
                          ? 'bg-emerald-950/60 border-emerald-500 text-white'
                          : 'bg-slate-800 border-slate-700 text-slate-400 hover:bg-slate-750'
                      }`}
                    >
                      <div className="text-base mb-0.5">🟢 EasyPaisa</div>
                      <span className="text-[10px] font-normal text-slate-400">Instant Telenor Wallet</span>
                    </button>
                  </div>
                </div>

                {/* Account Details */}
                <div className="space-y-2 text-xs">
                  <div>
                    <label className="block text-[11px] text-slate-400 mb-1">
                      {payoutMethod === 'jazzcash' ? 'JazzCash' : 'EasyPaisa'} Mobile Number (03XXXXXXXXX)
                    </label>
                    <div className="relative">
                      <span className="absolute left-3 top-2.5 text-slate-400 font-semibold text-[11px]">🇵🇰 +92</span>
                      <input
                        type="text"
                        value={payoutNumber}
                        onChange={(e) => setPayoutNumber(e.target.value)}
                        placeholder="03017654321"
                        maxLength={13}
                        className="w-full pl-16 pr-4 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white font-mono outline-none"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-[11px] text-slate-400 mb-1">Account Title / Full Name</label>
                    <input
                      type="text"
                      value={payoutAccountName}
                      onChange={(e) => setPayoutAccountName(e.target.value)}
                      placeholder="Intekhab Alam"
                      className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] text-slate-400 mb-1">Withdraw Amount (USD)</label>
                    <input
                      type="number"
                      step="1"
                      min="1"
                      value={payoutAmount}
                      onChange={(e) => setPayoutAmount(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white font-bold outline-none"
                    />
                    <p className="text-[10px] text-emerald-400 font-semibold mt-1">
                      You will receive: Rs. {(parseFloat(payoutAmount || '0') * 280).toLocaleString()} PKR (Exchange rate: 1 USD = 280 PKR)
                    </p>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => {
                    const prefix = payoutMethod === 'jazzcash' ? 'JC' : 'EP';
                    setPayoutTrxId(`${prefix}-${Math.floor(100000000 + Math.random() * 900000000)}`);
                    setCashoutSuccess(true);
                  }}
                  className={`w-full py-3 rounded-2xl text-white font-bold text-xs shadow-lg cursor-pointer transition-all ${
                    payoutMethod === 'jazzcash'
                      ? 'bg-rose-600 hover:bg-rose-500'
                      : 'bg-emerald-600 hover:bg-emerald-500'
                  }`}
                >
                  Withdraw Rs. {(parseFloat(payoutAmount || '10') * 280).toLocaleString()} PKR Now
                </button>
              </>
            )}
          </div>
        </div>
      )}

      {/* Edit Profile Form */}
      {isEditing && (
        <form
          onSubmit={handleSaveProfile}
          className={`p-6 rounded-3xl border space-y-4 shadow-xl ${
            darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'
          }`}
        >
          <h3 className="font-bold text-sm">Edit Your SocialOne Identity</h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs text-slate-400 mb-1">Display Name</label>
              <input
                type="text"
                value={editName}
                onChange={(e) => setEditName(e.target.value)}
                className={`w-full px-3 py-2 rounded-xl text-xs border outline-none ${
                  darkMode ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-100 border-slate-300 text-slate-900'
                }`}
              />
            </div>
            <div>
              <label className="block text-xs text-slate-400 mb-1">Username Handle</label>
              <input
                type="text"
                value={editUsername}
                onChange={(e) => setEditUsername(e.target.value)}
                className={`w-full px-3 py-2 rounded-xl text-xs border outline-none ${
                  darkMode ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-100 border-slate-300 text-slate-900'
                }`}
              />
            </div>
          </div>

          <div>
            <label className="block text-xs text-slate-400 mb-1">Bio</label>
            <textarea
              value={editBio}
              onChange={(e) => setEditBio(e.target.value)}
              rows={3}
              className={`w-full px-3 py-2 rounded-xl text-xs border outline-none ${
                darkMode ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-100 border-slate-300 text-slate-900'
              }`}
            />
          </div>

          <div className="flex items-center justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setIsEditing(false)}
              className="px-4 py-2 rounded-xl text-xs text-slate-400 hover:text-white cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-xl text-xs font-bold bg-blue-600 hover:bg-blue-500 text-white cursor-pointer shadow-sm"
            >
              Save Profile
            </button>
          </div>
        </form>
      )}

      {/* Tabs */}
      <div
        className={`flex items-center justify-around p-1 rounded-2xl border transition-colors ${
          darkMode ? 'bg-slate-900/60 border-slate-800' : 'bg-slate-100 border-slate-200'
        }`}
      >
        <button
          onClick={() => setActiveProfileTab('posts')}
          className={`flex-1 py-2 text-xs font-bold rounded-xl transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
            activeTab === 'posts'
              ? darkMode
                ? 'bg-blue-600 text-white'
                : 'bg-white text-slate-900 shadow-sm'
              : 'text-slate-400'
          }`}
        >
          <Grid className="w-3.5 h-3.5" />
          <span>My Posts ({myPosts.length})</span>
        </button>

        <button
          onClick={() => setActiveProfileTab('saved')}
          className={`flex-1 py-2 text-xs font-bold rounded-xl transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
            activeTab === 'saved'
              ? darkMode
                ? 'bg-blue-600 text-white'
                : 'bg-white text-slate-900 shadow-sm'
              : 'text-slate-400'
          }`}
        >
          <Bookmark className="w-3.5 h-3.5" />
          <span>Saved ({mySavedPosts.length})</span>
        </button>

        <button
          onClick={() => setActiveProfileTab('about')}
          className={`flex-1 py-2 text-xs font-bold rounded-xl transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
            activeTab === 'about'
              ? darkMode
                ? 'bg-blue-600 text-white'
                : 'bg-white text-slate-900 shadow-sm'
              : 'text-slate-400'
          }`}
        >
          <Sparkles className="w-3.5 h-3.5" />
          <span>Platform & Owner</span>
        </button>
      </div>

      {/* Tab Content */}
      {activeTab === 'posts' && (
        <div className="space-y-4">
          {myPosts.length === 0 ? (
            <div className="text-center py-12 text-slate-400 text-xs">
              You haven't posted yet. Tap "Create New Content" to publish your first post!
            </div>
          ) : (
            myPosts.map((post) => (
              <div
                key={post.id}
                className={`p-4 rounded-3xl border ${
                  darkMode ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200'
                }`}
              >
                <p className="text-xs text-slate-300 leading-relaxed">{post.content}</p>
                {post.mediaUrls?.[0] && (
                  <img
                    src={post.mediaUrls[0]}
                    alt="Post media"
                    className="w-full max-h-72 object-cover rounded-2xl mt-3"
                  />
                )}
                <div className="flex items-center gap-4 mt-3 text-xs text-slate-400">
                  <span>{post.likesCount} Likes</span>
                  <span>{post.commentsCount} Comments</span>
                </div>
              </div>
            ))
          )}
        </div>
      )}

      {activeTab === 'saved' && (
        <div className="space-y-4">
          {mySavedPosts.length === 0 ? (
            <div className="text-center py-12 text-slate-400 text-xs">
              No saved posts yet. Bookmark any post from your Home Feed to see it here!
            </div>
          ) : (
            mySavedPosts.map((post) => (
              <div
                key={post.id}
                className={`p-4 rounded-3xl border ${
                  darkMode ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200'
                }`}
              >
                <div className="flex items-center gap-2 mb-2">
                  <img
                    src={post.authorPhoto}
                    alt={post.authorName}
                    className="w-7 h-7 rounded-full object-cover"
                  />
                  <span className="font-bold text-xs">{post.authorName}</span>
                </div>
                <p className="text-xs text-slate-300">{post.content}</p>
              </div>
            ))
          )}
        </div>
      )}

      {activeTab === 'about' && (
        <div
          className={`p-6 rounded-3xl border space-y-4 text-xs text-slate-300 leading-relaxed ${
            darkMode ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200'
          }`}
        >
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-blue-600 via-indigo-600 to-teal-400 flex items-center justify-center text-white font-black text-xl">
              S1
            </div>
            <div>
              <h3 className="font-bold text-sm text-white">SocialOne Social Media Platform</h3>
              <p className="text-[11px] text-slate-400">Owned by Intekhab Alam — Founder & CEO</p>
            </div>
          </div>
          <p>
            SocialOne was built to eliminate the fragmentation of modern digital life. Instead of having to download and cycle through multiple different apps for vertical video shorts, community group discussions, photo stories, and direct messaging, SocialOne unifies them all with mandatory Google authentication, real-time Firestore synchronization, and WebRTC audio and video calling.
          </p>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-2 text-center">
            <div className="p-3 rounded-2xl bg-slate-800/60">
              <strong className="block text-white font-bold">1. Shorts</strong>
              <span className="text-[10px] text-slate-400">TikTok Style</span>
            </div>
            <div className="p-3 rounded-2xl bg-slate-800/60">
              <strong className="block text-white font-bold">2. Groups</strong>
              <span className="text-[10px] text-slate-400">Facebook Style</span>
            </div>
            <div className="p-3 rounded-2xl bg-slate-800/60">
              <strong className="block text-white font-bold">3. Stories</strong>
              <span className="text-[10px] text-slate-400">Instagram Style</span>
            </div>
            <div className="p-3 rounded-2xl bg-slate-800/60">
              <strong className="block text-white font-bold">4. WebRTC</strong>
              <span className="text-[10px] text-slate-400">WhatsApp Style</span>
            </div>
          </div>
        </div>
      )}

      {/* Admin / Profile Picture Changer Modal */}
      <AdminPictureModal
        isOpen={isPictureModalOpen}
        onClose={() => setIsPictureModalOpen(false)}
      />
    </div>
  );
};
