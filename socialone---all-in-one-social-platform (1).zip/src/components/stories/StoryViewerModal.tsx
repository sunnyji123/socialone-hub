import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { X, Heart, Send, ChevronLeft, ChevronRight } from 'lucide-react';
import confetti from 'canvas-confetti';

export const StoryViewerModal: React.FC = () => {
  const { stories, activeStoryIndex, setActiveStoryIndex, sendMessage } = useApp();
  const [progress, setProgress] = useState(0);
  const [isPaused, setIsPaused] = useState(false);
  const [replyText, setReplyText] = useState('');

  // Auto advancement timer - called unconditionally per Rules of Hooks
  useEffect(() => {
    setProgress(0);
    if (isPaused || activeStoryIndex === null || !stories[activeStoryIndex]) return;

    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          // Go to next story or close
          if (activeStoryIndex < stories.length - 1) {
            setActiveStoryIndex(activeStoryIndex + 1);
          } else {
            setActiveStoryIndex(null);
          }
          return 0;
        }
        return prev + 2; // ~5 seconds total
      });
    }, 100);

    return () => clearInterval(interval);
  }, [activeStoryIndex, isPaused, stories, setActiveStoryIndex]);

  if (activeStoryIndex === null || !stories[activeStoryIndex]) return null;

  const currentStory = stories[activeStoryIndex];

  const handlePrev = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (activeStoryIndex > 0) {
      setActiveStoryIndex(activeStoryIndex - 1);
    }
  };

  const handleNext = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (activeStoryIndex < stories.length - 1) {
      setActiveStoryIndex(activeStoryIndex + 1);
    } else {
      setActiveStoryIndex(null);
    }
  };

  const handleEmojiReaction = (emoji: string) => {
    confetti({
      particleCount: 25,
      spread: 60,
      origin: { y: 0.8 },
    });
    sendMessage(`Reacted ${emoji} to your story!`, 'text');
  };

  const handleSendReply = (e: React.FormEvent) => {
    e.preventDefault();
    if (!replyText.trim()) return;
    sendMessage(`Story reply: "${replyText.trim()}"`, 'text');
    setReplyText('');
    confetti({
      particleCount: 15,
      spread: 40,
      origin: { y: 0.85 },
    });
  };

  return (
    <div
      className="fixed inset-0 z-50 bg-black/90 backdrop-blur-xl flex items-center justify-center p-0 sm:p-4"
      onMouseDown={() => setIsPaused(true)}
      onMouseUp={() => setIsPaused(false)}
      onTouchStart={() => setIsPaused(true)}
      onTouchEnd={() => setIsPaused(false)}
    >
      {/* Close button */}
      <button
        onClick={() => setActiveStoryIndex(null)}
        className="absolute top-4 right-4 z-50 p-2.5 rounded-full bg-white/10 hover:bg-white/20 text-white cursor-pointer transition-colors"
      >
        <X className="w-6 h-6" />
      </button>

      {/* Navigation Arrows for desktop */}
      {activeStoryIndex > 0 && (
        <button
          onClick={handlePrev}
          className="hidden sm:flex absolute left-8 z-50 p-3 rounded-full bg-white/10 hover:bg-white/20 text-white cursor-pointer transition-colors"
        >
          <ChevronLeft className="w-6 h-6" />
        </button>
      )}

      {activeStoryIndex < stories.length - 1 && (
        <button
          onClick={handleNext}
          className="hidden sm:flex absolute right-8 z-50 p-3 rounded-full bg-white/10 hover:bg-white/20 text-white cursor-pointer transition-colors"
        >
          <ChevronRight className="w-6 h-6" />
        </button>
      )}

      {/* Story Container */}
      <div className="relative w-full max-w-sm sm:max-w-md h-full sm:h-[85vh] sm:rounded-3xl overflow-hidden shadow-2xl bg-slate-900 flex flex-col justify-between">
        {/* Progress Bars */}
        <div className="absolute top-3 left-3 right-3 z-30 flex items-center gap-1.5">
          {stories.map((s, idx) => (
            <div key={s.id} className="h-1 flex-1 bg-white/30 rounded-full overflow-hidden">
              <div
                className="h-full bg-white transition-all duration-100 ease-linear"
                style={{
                  width:
                    idx < activeStoryIndex
                      ? '100%'
                      : idx === activeStoryIndex
                      ? `${progress}%`
                      : '0%',
                }}
              />
            </div>
          ))}
        </div>

        {/* Author Header */}
        <div className="absolute top-6 left-4 right-4 z-30 flex items-center justify-between text-white drop-shadow">
          <div className="flex items-center gap-2.5">
            <img
              src={currentStory.authorPhoto}
              alt={currentStory.authorName}
              className="w-10 h-10 rounded-full object-cover ring-2 ring-white/50"
            />
            <div>
              <p className="font-bold text-xs">{currentStory.authorName}</p>
              <p className="text-[10px] text-white/70">
                {new Date(currentStory.createdAt).toLocaleTimeString([], {
                  hour: '2-digit',
                  minute: '2-digit',
                })}{' '}
                • 24h Story
              </p>
            </div>
          </div>
        </div>

        {/* Tap zones for left/right */}
        <div className="absolute inset-0 z-20 flex">
          <div className="w-1/3 h-full cursor-pointer" onClick={handlePrev} />
          <div className="w-2/3 h-full cursor-pointer" onClick={handleNext} />
        </div>

        {/* Story Media */}
        <div className="relative w-full h-full flex items-center justify-center bg-black">
          <img
            src={currentStory.mediaUrl}
            alt="Story content"
            className="w-full h-full object-cover"
          />

          {/* Caption overlay */}
          {currentStory.caption && (
            <div className="absolute bottom-20 left-4 right-4 z-30 p-3 rounded-2xl bg-black/50 backdrop-blur-md text-white text-xs text-center border border-white/10 font-medium">
              {currentStory.caption}
            </div>
          )}
        </div>

        {/* Bottom Reaction & Reply Bar */}
        <div className="absolute bottom-3 left-3 right-3 z-30 space-y-2">
          {/* Quick Reaction Emojis */}
          <div className="flex items-center justify-center gap-3 py-1">
            {['❤️', '🔥', '😂', '👏', '🎉', '😮'].map((emoji) => (
              <button
                key={emoji}
                onClick={(e) => {
                  e.stopPropagation();
                  handleEmojiReaction(emoji);
                }}
                className="w-8 h-8 rounded-full bg-black/40 hover:bg-black/60 hover:scale-125 text-base flex items-center justify-center transition-all cursor-pointer backdrop-blur-md"
              >
                {emoji}
              </button>
            ))}
          </div>

          {/* Reply Form */}
          <form
            onSubmit={handleSendReply}
            className="flex items-center gap-2"
            onClick={(e) => e.stopPropagation()}
          >
            <input
              type="text"
              value={replyText}
              onChange={(e) => setReplyText(e.target.value)}
              placeholder={`Reply to ${currentStory.authorName.split(' ')[0]}...`}
              className="flex-1 px-4 py-2.5 rounded-full bg-white/20 backdrop-blur-md text-white text-xs placeholder-white/70 border border-white/20 focus:outline-none focus:bg-white/30"
            />
            <button
              type="submit"
              className="p-2.5 rounded-full bg-blue-600 hover:bg-blue-500 text-white cursor-pointer transition-colors shadow-lg"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
