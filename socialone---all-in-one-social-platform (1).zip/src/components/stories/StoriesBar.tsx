import React from 'react';
import { useAuth } from '../../context/AuthContext';
import { useApp } from '../../context/AppContext';
import { Plus } from 'lucide-react';

export const StoriesBar: React.FC = () => {
  const { userProfile, darkMode } = useAuth();
  const { stories, setActiveStoryIndex, setIsCreateModalOpen } = useApp();

  return (
    <div
      className={`p-4 rounded-3xl border mb-6 overflow-x-auto no-scrollbar transition-colors ${
        darkMode ? 'bg-slate-900/40 border-slate-800/80' : 'bg-white border-slate-200 shadow-xs'
      }`}
    >
      <div className="flex items-center gap-4 min-w-max">
        {/* Current User: Add Story */}
        <div
          onClick={() => setIsCreateModalOpen(true)}
          className="flex flex-col items-center gap-1.5 cursor-pointer group select-none"
        >
          <div className="relative">
            <div className="w-16 h-16 rounded-full p-0.5 border-2 border-dashed border-blue-500/50 group-hover:border-blue-500 transition-colors flex items-center justify-center">
              <img
                src={
                  userProfile?.photoURL ||
                  'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&auto=format&fit=crop&q=80'
                }
                alt="Your story"
                className="w-full h-full rounded-full object-cover group-hover:scale-105 transition-transform"
              />
            </div>
            <div className="absolute -bottom-1 -right-1 w-5 h-5 rounded-full bg-gradient-to-r from-blue-600 to-indigo-600 text-white flex items-center justify-center shadow-md ring-2 ring-[#0B0F19]">
              <Plus className="w-3.5 h-3.5 stroke-[3]" />
            </div>
          </div>
          <span className="text-[11px] font-medium text-slate-400 group-hover:text-blue-500 transition-colors">
            Your Story
          </span>
        </div>

        {/* Existing Stories */}
        {stories.map((story, index) => {
          return (
            <div
              key={story.id}
              onClick={() => setActiveStoryIndex(index)}
              className="flex flex-col items-center gap-1.5 cursor-pointer group select-none"
            >
              <div className="relative">
                {/* Vibrant Gradient Ring */}
                <div className="w-16 h-16 rounded-full p-[2.5px] bg-gradient-to-tr from-teal-400 via-indigo-500 to-rose-500 group-hover:rotate-12 transition-all duration-300 shadow-md shadow-indigo-500/20">
                  <div
                    className={`w-full h-full rounded-full p-[2px] ${
                      darkMode ? 'bg-[#0B0F19]' : 'bg-white'
                    }`}
                  >
                    <img
                      src={story.authorPhoto}
                      alt={story.authorName}
                      className="w-full h-full rounded-full object-cover group-hover:scale-105 transition-transform"
                    />
                  </div>
                </div>
              </div>
              <span className="text-[11px] font-medium text-slate-400 max-w-[68px] truncate group-hover:text-slate-200 transition-colors">
                {story.authorName.split(' ')[0]}
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
};
