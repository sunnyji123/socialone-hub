import React, { useState, useEffect, useRef } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Mic,
  MicOff,
  Video as VideoIcon,
  VideoOff,
  PhoneOff,
  Phone,
  Maximize2,
  RefreshCw,
  Sparkles,
  Volume2,
} from 'lucide-react';

export const WebRTCCallModal: React.FC = () => {
  const { currentCall, answerCall, declineCall, endCall } = useApp();

  const [isMuted, setIsMuted] = useState(false);
  const [isVideoEnabled, setIsVideoEnabled] = useState(true);
  const [callDuration, setCallDuration] = useState(0);
  const [cameraFacing, setCameraFacing] = useState<'user' | 'environment'>('user');
  const [hasCameraPermission, setHasCameraPermission] = useState<boolean | null>(null);

  const localVideoRef = useRef<HTMLVideoElement | null>(null);
  const localStreamRef = useRef<MediaStream | null>(null);

  // Call duration timer
  useEffect(() => {
    let timer: any;
    if (currentCall?.status === 'active') {
      timer = setInterval(() => {
        setCallDuration((prev) => prev + 1);
      }, 1000);
    } else {
      setCallDuration(0);
    }
    return () => clearInterval(timer);
  }, [currentCall?.status]);

  // Request actual camera stream via WebRTC getUserMedia when in video call
  useEffect(() => {
    if (!currentCall) return;

    if (currentCall.type === 'video' && currentCall.status === 'active') {
      navigator.mediaDevices
        ?.getUserMedia({
          video: { facingMode: cameraFacing },
          audio: true,
        })
        .then((stream) => {
          localStreamRef.current = stream;
          setHasCameraPermission(true);
          if (localVideoRef.current) {
            localVideoRef.current.srcObject = stream;
          }
        })
        .catch((err) => {
          console.warn('WebRTC camera preview fallback active:', err.message);
          setHasCameraPermission(false);
        });
    }

    return () => {
      // Clean up stream tracks on call exit
      if (localStreamRef.current) {
        localStreamRef.current.getTracks().forEach((track) => track.stop());
      }
    };
  }, [currentCall?.status, currentCall?.type, cameraFacing]);

  // Toggle microphone
  const toggleMute = () => {
    if (localStreamRef.current) {
      localStreamRef.current.getAudioTracks().forEach((track) => {
        track.enabled = isMuted;
      });
    }
    setIsMuted(!isMuted);
  };

  // Toggle camera
  const toggleVideo = () => {
    if (localStreamRef.current) {
      localStreamRef.current.getVideoTracks().forEach((track) => {
        track.enabled = !isVideoEnabled;
      });
    }
    setIsVideoEnabled(!isVideoEnabled);
  };

  // Flip camera
  const flipCamera = () => {
    setCameraFacing((prev) => (prev === 'user' ? 'environment' : 'user'));
  };

  if (!currentCall) return null;

  const formatTimer = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  // Incoming Call Ringing View
  if (currentCall.status === 'calling' && currentCall.callerId !== 'current-user') {
    return (
      <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4">
        <div className="max-w-sm w-full bg-slate-900 border border-slate-800 rounded-3xl p-6 text-center text-white shadow-2xl relative overflow-hidden">
          {/* Ringing ambient pulse */}
          <div className="absolute inset-0 bg-blue-500/10 animate-pulse pointer-events-none" />

          <div className="relative z-10 space-y-4">
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-blue-500/20 text-blue-400 border border-blue-500/30">
              <Sparkles className="w-3.5 h-3.5" />
              Incoming SocialOne WebRTC Call
            </span>

            {/* Caller Photo with expanding ripple rings */}
            <div className="relative mx-auto w-28 h-28 flex items-center justify-center">
              <div className="absolute inset-0 rounded-full bg-blue-500/20 animate-ping" />
              <img
                src={currentCall.callerPhoto}
                alt={currentCall.callerName}
                className="w-24 h-24 rounded-full object-cover ring-4 ring-blue-500 shadow-xl relative z-10"
              />
            </div>

            <div>
              <h3 className="text-xl font-bold">{currentCall.callerName}</h3>
              <p className="text-xs text-slate-400 mt-1">
                {currentCall.type === 'video' ? 'Incoming Video Call...' : 'Incoming Voice Call...'}
              </p>
            </div>

            {/* Answer & Decline Actions */}
            <div className="pt-6 flex items-center justify-around">
              {/* Decline */}
              <button
                onClick={declineCall}
                className="w-14 h-14 rounded-full bg-rose-600 hover:bg-rose-500 text-white flex items-center justify-center shadow-lg cursor-pointer transition-transform active:scale-95"
                title="Decline Call"
              >
                <PhoneOff className="w-6 h-6" />
              </button>

              {/* Answer */}
              <button
                onClick={answerCall}
                className="w-14 h-14 rounded-full bg-emerald-500 hover:bg-emerald-400 text-white flex items-center justify-center shadow-lg shadow-emerald-500/30 cursor-pointer transition-transform active:scale-95 animate-bounce"
                title="Answer Call"
              >
                <Phone className="w-6 h-6" />
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Active / Outgoing Connected Screen
  return (
    <div className="fixed inset-0 z-50 bg-[#070B14] text-white flex flex-col justify-between overflow-hidden">
      {/* Top Header */}
      <div className="px-6 py-4 flex items-center justify-between z-30 bg-gradient-to-b from-black/80 to-transparent">
        <div className="flex items-center gap-3">
          <img
            src={currentCall.receiverPhoto || currentCall.callerPhoto}
            alt="Participant"
            className="w-10 h-10 rounded-full object-cover ring-2 ring-blue-500"
          />
          <div>
            <h3 className="font-bold text-sm">
              {currentCall.receiverName || currentCall.callerName}
            </h3>
            <div className="flex items-center gap-2 text-xs text-slate-400">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
              <span>
                {currentCall.status === 'calling'
                  ? 'Connecting Peer...'
                  : `WebRTC Connected • ${formatTimer(callDuration)}`}
              </span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <span className="px-2.5 py-1 rounded-full text-xs font-semibold bg-white/10 text-slate-300">
            {currentCall.type === 'video' ? 'HD Video Call' : 'Encrypted Voice'}
          </span>
        </div>
      </div>

      {/* Main Remote Video or Avatar Center */}
      <div className="relative flex-1 flex items-center justify-center bg-black/60 overflow-hidden">
        {currentCall.type === 'video' ? (
          <div className="relative w-full h-full flex items-center justify-center">
            {/* Simulated Remote Partner Video */}
            <img
              src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=1200&auto=format&fit=crop&q=80"
              alt="Remote Video Stream"
              className="w-full h-full object-cover opacity-90"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-black/30 pointer-events-none" />

            {/* Remote audio waveform indicator */}
            <div className="absolute bottom-8 left-8 flex items-center gap-2 px-3 py-1.5 rounded-full bg-black/60 backdrop-blur-md text-xs text-emerald-400 border border-emerald-500/30">
              <Volume2 className="w-4 h-4 animate-bounce" />
              <span>Speaking...</span>
            </div>

            {/* Picture-in-Picture Local User Video Stream */}
            <div className="absolute top-6 right-6 w-32 h-44 sm:w-40 sm:h-56 rounded-2xl overflow-hidden shadow-2xl border-2 border-white/30 bg-slate-900 z-30">
              {isVideoEnabled ? (
                hasCameraPermission ? (
                  <video
                    ref={localVideoRef}
                    autoPlay
                    playsInline
                    muted
                    className="w-full h-full object-cover transform scale-x-[-1]"
                  />
                ) : (
                  <div className="w-full h-full flex flex-col items-center justify-center text-center p-2 bg-slate-800">
                    <VideoIcon className="w-6 h-6 text-blue-400 mb-1" />
                    <span className="text-[10px] text-slate-300">Camera Enabled</span>
                  </div>
                )
              ) : (
                <div className="w-full h-full flex flex-col items-center justify-center bg-slate-800 text-slate-400">
                  <VideoOff className="w-6 h-6 mb-1" />
                  <span className="text-[10px]">Camera Off</span>
                </div>
              )}
            </div>
          </div>
        ) : (
          /* Voice Call Avatar Display */
          <div className="text-center space-y-4">
            <div className="relative mx-auto w-36 h-36 flex items-center justify-center">
              <div className="absolute inset-0 rounded-full bg-blue-500/20 animate-ping" />
              <img
                src={currentCall.receiverPhoto || currentCall.callerPhoto}
                alt="Partner"
                className="w-32 h-32 rounded-full object-cover ring-4 ring-indigo-500 shadow-2xl relative z-10"
              />
            </div>
            <h2 className="text-2xl font-bold">
              {currentCall.receiverName || currentCall.callerName}
            </h2>
            <p className="text-sm text-indigo-400 font-medium">
              WebRTC Opus HD Voice • {formatTimer(callDuration)}
            </p>
          </div>
        )}
      </div>

      {/* Bottom Floating Control Bar */}
      <div className="p-6 bg-gradient-to-t from-black via-black/80 to-transparent flex items-center justify-center gap-5 z-30">
        {/* Mute Mic */}
        <button
          onClick={toggleMute}
          className={`w-13 h-13 rounded-full flex items-center justify-center transition-all cursor-pointer ${
            isMuted ? 'bg-rose-500 text-white' : 'bg-white/15 hover:bg-white/25 text-white'
          }`}
          title={isMuted ? 'Unmute Microphone' : 'Mute Microphone'}
        >
          {isMuted ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
        </button>

        {/* Video Toggle (if video call) */}
        {currentCall.type === 'video' && (
          <button
            onClick={toggleVideo}
            className={`w-13 h-13 rounded-full flex items-center justify-center transition-all cursor-pointer ${
              !isVideoEnabled ? 'bg-rose-500 text-white' : 'bg-white/15 hover:bg-white/25 text-white'
            }`}
            title={isVideoEnabled ? 'Turn Camera Off' : 'Turn Camera On'}
          >
            {isVideoEnabled ? <VideoIcon className="w-5 h-5" /> : <VideoOff className="w-5 h-5" />}
          </button>
        )}

        {/* Flip camera */}
        {currentCall.type === 'video' && (
          <button
            onClick={flipCamera}
            className="w-13 h-13 rounded-full bg-white/15 hover:bg-white/25 text-white flex items-center justify-center transition-all cursor-pointer"
            title="Flip Camera"
          >
            <RefreshCw className="w-5 h-5" />
          </button>
        )}

        {/* End Call Button */}
        <button
          onClick={endCall}
          className="w-16 h-16 rounded-full bg-rose-600 hover:bg-rose-500 text-white flex items-center justify-center shadow-lg shadow-rose-600/30 cursor-pointer transition-transform active:scale-95"
          title="End Call"
        >
          <PhoneOff className="w-7 h-7" />
        </button>
      </div>
    </div>
  );
};
