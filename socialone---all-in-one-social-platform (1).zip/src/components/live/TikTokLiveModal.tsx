import React, { useState, useRef, useEffect, useCallback } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useApp } from '../../context/AppContext';
import { TIKTOK_LIVE_GIFTS } from '../../lib/initialData';
import { LiveGift, LiveStreamSession } from '../../types';
import {
  X,
  Heart,
  MessageCircle,
  Share2,
  Gift,
  Users,
  Sparkles,
  Camera,
  Mic,
  MicOff,
  VideoOff,
  Send,
  ShieldCheck,
  TrendingUp,
  DollarSign,
  AlertCircle,
  CheckCircle2,
  Crown,
  Coins,
  Fuel,
  Plus,
} from 'lucide-react';
import confetti from 'canvas-confetti';

interface FloatingHeart {
  id: number;
  x: number;
  color: string;
}

export const TikTokLiveModal: React.FC = () => {
  const { userProfile, isAdmin, gainFollowers, deductCoins } = useAuth();
  const {
    isLiveModalOpen,
    setIsLiveModalOpen,
    activeLiveStream,
    isLiveHostMode,
    setIsLiveHostMode,
    endLiveStream,
    sendLiveGift,
    liveComments,
    addLiveComment,
    ownerPlatformRevenue,
    setIsCoinStoreOpen,
    setIsCreatorCashoutOpen,
  } = useApp();

  const [showGiftDrawer, setShowGiftDrawer] = useState(false);
  const [commentInput, setCommentInput] = useState('');
  const [floatingHearts, setFloatingHearts] = useState<FloatingHeart[]>([]);
  const [activeFlyingGift, setActiveFlyingGift] = useState<LiveGift | null>(null);
  const [isMicMuted, setIsMicMuted] = useState(false);
  const [isVideoMuted, setIsVideoMuted] = useState(false);
  const [cameraActive, setCameraActive] = useState(false);

  // Follower unlock modal state if attempting to host without 100 followers
  const [showUnlockRequirement, setShowUnlockRequirement] = useState(false);
  const [boostedNotice, setBoostedNotice] = useState(false);

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const commentsEndRef = useRef<HTMLDivElement | null>(null);

  const streamId = activeLiveStream?.id || 'live-intekhab-founder';
  const comments = liveComments[streamId] || [];

  const followersCount = userProfile?.followersCount || 1;
  const isEligibleForLive = followersCount >= 100 || isAdmin;

  // Auto-scroll comments to bottom
  useEffect(() => {
    commentsEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [comments.length]);

  // Handle camera start for host
  const startHostCamera = useCallback(async () => {
    if (!isLiveHostMode) return;
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: true,
        audio: true,
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.play().catch(() => {});
      }
      setCameraActive(true);
    } catch {
      // Fallback: draw animated live studio canvas
      setCameraActive(false);
      drawLiveCanvas();
    }
  }, [isLiveHostMode]);

  useEffect(() => {
    if (isLiveModalOpen && isLiveHostMode) {
      startHostCamera();
    }
    return () => {
      if (streamRef.current) {
        streamRef.current.getTracks().forEach((t) => t.stop());
        streamRef.current = null;
      }
    };
  }, [isLiveModalOpen, isLiveHostMode, startHostCamera]);

  // Live stage canvas renderer for simulated / fallback broadcast
  const drawLiveCanvas = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let tick = 0;
    let animId: number;

    const render = () => {
      tick += 0.04;
      const w = canvas.width;
      const h = canvas.height;

      // Deep vibrant stage gradient
      const grad = ctx.createLinearGradient(0, 0, w, h);
      grad.addColorStop(0, '#0F172A');
      grad.addColorStop(0.5, '#1E1B4B');
      grad.addColorStop(1, '#020617');
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, w, h);

      // Dynamic studio spotlight beams
      ctx.save();
      ctx.globalAlpha = 0.25;
      const beamX = (Math.sin(tick) + 1) * 0.5 * w;
      const beamGrad = ctx.createRadialGradient(beamX, 100, 20, beamX, 200, 260);
      beamGrad.addColorStop(0, '#38BDF8');
      beamGrad.addColorStop(1, 'transparent');
      ctx.fillStyle = beamGrad;
      ctx.fillRect(0, 0, w, h);
      ctx.restore();

      // Studio audio visualizer bars
      const bars = 18;
      const barWidth = 8;
      const startX = (w - bars * (barWidth + 4)) / 2;
      for (let i = 0; i < bars; i++) {
        const barHeight = Math.abs(Math.sin(tick * 3 + i * 0.4)) * 60 + 10;
        const x = startX + i * (barWidth + 4);
        const y = h - 220 - barHeight;
        const bGrad = ctx.createLinearGradient(x, y, x, y + barHeight);
        bGrad.addColorStop(0, '#F43F5E');
        bGrad.addColorStop(1, '#8B5CF6');
        ctx.fillStyle = bGrad;
        ctx.fillRect(x, y, barWidth, barHeight);
      }

      // Host Live Badge Orb
      ctx.save();
      const centerX = w / 2;
      const centerY = h / 2 - 80;
      const glow = Math.sin(tick * 2) * 8 + 65;

      ctx.beginPath();
      ctx.arc(centerX, centerY, glow + 8, 0, Math.PI * 2);
      ctx.fillStyle = 'rgba(244, 63, 94, 0.2)';
      ctx.fill();

      ctx.beginPath();
      ctx.arc(centerX, centerY, glow, 0, Math.PI * 2);
      ctx.fillStyle = '#0F172A';
      ctx.fill();
      ctx.lineWidth = 3;
      ctx.strokeStyle = '#F43F5E';
      ctx.stroke();

      // Broadcast Icon
      ctx.fillStyle = '#FFFFFF';
      ctx.font = 'bold 28px sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText('🔴 LIVE', centerX, centerY);
      ctx.restore();

      animId = requestAnimationFrame(render);
    };

    render();
    return () => cancelAnimationFrame(animId);
  };

  if (!isLiveModalOpen) return null;

  // Handle heart tap
  const spawnFloatingHeart = (e: React.MouseEvent) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const colors = ['#F43F5E', '#EC4899', '#8B5CF6', '#3B82F6', '#10B981', '#F59E0B'];
    const newHeart: FloatingHeart = {
      id: Date.now() + Math.random(),
      x: Math.max(20, Math.min(x, rect.width - 40)),
      color: colors[Math.floor(Math.random() * colors.length)],
    };
    setFloatingHearts((prev) => [...prev.slice(-15), newHeart]);
    setTimeout(() => {
      setFloatingHearts((prev) => prev.filter((h) => h.id !== newHeart.id));
    }, 1800);
  };

  const handleSendComment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!commentInput.trim()) return;
    addLiveComment(streamId, commentInput.trim());
    setCommentInput('');
  };

  const [insufficientCoinWarning, setInsufficientCoinWarning] = useState<string | null>(null);

  const handleSendGift = async (gift: LiveGift) => {
    const userCoins = userProfile?.coinsBalance || 0;
    if (userCoins < gift.coins) {
      setInsufficientCoinWarning(
        `You need ${gift.coins} Coins to send ${gift.name} ${gift.icon}. You have ${userCoins} Coins.`
      );
      setTimeout(() => setInsufficientCoinWarning(null), 3000);
      setIsCoinStoreOpen(true);
      return;
    }

    const deducted = await deductCoins(gift.coins);
    if (!deducted) {
      setIsCoinStoreOpen(true);
      return;
    }

    setShowGiftDrawer(false);
    setActiveFlyingGift(gift);

    // Dynamic celebration based on gift animation type
    confetti({
      particleCount: gift.coins >= 500 ? 120 : 50,
      spread: 80,
      origin: { y: 0.5 },
    });

    await sendLiveGift(streamId, gift);

    setTimeout(() => {
      setActiveFlyingGift(null);
    }, gift.animationType === 'lion' || gift.animationType === 'galaxy' ? 4500 : 3000);
  };

  const handleBoostFollowers = async () => {
    await gainFollowers(25);
    setBoostedNotice(true);
    setTimeout(() => setBoostedNotice(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/90 flex items-center justify-center p-0 sm:p-4 backdrop-blur-md">
      {/* Follower Unlock Notice Modal (if not eligible) */}
      {showUnlockRequirement && (
        <div className="absolute inset-0 z-60 bg-black/80 flex items-center justify-center p-4">
          <div className="max-w-md w-full bg-slate-900 border border-slate-800 rounded-3xl p-6 text-center space-y-4 shadow-2xl">
            <div className="w-16 h-16 rounded-full bg-rose-500/10 text-rose-500 mx-auto flex items-center justify-center">
              <AlertCircle className="w-8 h-8" />
            </div>
            <h3 className="text-xl font-black text-white">TikTok Live Requires 100 Followers</h3>
            <p className="text-xs text-slate-300 leading-relaxed">
              Just like TikTok, creators need at least <strong className="text-rose-400">100 Followers</strong> to broadcast Live and receive monetary gifts.
            </p>

            <div className="bg-slate-800/80 p-4 rounded-2xl border border-slate-700/60 space-y-2">
              <div className="flex justify-between text-xs font-bold">
                <span className="text-slate-400">Current Followers:</span>
                <span className="text-rose-400">{followersCount} / 100</span>
              </div>
              <div className="w-full h-2 rounded-full bg-slate-700 overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-rose-500 to-indigo-500 rounded-full transition-all duration-300"
                  style={{ width: `${Math.min(100, (followersCount / 100) * 100)}%` }}
                />
              </div>
            </div>

            <div className="flex flex-col gap-2 pt-2">
              <button
                onClick={handleBoostFollowers}
                className="w-full py-3 rounded-2xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-lg cursor-pointer"
              >
                <Sparkles className="w-4 h-4" />
                <span>Simulate / Boost Followers (+25)</span>
              </button>

              {boostedNotice && (
                <p className="text-xs text-emerald-400 font-bold flex items-center justify-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  Added 25 Followers! ({followersCount} total)
                </p>
              )}

              <button
                onClick={() => setShowUnlockRequirement(false)}
                className="w-full py-2.5 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold text-xs cursor-pointer"
              >
                Close & Return
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Main Live Stage Container */}
      <div
        onClick={spawnFloatingHeart}
        className="relative w-full max-w-md h-full sm:h-[840px] sm:max-h-[92vh] bg-black sm:rounded-3xl overflow-hidden shadow-2xl flex flex-col justify-between select-none"
      >
        {/* Background Stream Video / Canvas */}
        <div className="absolute inset-0 z-0">
          {isLiveHostMode ? (
            cameraActive ? (
              <video
                ref={videoRef}
                autoPlay
                playsInline
                muted
                className={`w-full h-full object-cover ${isVideoMuted ? 'hidden' : ''}`}
              />
            ) : (
              <canvas ref={canvasRef} width={450} height={800} className="w-full h-full object-cover" />
            )
          ) : activeLiveStream?.streamUrl ? (
            <img
              src={activeLiveStream.streamUrl}
              alt="Live broadcast"
              className="w-full h-full object-cover filter brightness-90"
            />
          ) : (
            <canvas ref={canvasRef} width={450} height={800} className="w-full h-full object-cover" />
          )}

          {/* Dark gradient scrims */}
          <div className="absolute inset-0 bg-gradient-to-b from-black/70 via-transparent to-black/90 pointer-events-none" />
        </div>

        {/* Top Header Floating Overlay */}
        <div className="relative z-20 p-4 space-y-2 pointer-events-auto">
          <div className="flex items-center justify-between gap-2">
            {/* Host pill */}
            <div className="flex items-center gap-2 p-1.5 pr-3 rounded-full bg-black/50 backdrop-blur-md border border-white/10 shadow-lg">
              <img
                src={
                  activeLiveStream?.hostPhoto ||
                  'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&auto=format&fit=crop&q=80'
                }
                alt="Host"
                className="w-8 h-8 rounded-full object-cover ring-2 ring-rose-500"
              />
              <div className="text-left">
                <div className="flex items-center gap-1">
                  <span className="text-xs font-bold text-white max-w-[110px] truncate">
                    {activeLiveStream?.hostName || 'Intekhab Alam'}
                  </span>
                  {activeLiveStream?.hostId === 'intekhab-alam-founder' && (
                    <Crown className="w-3 h-3 text-amber-400 fill-amber-400" />
                  )}
                </div>
                <div className="flex items-center gap-1.5 text-[10px] text-white/80">
                  <span className="w-1.5 h-1.5 rounded-full bg-rose-500 animate-ping" />
                  <span className="font-semibold text-rose-400">LIVE</span>
                  <span>•</span>
                  <span className="flex items-center gap-0.5">
                    <Users className="w-2.5 h-2.5" />
                    {activeLiveStream?.viewersCount || 1420}
                  </span>
                </div>
              </div>
            </div>

            {/* Exit / End Stream Button */}
            <button
              onClick={(e) => {
                e.stopPropagation();
                endLiveStream();
              }}
              className="p-2 rounded-full bg-black/60 hover:bg-black/80 text-white backdrop-blur-md border border-white/10 cursor-pointer transition-colors"
              title="Close Live Stream"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Revenue Tracker Bar: 75% Creator / 25% Owner Intekhab Alam */}
          <div className="p-2.5 rounded-2xl bg-black/70 backdrop-blur-md border border-amber-500/30 text-white space-y-1.5 shadow-lg">
            <div className="flex items-center justify-between text-xs">
              <span className="flex items-center gap-1.5 font-extrabold text-amber-400">
                <Sparkles className="w-3.5 h-3.5" />
                Live Gift Earnings
              </span>
              <div className="flex items-center gap-2">
                <span className="font-black text-sm text-emerald-400">
                  ${(activeLiveStream?.totalEarningsUsd || 0).toFixed(2)} USD
                </span>
                {/* Creator Petrol / Cashout Button (JazzCash & EasyPaisa) */}
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    setIsCreatorCashoutOpen(true);
                  }}
                  className="px-2.5 py-1 rounded-full bg-gradient-to-r from-emerald-500 to-teal-600 hover:opacity-90 text-white text-[10px] font-bold flex items-center gap-1 shadow-md cursor-pointer active:scale-95 transition-all"
                  title="Withdraw Live Earnings / Petrol Le Sakte Hain (JazzCash & EasyPaisa)"
                >
                  <Fuel className="w-3 h-3 text-amber-300" />
                  <span>Petrol / Cashout</span>
                </button>
              </div>
            </div>

            {/* Split breakdown */}
            <div className="flex items-center justify-between text-[10px] text-slate-300 pt-1 border-t border-white/10">
              <span className="text-teal-300">
                Creator (75%):{' '}
                <strong>
                  ${(activeLiveStream?.hostEarningsUsd || 0).toFixed(2)} (~Rs.{' '}
                  {Math.round((activeLiveStream?.hostEarningsUsd || 0) * 280).toLocaleString()} PKR)
                </strong>
              </span>
              <span className="text-amber-300">
                Owner Intekhab Alam (25%):{' '}
                <strong>${(activeLiveStream?.ownerEarningsUsd || 0).toFixed(2)}</strong>
              </span>
            </div>
          </div>
        </div>

        {/* Animated Flying Gift Banner on Screen */}
        {activeFlyingGift && (
          <div className="absolute inset-0 z-30 pointer-events-none flex items-center justify-center p-4">
            {activeFlyingGift.animationType === 'lion' ? (
              /* Giant Golden Lion King Animation */
              <div className="flex flex-col items-center animate-bounce">
                <div className="relative">
                  <span className="text-9xl drop-shadow-[0_0_35px_rgba(245,158,11,0.8)] animate-pulse">
                    🦁
                  </span>
                  <span className="absolute -top-4 -right-4 text-5xl animate-spin">👑</span>
                </div>
                <div className="mt-3 px-6 py-2.5 rounded-full bg-gradient-to-r from-amber-500 via-yellow-500 to-amber-600 text-slate-950 font-black text-base shadow-2xl border-2 border-white ring-4 ring-amber-400/40">
                  🦁 GOLDEN LION KING SENT! (+{activeFlyingGift.coins.toLocaleString()} Coins)
                </div>
                <p className="text-xs text-amber-200 font-bold drop-shadow mt-1">
                  75% Creator (${activeFlyingGift.creatorShare.toFixed(2)}) • 25% Owner Intekhab (${activeFlyingGift.ownerShare.toFixed(2)})
                </p>
              </div>
            ) : activeFlyingGift.animationType === 'car' ? (
              /* Sports Car Animation */
              <div className="flex flex-col items-center animate-pulse">
                <span className="text-9xl drop-shadow-[0_0_35px_rgba(239,68,68,0.8)]">🏎️</span>
                <div className="mt-3 px-6 py-2 rounded-full bg-gradient-to-r from-red-600 to-rose-600 text-white font-black text-sm shadow-2xl border-2 border-white">
                  🏎️ SUPER SPORTS CAR! (+{activeFlyingGift.coins.toLocaleString()} Coins)
                </div>
                <p className="text-xs text-rose-200 font-bold drop-shadow mt-1">
                  75% Creator (${activeFlyingGift.creatorShare.toFixed(2)}) • 25% Owner Intekhab (${activeFlyingGift.ownerShare.toFixed(2)})
                </p>
              </div>
            ) : activeFlyingGift.animationType === 'galaxy' ? (
              /* Universe Galaxy Animation */
              <div className="flex flex-col items-center animate-spin duration-700">
                <span className="text-9xl drop-shadow-[0_0_40px_rgba(139,92,246,0.9)]">🌌</span>
                <div className="mt-3 px-6 py-2 rounded-full bg-gradient-to-r from-purple-600 to-indigo-600 text-white font-black text-sm shadow-2xl border-2 border-white">
                  🌌 UNIVERSE GALAXY SENT! (+{activeFlyingGift.coins.toLocaleString()} Coins)
                </div>
              </div>
            ) : (
              /* Standard Gift Zoom Banner */
              <div className="flex flex-col items-center animate-bounce">
                <span className="text-8xl drop-shadow-2xl">{activeFlyingGift.icon}</span>
                <div className="mt-3 px-6 py-2 rounded-full bg-gradient-to-r from-amber-500 to-rose-500 text-white font-black text-sm shadow-2xl border-2 border-white/40">
                  Sent {activeFlyingGift.name}! (+{activeFlyingGift.coins} Coins)
                </div>
                <p className="text-[11px] text-white/90 drop-shadow mt-1">
                  75% Creator (${activeFlyingGift.creatorShare.toFixed(2)}) • 25% Owner Intekhab (${activeFlyingGift.ownerShare.toFixed(2)})
                </p>
              </div>
            )}
          </div>
        )}

        {/* Floating Tap Hearts */}
        <div className="absolute inset-0 pointer-events-none overflow-hidden z-25">
          {floatingHearts.map((heart) => (
            <div
              key={heart.id}
              className="absolute bottom-24 transition-all duration-1000 ease-out animate-[fadeUp_1.6s_forwards]"
              style={{
                left: `${heart.x}px`,
                color: heart.color,
              }}
            >
              <Heart className="w-8 h-8 fill-current drop-shadow-lg" />
            </div>
          ))}
        </div>

        {/* Bottom Interactive Area */}
        <div className="relative z-20 p-4 space-y-3 pointer-events-auto">
          {/* Live Comment Stream */}
          <div className="h-44 overflow-y-auto space-y-2 pr-2 text-xs scrollbar-none flex flex-col justify-end">
            {comments.slice(-8).map((comm) => (
              <div
                key={comm.id}
                className={`p-2 rounded-xl backdrop-blur-md text-white max-w-[85%] ${
                  comm.gift
                    ? 'bg-gradient-to-r from-amber-500/30 to-rose-500/30 border border-amber-400/40 shadow-md'
                    : 'bg-black/50 border border-white/10'
                }`}
              >
                <div className="flex items-center gap-1.5 font-bold text-[11px]">
                  <span className="text-blue-300">@{comm.userName}</span>
                  {comm.gift && (
                    <span className="px-1.5 py-0.2 rounded-md bg-amber-500 text-black text-[9px] font-black uppercase">
                      Gifted {comm.gift.icon}
                    </span>
                  )}
                </div>
                <p className="text-slate-100 text-xs mt-0.5 leading-snug">{comm.text}</p>
              </div>
            ))}
            <div ref={commentsEndRef} />
          </div>

          {/* Action Row & Comment Input */}
          <div className="flex items-center gap-2">
            <form onSubmit={handleSendComment} className="flex-1 flex items-center gap-2">
              <input
                type="text"
                value={commentInput}
                onChange={(e) => setCommentInput(e.target.value)}
                onClick={(e) => e.stopPropagation()}
                placeholder="Say something live..."
                className="flex-1 px-4 py-2.5 rounded-full bg-black/60 backdrop-blur-md border border-white/20 text-white placeholder-white/60 text-xs outline-none focus:border-rose-500"
              />
              <button
                type="submit"
                onClick={(e) => e.stopPropagation()}
                className="p-2.5 rounded-full bg-rose-600 hover:bg-rose-500 text-white cursor-pointer shadow-md"
              >
                <Send className="w-4 h-4" />
              </button>
            </form>

            {/* Gift Button */}
            <button
              onClick={(e) => {
                e.stopPropagation();
                setShowGiftDrawer(!showGiftDrawer);
              }}
              className="p-3 rounded-full bg-gradient-to-r from-amber-500 to-rose-500 text-white shadow-xl hover:scale-105 active:scale-95 transition-all cursor-pointer ring-2 ring-white/30"
              title="Send TikTok Live Gift"
            >
              <Gift className="w-5 h-5 fill-current" />
            </button>
          </div>
        </div>

        {/* Gift Drawer Modal */}
        {showGiftDrawer && (
          <div
            onClick={(e) => e.stopPropagation()}
            className="absolute bottom-0 left-0 right-0 z-40 bg-slate-950/98 border-t border-slate-700/80 rounded-t-3xl p-4 shadow-2xl backdrop-blur-xl animate-in slide-in-from-bottom duration-200"
          >
            {/* Header with Viewer's Coins & Sikka Recharge */}
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div>
                <h4 className="font-black text-sm text-white flex items-center gap-1.5">
                  <Gift className="w-4 h-4 text-amber-400" />
                  <span>TikTok Live Gifts</span>
                </h4>
                <p className="text-[10px] text-slate-400">
                  75% Creator • 25% Platform Share to Owner Intekhab Alam
                </p>
              </div>

              {/* Viewer Coins Balance & Recharge Button */}
              <div className="flex items-center gap-2">
                <div className="flex items-center gap-1 px-2.5 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs font-bold">
                  <Coins className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />
                  <span>{(userProfile?.coinsBalance || 0).toLocaleString()}</span>
                </div>

                <button
                  onClick={() => setIsCoinStoreOpen(true)}
                  className="px-2.5 py-1 rounded-full bg-gradient-to-r from-amber-500 to-rose-500 hover:opacity-90 text-white text-[11px] font-bold flex items-center gap-1 shadow-xs cursor-pointer active:scale-95 transition-all"
                  title="Buy / Recharge Coins"
                >
                  <Plus className="w-3 h-3" />
                  <span>Recharge</span>
                </button>

                <button
                  onClick={() => setShowGiftDrawer(false)}
                  className="p-1 rounded-full text-slate-400 hover:text-white cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Warning if insufficient coins */}
            {insufficientCoinWarning && (
              <div className="mt-2.5 p-2 rounded-xl bg-amber-500/15 border border-amber-500/30 text-amber-300 text-[11px] flex items-center justify-between">
                <span>{insufficientCoinWarning}</span>
                <button
                  onClick={() => setIsCoinStoreOpen(true)}
                  className="font-bold underline text-amber-400 cursor-pointer shrink-0 ml-2"
                >
                  Buy Coins Now →
                </button>
              </div>
            )}

            {/* Gift Options Grid */}
            <div className="grid grid-cols-4 sm:grid-cols-7 gap-2 py-3.5 max-h-56 overflow-y-auto scrollbar-none">
              {TIKTOK_LIVE_GIFTS.map((gift) => {
                const canAfford = (userProfile?.coinsBalance || 0) >= gift.coins;
                return (
                  <button
                    key={gift.id}
                    onClick={() => handleSendGift(gift)}
                    className={`p-2 rounded-2xl border flex flex-col items-center gap-1 transition-all group active:scale-95 cursor-pointer shadow-md relative ${
                      canAfford
                        ? 'bg-slate-900/90 hover:bg-slate-800 border-slate-700/80 hover:border-amber-400/60'
                        : 'bg-slate-900/50 border-slate-800 opacity-75 hover:opacity-100'
                    }`}
                  >
                    <span className="text-3xl group-hover:scale-110 transition-transform">
                      {gift.icon}
                    </span>
                    <span className="text-[10px] font-bold text-white truncate max-w-full">
                      {gift.name}
                    </span>
                    <span className="text-[10px] font-black text-amber-400 flex items-center gap-0.5">
                      <Coins className="w-2.5 h-2.5 fill-current" />
                      {gift.coins.toLocaleString()}
                    </span>
                  </button>
                );
              })}
            </div>

            <div className="p-2.5 rounded-xl bg-slate-900 border border-slate-800 text-[10px] text-slate-400 flex items-center justify-between">
              <span>💡 Instant TikTok gift animations with sound & confetti.</span>
              <button
                onClick={() => setIsCoinStoreOpen(true)}
                className="text-amber-400 font-bold hover:underline cursor-pointer"
              >
                🪙 JazzCash / EasyPaisa Coin Store
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
