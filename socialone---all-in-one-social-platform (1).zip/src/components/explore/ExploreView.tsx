import React from 'react';
import { useAuth } from '../../context/AuthContext';
import { useApp } from '../../context/AppContext';
import { Search, Flame, UserPlus, Check, Sparkles, Play, Heart } from 'lucide-react';

export const ExploreView: React.FC = () => {
  const { userProfile, toggleFollowUser, darkMode } = useAuth();
  const {
    searchQuery,
    setSearchQuery,
    posts,
    videos,
    setActiveTab,
  } = useApp();

  const trendingTags = [
    { tag: 'socialone', posts: '14.2k' },
    { tag: 'shorts', posts: '28.5k' },
    { tag: 'tech', posts: '9.8k' },
    { tag: 'photography', posts: '18.1k' },
    { tag: 'creators', posts: '7.4k' },
    { tag: 'webrtc', posts: '4.2k' },
    { tag: 'future', posts: '12.0k' },
  ];

  const featuredCreators = [
    {
      uid: 'intekhab-alam-founder',
      name: 'Intekhab Alam',
      handle: 'intekhab',
      role: 'Founder & CEO',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&auto=format&fit=crop&q=80',
      bio: 'Building the SocialOne all-in-one ecosystem.',
    },
    {
      uid: 'user-elena-vance',
      name: 'Elena Vance',
      handle: 'elenavance',
      role: 'Visual Artist',
      avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=400&auto=format&fit=crop&q=80',
      bio: 'Landscape & golden hour photography.',
    },
    {
      uid: 'user-marcus-chen',
      name: 'Marcus Chen',
      handle: 'marcus_code',
      role: 'Software Engineer',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&auto=format&fit=crop&q=80',
      bio: 'Fullstack systems, AI and responsive architecture.',
    },
    {
      uid: 'user-sophia-martinez',
      name: 'Sophia Martinez',
      handle: 'sophiam',
      role: 'Adventure Creator',
      avatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=400&auto=format&fit=crop&q=80',
      bio: 'High mountain trails and drone reels.',
    },
  ];

  // Search filtered results
  const matchingPosts = posts.filter(
    (p) =>
      p.content.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.authorName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.tags?.some((t) => t.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  const matchingVideos = videos.filter(
    (v) =>
      v.caption.toLowerCase().includes(searchQuery.toLowerCase()) ||
      v.creatorName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      v.hashtags?.some((h) => h.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  return (
    <div className="max-w-5xl mx-auto w-full pb-20 space-y-8">
      {/* Header & Search */}
      <div className="space-y-4">
        <div>
          <h2 className="text-2xl font-black tracking-tight flex items-center gap-2">
            <span>Explore & Discover</span>
            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-blue-500/10 text-blue-400 border border-blue-500/20">
              Instagram & TikTok Search
            </span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Discover trending topics, viral videos, creators, and community discussions.
          </p>
        </div>

        <div className="relative">
          <Search className="w-5 h-5 absolute left-4 top-3.5 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search keywords, hashtags like #tech, creators or reels..."
            className={`w-full pl-12 pr-4 py-3 rounded-2xl text-xs sm:text-sm border outline-none transition-all ${
              darkMode
                ? 'bg-slate-900 border-slate-800 text-white placeholder-slate-500 focus:border-blue-500 shadow-md'
                : 'bg-white border-slate-200 text-slate-900 placeholder-slate-400 focus:border-blue-500 shadow-xs'
            }`}
          />
        </div>
      </div>

      {/* Trending Hashtags */}
      <div className="space-y-3">
        <h3 className="font-bold text-sm flex items-center gap-2">
          <Flame className="w-4 h-4 text-rose-500" />
          <span>Trending Hashtags</span>
        </h3>
        <div className="flex flex-wrap gap-2.5">
          {trendingTags.map((item) => (
            <button
              key={item.tag}
              onClick={() => setSearchQuery(item.tag)}
              className={`px-3.5 py-1.5 rounded-2xl text-xs font-semibold border flex items-center gap-2 cursor-pointer transition-all hover:scale-105 ${
                searchQuery === item.tag
                  ? 'bg-blue-600 text-white border-blue-600'
                  : darkMode
                  ? 'bg-slate-900/60 border-slate-800 text-slate-300 hover:text-white hover:border-slate-700'
                  : 'bg-white border-slate-200 text-slate-700 hover:border-slate-300'
              }`}
            >
              <span className="text-blue-400">#{item.tag}</span>
              <span className="text-[10px] text-slate-500">{item.posts}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Suggested Creators */}
      <div className="space-y-3">
        <h3 className="font-bold text-sm flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-indigo-400" />
          <span>Featured Creators on SocialOne</span>
        </h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {featuredCreators.map((creator) => {
            const isFollowing = userProfile?.followingIds?.includes(creator.uid);
            return (
              <div
                key={creator.uid}
                className={`p-4 rounded-3xl border flex flex-col justify-between space-y-3 transition-colors ${
                  darkMode ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200 shadow-xs'
                }`}
              >
                <div className="flex items-center gap-3">
                  <img
                    src={creator.avatar}
                    alt={creator.name}
                    className="w-12 h-12 rounded-full object-cover ring-2 ring-blue-500/30"
                  />
                  <div className="min-w-0">
                    <p className="font-bold text-xs truncate">{creator.name}</p>
                    <p className="text-[10px] text-slate-400">@{creator.handle}</p>
                    <span className="text-[10px] font-semibold text-indigo-400">{creator.role}</span>
                  </div>
                </div>

                <p className="text-[11px] text-slate-400 line-clamp-2">{creator.bio}</p>

                {creator.uid !== userProfile?.uid && (
                  <button
                    onClick={() => toggleFollowUser(creator.uid)}
                    className={`w-full py-2 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
                      isFollowing
                        ? 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                        : 'bg-blue-600 hover:bg-blue-500 text-white'
                    }`}
                  >
                    {isFollowing ? (
                      <>
                        <Check className="w-3.5 h-3.5" />
                        <span>Following</span>
                      </>
                    ) : (
                      <>
                        <UserPlus className="w-3.5 h-3.5" />
                        <span>Follow</span>
                      </>
                    )}
                  </button>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Instagram-style Visual Media Grid */}
      <div className="space-y-3">
        <h3 className="font-bold text-sm">Visual Discovery Grid</h3>
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
          {matchingPosts
            .filter((p) => p.mediaUrls && p.mediaUrls.length > 0)
            .map((post) => (
              <div
                key={post.id}
                onClick={() => setActiveTab('home')}
                className="relative aspect-square rounded-2xl overflow-hidden cursor-pointer group bg-black shadow-xs"
              >
                <img
                  src={post.mediaUrls[0]}
                  alt="Explore media"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-4 text-white text-xs font-bold">
                  <div className="flex items-center gap-1">
                    <Heart className="w-4 h-4 fill-current text-rose-500" />
                    <span>{post.likesCount}</span>
                  </div>
                </div>
              </div>
            ))}

          {/* Videos Grid thumbnails */}
          {matchingVideos.map((vid) => (
            <div
              key={vid.id}
              onClick={() => setActiveTab('videos')}
              className="relative aspect-square rounded-2xl overflow-hidden cursor-pointer group bg-black shadow-xs"
            >
              <video
                src={vid.videoUrl}
                muted
                className="w-full h-full object-cover opacity-80 group-hover:scale-105 transition-transform"
              />
              <div className="absolute top-2 right-2 p-1.5 rounded-full bg-black/60 text-white">
                <Play className="w-3.5 h-3.5 fill-current" />
              </div>
              <div className="absolute bottom-2 left-2 right-2 text-white text-[11px] font-bold truncate drop-shadow">
                {vid.caption}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
