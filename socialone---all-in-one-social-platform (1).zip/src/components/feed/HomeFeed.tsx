import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useApp } from '../../context/AppContext';
import { StoriesBar } from '../stories/StoriesBar';
import {
  Heart,
  MessageCircle,
  Share2,
  Bookmark,
  MoreHorizontal,
  Image as ImageIcon,
  Video,
  Smile,
  Send,
  Trash2,
  Flag,
  Sparkles,
  Check,
} from 'lucide-react';
import confetti from 'canvas-confetti';

export const HomeFeed: React.FC = () => {
  const { userProfile, darkMode, isAdmin, toggleSavePost } = useAuth();
  const {
    posts,
    toggleLikePost,
    postComments,
    addPostComment,
    deletePost,
    submitReport,
    setIsCreateModalOpen,
    setIsTikTokStudioOpen,
  } = useApp();

  const [activeFeedTab, setActiveFeedTab] = useState<'for-you' | 'following' | 'trending' | 'saved'>('for-you');
  const [expandedComments, setExpandedComments] = useState<{ [postId: string]: boolean }>({});
  const [commentInputs, setCommentInputs] = useState<{ [postId: string]: string }>({});
  const [copiedPostId, setCopiedPostId] = useState<string | null>(null);
  const [reportingPostId, setReportingPostId] = useState<string | null>(null);
  const [reportReason, setReportReason] = useState('');

  // Filter posts based on active feed tab
  const filteredPosts = posts.filter((post) => {
    if (activeFeedTab === 'saved') {
      return userProfile?.savedPostIds?.includes(post.id);
    }
    if (activeFeedTab === 'following') {
      return (
        userProfile?.followingIds?.includes(post.authorId) ||
        post.authorId === userProfile?.uid ||
        post.authorId === 'intekhab-alam-founder'
      );
    }
    if (activeFeedTab === 'trending') {
      return post.likesCount > 100 || post.commentsCount > 10;
    }
    return true; // 'for-you'
  });

  const handleLike = (postId: string, e: React.MouseEvent) => {
    toggleLikePost(postId);
    const rect = e.currentTarget.getBoundingClientRect();
    confetti({
      particleCount: 20,
      spread: 45,
      origin: {
        x: (rect.left + rect.width / 2) / window.innerWidth,
        y: (rect.top + rect.height / 2) / window.innerHeight,
      },
    });
  };

  const handleShare = (postId: string) => {
    navigator.clipboard?.writeText(window.location.origin + `?post=${postId}`);
    setCopiedPostId(postId);
    setTimeout(() => setCopiedPostId(null), 2500);
  };

  const handleCommentSubmit = (postId: string, e: React.FormEvent) => {
    e.preventDefault();
    const text = commentInputs[postId]?.trim();
    if (!text) return;
    addPostComment(postId, text);
    setCommentInputs((prev) => ({ ...prev, [postId]: '' }));
  };

  const handleReportPost = async (postId: string, postTitle: string) => {
    if (!reportReason.trim()) return;
    await submitReport('post', postId, postTitle, reportReason.trim());
    setReportingPostId(null);
    setReportReason('');
    alert('Report submitted to moderation queue. Thank you for keeping SocialOne safe.');
  };

  return (
    <div className="max-w-2xl mx-auto w-full pb-20">
      {/* 24h Stories Bar */}
      <StoriesBar />

      {/* Feed Tabs */}
      <div
        className={`flex items-center justify-between p-1 rounded-2xl border mb-6 transition-colors ${
          darkMode ? 'bg-slate-900/60 border-slate-800' : 'bg-slate-100 border-slate-200'
        }`}
      >
        {[
          { id: 'for-you', label: 'For You' },
          { id: 'following', label: 'Following' },
          { id: 'trending', label: 'Trending 🔥' },
          { id: 'saved', label: 'Saved 📌' },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveFeedTab(tab.id as any)}
            className={`flex-1 py-2 text-xs font-bold rounded-xl transition-all cursor-pointer ${
              activeFeedTab === tab.id
                ? darkMode
                  ? 'bg-blue-600 text-white shadow-md'
                  : 'bg-white text-slate-900 shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Create Post Prompt Box */}
      <div
        className={`p-4 rounded-3xl border mb-6 transition-colors shadow-xs ${
          darkMode ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200'
        }`}
      >
        <div className="flex items-center gap-3">
          <img
            src={
              userProfile?.photoURL ||
              'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&auto=format&fit=crop&q=80'
            }
            alt="You"
            className="w-10 h-10 rounded-full object-cover ring-2 ring-blue-500/20"
          />
          <button
            onClick={() => setIsCreateModalOpen(true)}
            className={`flex-1 text-left px-4 py-2.5 rounded-full text-xs transition-colors cursor-pointer ${
              darkMode
                ? 'bg-slate-800/80 text-slate-400 hover:bg-slate-800 hover:text-slate-300'
                : 'bg-slate-100 text-slate-500 hover:bg-slate-200'
            }`}
          >
            What’s happening on SocialOne today, {userProfile?.displayName.split(' ')[0]}?
          </button>
        </div>

        <div className="flex items-center justify-between pt-3 mt-3 border-t border-slate-800/40 text-xs text-slate-400">
          <button
            onClick={() => setIsCreateModalOpen(true)}
            className="flex items-center gap-1.5 hover:text-blue-500 transition-colors cursor-pointer"
          >
            <ImageIcon className="w-4 h-4 text-emerald-400" />
            <span className="font-medium">Gallery Photos/Videos</span>
          </button>

          <button
            onClick={() => setIsTikTokStudioOpen(true)}
            className="flex items-center gap-1.5 hover:text-rose-500 transition-colors cursor-pointer"
          >
            <Video className="w-4 h-4 text-rose-400" />
            <span className="font-medium">Record TikTok Short</span>
          </button>

          <button
            onClick={() => setIsCreateModalOpen(true)}
            className="flex items-center gap-1.5 hover:text-amber-500 transition-colors cursor-pointer"
          >
            <Smile className="w-4 h-4 text-amber-400" />
            <span className="font-medium">Feelings</span>
          </button>
        </div>
      </div>

      {/* Posts Stream */}
      <div className="space-y-6">
        {filteredPosts.length === 0 ? (
          <div
            className={`p-10 rounded-3xl border text-center space-y-3 ${
              darkMode ? 'bg-slate-900/40 border-slate-800' : 'bg-white border-slate-200'
            }`}
          >
            <p className="text-base font-semibold">No posts found in this tab</p>
            <p className="text-xs text-slate-400">
              Be the first to share a post, video reel or story on SocialOne!
            </p>
            <button
              onClick={() => setIsCreateModalOpen(true)}
              className="px-5 py-2 rounded-full text-xs font-bold text-white bg-blue-600 hover:bg-blue-500 cursor-pointer"
            >
              Create First Post
            </button>
          </div>
        ) : (
          filteredPosts.map((post) => {
            const isLiked = post.likedBy?.includes(userProfile?.uid || '');
            const isSaved = userProfile?.savedPostIds?.includes(post.id);
            const isCommentsOpen = Boolean(expandedComments[post.id]);
            const comments = postComments[post.id] || [];

            return (
              <article
                key={post.id}
                className={`rounded-3xl border transition-all duration-200 overflow-hidden shadow-xs hover:border-slate-700/80 ${
                  darkMode ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200'
                }`}
              >
                {/* Post Header */}
                <div className="p-4 sm:p-5 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <img
                      src={post.authorPhoto}
                      alt={post.authorName}
                      className="w-11 h-11 rounded-full object-cover ring-2 ring-blue-500/30"
                    />
                    <div>
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <span className="font-bold text-sm">{post.authorName}</span>
                        {post.authorId === 'intekhab-alam-founder' && (
                          <span className="inline-flex items-center gap-1 text-[10px] font-bold text-white bg-gradient-to-r from-blue-600 to-indigo-600 px-2 py-0.5 rounded-full shadow-xs">
                            <Sparkles className="w-2.5 h-2.5" />
                            Founder & CEO
                          </span>
                        )}
                        {post.groupName && (
                          <span className="text-[11px] text-indigo-400 font-medium">
                            in {post.groupName}
                          </span>
                        )}
                      </div>
                      <div className="flex items-center gap-2 text-xs text-slate-400">
                        <span>@{post.authorUsername}</span>
                        <span>•</span>
                        <span>
                          {new Date(post.createdAt).toLocaleDateString([], {
                            month: 'short',
                            day: 'numeric',
                          })}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Options Menu */}
                  <div className="flex items-center gap-1">
                    {(post.authorId === userProfile?.uid || isAdmin) && (
                      <button
                        onClick={() => deletePost(post.id)}
                        className="p-2 rounded-full hover:bg-rose-500/10 text-slate-400 hover:text-rose-400 transition-colors cursor-pointer"
                        title="Delete Post"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    )}
                    <button
                      onClick={() => setReportingPostId(post.id)}
                      className="p-2 rounded-full hover:bg-slate-800 text-slate-400 hover:text-slate-200 transition-colors cursor-pointer"
                      title="Report Post"
                    >
                      <Flag className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                {/* Content */}
                <div className="px-4 sm:px-5 pb-3">
                  <p className="text-sm leading-relaxed whitespace-pre-line font-normal">
                    {post.content}
                  </p>

                  {/* Tags */}
                  {post.tags && post.tags.length > 0 && (
                    <div className="flex flex-wrap gap-1.5 mt-2.5">
                      {post.tags.map((tag) => (
                        <span
                          key={tag}
                          className="text-xs font-semibold text-blue-500 hover:underline cursor-pointer"
                        >
                          #{tag}
                        </span>
                      ))}
                    </div>
                  )}
                </div>

                {/* Media */}
                {post.mediaUrls && post.mediaUrls.length > 0 && (
                  <div className="relative mt-2 bg-black/40 overflow-hidden max-h-[500px] flex items-center justify-center">
                    {post.mediaType === 'video' ? (
                      <video
                        src={post.mediaUrls[0]}
                        controls
                        className="w-full max-h-[500px] object-contain"
                      />
                    ) : (
                      <img
                        src={post.mediaUrls[0]}
                        alt="Post media"
                        className="w-full max-h-[500px] object-cover"
                      />
                    )}
                  </div>
                )}

                {/* Engagement Metrics Bar */}
                <div className="px-4 sm:px-5 py-2.5 flex items-center justify-between text-xs text-slate-400 border-b border-slate-800/40">
                  <span>{post.likesCount} Likes</span>
                  <div className="flex items-center gap-3">
                    <span>{post.commentsCount} Comments</span>
                    <span>{post.sharesCount} Shares</span>
                  </div>
                </div>

                {/* Interactive Action Bar */}
                <div className="px-4 sm:px-5 py-2 flex items-center justify-between">
                  <button
                    onClick={(e) => handleLike(post.id, e)}
                    className={`flex-1 py-2 flex items-center justify-center gap-2 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                      isLiked
                        ? 'text-rose-500 bg-rose-500/10'
                        : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/40'
                    }`}
                  >
                    <Heart className={`w-4 h-4 ${isLiked ? 'fill-rose-500 text-rose-500' : ''}`} />
                    <span>{isLiked ? 'Liked' : 'Like'}</span>
                  </button>

                  <button
                    onClick={() =>
                      setExpandedComments((prev) => ({ ...prev, [post.id]: !prev[post.id] }))
                    }
                    className="flex-1 py-2 flex items-center justify-center gap-2 rounded-xl text-xs font-semibold text-slate-400 hover:text-slate-200 hover:bg-slate-800/40 transition-all cursor-pointer"
                  >
                    <MessageCircle className="w-4 h-4" />
                    <span>Comment</span>
                  </button>

                  <button
                    onClick={() => handleShare(post.id)}
                    className="flex-1 py-2 flex items-center justify-center gap-2 rounded-xl text-xs font-semibold text-slate-400 hover:text-slate-200 hover:bg-slate-800/40 transition-all cursor-pointer"
                  >
                    {copiedPostId === post.id ? (
                      <>
                        <Check className="w-4 h-4 text-emerald-400" />
                        <span className="text-emerald-400">Copied!</span>
                      </>
                    ) : (
                      <>
                        <Share2 className="w-4 h-4" />
                        <span>Share</span>
                      </>
                    )}
                  </button>

                  <button
                    onClick={() => toggleSavePost(post.id)}
                    className={`p-2 rounded-xl transition-all cursor-pointer ${
                      isSaved
                        ? 'text-amber-400 bg-amber-400/10'
                        : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/40'
                    }`}
                    title={isSaved ? 'Remove from Saved' : 'Save Post'}
                  >
                    <Bookmark
                      className={`w-4 h-4 ${isSaved ? 'fill-amber-400 text-amber-400' : ''}`}
                    />
                  </button>
                </div>

                {/* Expanded Comments Drawer */}
                {isCommentsOpen && (
                  <div
                    className={`p-4 border-t ${
                      darkMode ? 'bg-slate-900/40 border-slate-800/60' : 'bg-slate-50/70 border-slate-200'
                    }`}
                  >
                    {/* Add comment form */}
                    <form
                      onSubmit={(e) => handleCommentSubmit(post.id, e)}
                      className="flex items-center gap-2 mb-3"
                    >
                      <input
                        type="text"
                        value={commentInputs[post.id] || ''}
                        onChange={(e) =>
                          setCommentInputs((prev) => ({ ...prev, [post.id]: e.target.value }))
                        }
                        placeholder="Write a comment..."
                        className={`flex-1 px-4 py-2 rounded-full text-xs outline-none border transition-colors ${
                          darkMode
                            ? 'bg-slate-900 border-slate-700 text-white placeholder-slate-500 focus:border-blue-500'
                            : 'bg-white border-slate-300 text-slate-900 placeholder-slate-400 focus:border-blue-500'
                        }`}
                      />
                      <button
                        type="submit"
                        className="p-2 rounded-full bg-blue-600 hover:bg-blue-500 text-white cursor-pointer shadow-sm transition-colors"
                      >
                        <Send className="w-4 h-4" />
                      </button>
                    </form>

                    {/* Comments list */}
                    <div className="space-y-2.5 max-h-56 overflow-y-auto">
                      {comments.length === 0 ? (
                        <p className="text-xs text-slate-400 py-1">
                          No comments yet. Be the first to share your thoughts!
                        </p>
                      ) : (
                        comments.map((comment) => (
                          <div key={comment.id} className="flex items-start gap-2.5 text-xs">
                            <img
                              src={comment.authorPhoto}
                              alt={comment.authorName}
                              className="w-7 h-7 rounded-full object-cover shrink-0 mt-0.5"
                            />
                            <div
                              className={`p-2.5 rounded-2xl flex-1 ${
                                darkMode ? 'bg-slate-800/70' : 'bg-slate-200/60'
                              }`}
                            >
                              <div className="flex items-center justify-between">
                                <span className="font-bold text-[11px]">{comment.authorName}</span>
                                <span className="text-[10px] text-slate-400">
                                  {new Date(comment.createdAt).toLocaleTimeString([], {
                                    hour: '2-digit',
                                    minute: '2-digit',
                                  })}
                                </span>
                              </div>
                              <p className="mt-1 text-slate-300 font-normal">{comment.content}</p>
                            </div>
                          </div>
                        ))
                      )}
                    </div>
                  </div>
                )}
              </article>
            );
          })
        )}
      </div>

      {/* Moderation Report Dialog */}
      {reportingPostId && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div
            className={`p-6 rounded-3xl border max-w-md w-full space-y-4 shadow-2xl ${
              darkMode ? 'bg-slate-900 border-slate-800 text-white' : 'bg-white border-slate-200 text-slate-900'
            }`}
          >
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-base flex items-center gap-2">
                <Flag className="w-5 h-5 text-rose-500" />
                Report Post
              </h3>
              <button
                onClick={() => setReportingPostId(null)}
                className="text-xs text-slate-400 hover:text-white cursor-pointer"
              >
                Cancel
              </button>
            </div>
            <p className="text-xs text-slate-400">
              Help us maintain a safe community on SocialOne. Please describe why this post violates community guidelines.
            </p>
            <textarea
              value={reportReason}
              onChange={(e) => setReportReason(e.target.value)}
              placeholder="Reason (e.g. spam, harassment, hate speech, copyright infringement)..."
              rows={3}
              className={`w-full p-3 rounded-2xl text-xs border outline-none ${
                darkMode ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-100 border-slate-200 text-slate-900'
              }`}
            />
            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                onClick={() => setReportingPostId(null)}
                className="px-4 py-2 rounded-xl text-xs text-slate-400 hover:bg-slate-800 cursor-pointer"
              >
                Close
              </button>
              <button
                onClick={() => handleReportPost(reportingPostId, 'Reported Post')}
                className="px-4 py-2 rounded-xl text-xs font-bold bg-rose-600 hover:bg-rose-500 text-white cursor-pointer"
              >
                Submit Report
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
