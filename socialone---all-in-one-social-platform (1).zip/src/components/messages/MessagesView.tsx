import React, { useState, useRef, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useApp } from '../../context/AppContext';
import {
  Search,
  Phone,
  Video,
  Send,
  Mic,
  Image as ImageIcon,
  Smile,
  Check,
  CheckCheck,
  MoreVertical,
  Play,
  Pause,
  Sparkles,
  Users,
} from 'lucide-react';

export const MessagesView: React.FC = () => {
  const { userProfile, darkMode } = useAuth();
  const {
    conversations,
    activeConversation,
    setActiveConversation,
    messages,
    sendMessage,
    startCall,
  } = useApp();

  const [messageText, setMessageText] = useState('');
  const [filterType, setFilterType] = useState<'all' | 'direct' | 'group'>('all');
  const [chatSearch, setChatSearch] = useState('');
  const [isRecordingVoice, setIsRecordingVoice] = useState(false);
  const [recordingSeconds, setRecordingSeconds] = useState(0);
  const [playingAudioId, setPlayingAudioId] = useState<string | null>(null);
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);

  const messagesEndRef = useRef<HTMLDivElement | null>(null);
  const chatFileInputRef = useRef<HTMLInputElement | null>(null);

  const handleChatFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const url = URL.createObjectURL(file);
    sendMessage(file.name, 'image', url);
  };

  // Auto scroll to bottom of chat
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Voice note recording timer simulation
  useEffect(() => {
    let interval: any;
    if (isRecordingVoice) {
      interval = setInterval(() => {
        setRecordingSeconds((prev) => prev + 1);
      }, 1000);
    } else {
      setRecordingSeconds(0);
    }
    return () => clearInterval(interval);
  }, [isRecordingVoice]);

  const handleSendTextMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!messageText.trim()) return;
    sendMessage(messageText.trim(), 'text');
    setMessageText('');
    setShowEmojiPicker(false);
  };

  const handleFinishVoiceRecord = () => {
    setIsRecordingVoice(false);
    sendMessage(`Voice note (${recordingSeconds}s)`, 'audio', undefined, recordingSeconds || 4);
  };

  const togglePlayAudio = (msgId: string) => {
    if (playingAudioId === msgId) {
      setPlayingAudioId(null);
    } else {
      setPlayingAudioId(msgId);
      setTimeout(() => setPlayingAudioId(null), 4000);
    }
  };

  const filteredConversations = conversations.filter((conv) => {
    if (filterType === 'direct' && conv.type !== 'direct') return false;
    if (filterType === 'group' && conv.type !== 'group') return false;
    if (chatSearch.trim()) {
      return (
        conv.name?.toLowerCase().includes(chatSearch.toLowerCase()) ||
        conv.lastMessage?.toLowerCase().includes(chatSearch.toLowerCase())
      );
    }
    return true;
  });

  const conversationMessages = messages.filter(
    (m) => m.conversationId === activeConversation?.id
  );

  return (
    <div
      className={`max-w-6xl mx-auto w-full h-[calc(100vh-6.5rem)] rounded-3xl border overflow-hidden flex shadow-lg transition-colors ${
        darkMode ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200'
      }`}
    >
      {/* Left Conversations Sidebar */}
      <div
        className={`w-full sm:w-80 md:w-96 border-r flex flex-col shrink-0 ${
          activeConversation ? 'hidden sm:flex' : 'flex'
        } ${darkMode ? 'border-slate-800 bg-[#0B0F19]/40' : 'border-slate-200 bg-slate-50/60'}`}
      >
        {/* Header */}
        <div className="p-4 border-b border-slate-800/40 space-y-3">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-black tracking-tight flex items-center gap-2">
              <span>Messages & Calls</span>
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
            </h2>
            <span className="text-[10px] font-semibold text-slate-400 bg-blue-500/10 px-2 py-0.5 rounded-full border border-blue-500/20">
              WhatsApp Engine
            </span>
          </div>

          {/* Search */}
          <div className="relative">
            <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
            <input
              type="text"
              value={chatSearch}
              onChange={(e) => setChatSearch(e.target.value)}
              placeholder="Search chats or messages..."
              className={`w-full pl-9 pr-3 py-1.5 rounded-xl text-xs border outline-none ${
                darkMode
                  ? 'bg-slate-900 border-slate-800 text-white placeholder-slate-500 focus:border-blue-500'
                  : 'bg-white border-slate-200 text-slate-900 placeholder-slate-400 focus:border-blue-500'
              }`}
            />
          </div>

          {/* Filter Pills */}
          <div className="flex items-center gap-2">
            {[
              { id: 'all', label: 'All' },
              { id: 'direct', label: 'Direct' },
              { id: 'group', label: 'Groups' },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setFilterType(tab.id as any)}
                className={`px-3 py-1 rounded-full text-xs font-semibold cursor-pointer transition-colors ${
                  filterType === tab.id
                    ? 'bg-blue-600 text-white'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        {/* Conversation List */}
        <div className="flex-1 overflow-y-auto divide-y divide-slate-800/20">
          {filteredConversations.map((conv) => {
            const isSelected = activeConversation?.id === conv.id;
            return (
              <div
                key={conv.id}
                onClick={() => setActiveConversation(conv)}
                className={`p-3.5 flex items-center gap-3 cursor-pointer transition-colors select-none ${
                  isSelected
                    ? darkMode
                      ? 'bg-blue-600/15 border-l-4 border-blue-500'
                      : 'bg-blue-50 border-l-4 border-blue-600'
                    : darkMode
                    ? 'hover:bg-slate-800/40'
                    : 'hover:bg-slate-100/70'
                }`}
              >
                <div className="relative">
                  <img
                    src={
                      conv.avatarUrl ||
                      'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&auto=format&fit=crop&q=80'
                    }
                    alt={conv.name || 'Chat'}
                    className="w-12 h-12 rounded-full object-cover ring-2 ring-blue-500/20"
                  />
                  {conv.type === 'direct' && (
                    <span className="absolute bottom-0 right-0 w-3 h-3 rounded-full bg-emerald-500 ring-2 ring-[#0B0F19]"></span>
                  )}
                  {conv.type === 'group' && (
                    <span className="absolute bottom-0 right-0 p-0.5 rounded-full bg-indigo-600 text-white ring-2 ring-[#0B0F19]">
                      <Users className="w-2.5 h-2.5" />
                    </span>
                  )}
                </div>

                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between mb-0.5">
                    <h4 className="font-bold text-xs truncate">{conv.name}</h4>
                    <span className="text-[10px] text-slate-400 shrink-0">
                      {conv.lastMessageTime || 'Today'}
                    </span>
                  </div>
                  <p className="text-xs text-slate-400 truncate font-normal">
                    {conv.lastMessage || 'Say hello on SocialOne!'}
                  </p>
                </div>

                {Boolean(conv.unreadCount) && (
                  <span className="w-5 h-5 rounded-full bg-emerald-500 text-white text-[10px] font-bold flex items-center justify-center shrink-0">
                    {conv.unreadCount}
                  </span>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Right Chat Room */}
      <div
        className={`flex-1 flex flex-col ${
          !activeConversation ? 'hidden sm:flex items-center justify-center' : 'flex'
        }`}
      >
        {activeConversation ? (
          <>
            {/* Chat Room Header */}
            <div
              className={`px-4 sm:px-6 py-3.5 border-b flex items-center justify-between z-10 ${
                darkMode ? 'bg-[#0B0F19]/80 border-slate-800' : 'bg-white border-slate-200 shadow-xs'
              }`}
            >
              <div className="flex items-center gap-3">
                <button
                  onClick={() => setActiveConversation(null)}
                  className="sm:hidden text-xs text-blue-500 font-semibold cursor-pointer"
                >
                  ← Back
                </button>
                <div className="relative">
                  <img
                    src={
                      activeConversation.avatarUrl ||
                      'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&auto=format&fit=crop&q=80'
                    }
                    alt={activeConversation.name}
                    className="w-10 h-10 rounded-full object-cover ring-2 ring-blue-500/30"
                  />
                  <span className="absolute bottom-0 right-0 w-2.5 h-2.5 rounded-full bg-emerald-500 ring-2 ring-[#0B0F19]"></span>
                </div>
                <div>
                  <h3 className="font-bold text-xs sm:text-sm flex items-center gap-1.5">
                    <span>{activeConversation.name}</span>
                    {activeConversation.id === 'conv-intekhab' && (
                      <span className="inline-flex items-center gap-0.5 text-[9px] font-bold text-white bg-blue-600 px-1.5 py-0.2 rounded-full">
                        <Sparkles className="w-2 h-2" />
                        Founder
                      </span>
                    )}
                  </h3>
                  <p className="text-[10px] text-emerald-400 font-medium">
                    Online • End-to-End Encrypted
                  </p>
                </div>
              </div>

              {/* Call Action Buttons */}
              <div className="flex items-center gap-1 sm:gap-2">
                <button
                  onClick={() =>
                    startCall(
                      activeConversation.id,
                      activeConversation.name || 'Intekhab Alam',
                      activeConversation.avatarUrl || '',
                      'voice'
                    )
                  }
                  className={`p-2.5 rounded-full transition-colors cursor-pointer ${
                    darkMode
                      ? 'bg-slate-800 hover:bg-slate-700 text-slate-300'
                      : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                  }`}
                  title="Start Voice Call"
                >
                  <Phone className="w-4 h-4 text-emerald-400" />
                </button>

                <button
                  onClick={() =>
                    startCall(
                      activeConversation.id,
                      activeConversation.name || 'Intekhab Alam',
                      activeConversation.avatarUrl || '',
                      'video'
                    )
                  }
                  className={`p-2.5 rounded-full transition-colors cursor-pointer ${
                    darkMode
                      ? 'bg-blue-600/20 hover:bg-blue-600/30 text-blue-400'
                      : 'bg-blue-50 hover:bg-blue-100 text-blue-600'
                  }`}
                  title="Start WebRTC Video Call"
                >
                  <Video className="w-4 h-4" />
                </button>

                <button className="p-2 text-slate-400 hover:text-slate-200 cursor-pointer">
                  <MoreVertical className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Messages Scroll View */}
            <div
              className={`flex-1 overflow-y-auto p-4 sm:p-6 space-y-4 ${
                darkMode ? 'bg-[#080C16]' : 'bg-[#F4F6F9]'
              }`}
            >
              {/* Encryption Banner */}
              <div className="text-center my-2">
                <span className="inline-block px-3 py-1 rounded-full text-[10px] font-medium bg-amber-500/10 text-amber-400 border border-amber-500/20">
                  🔒 Messages and calls are end-to-end encrypted. No one outside can read or listen.
                </span>
              </div>

              {conversationMessages.map((msg) => {
                const isMe = msg.senderId === userProfile?.uid;
                const isPlayingThisAudio = playingAudioId === msg.id;

                return (
                  <div
                    key={msg.id}
                    className={`flex items-end gap-2 ${isMe ? 'justify-end' : 'justify-start'}`}
                  >
                    {!isMe && (
                      <img
                        src={msg.senderPhoto}
                        alt={msg.senderName}
                        className="w-7 h-7 rounded-full object-cover shrink-0 mb-1"
                      />
                    )}

                    <div
                      className={`max-w-[82%] sm:max-w-md px-4 py-2.5 rounded-2xl shadow-xs text-xs relative ${
                        isMe
                          ? 'bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-br-none'
                          : darkMode
                          ? 'bg-slate-800 text-slate-200 rounded-bl-none border border-slate-700/50'
                          : 'bg-white text-slate-900 rounded-bl-none border border-slate-200'
                      }`}
                    >
                      {/* Sender Name in group chats */}
                      {!isMe && activeConversation.type === 'group' && (
                        <p className="font-bold text-[10px] text-blue-400 mb-0.5">
                          {msg.senderName}
                        </p>
                      )}

                      {/* Content */}
                      {msg.type === 'image' && msg.mediaUrl ? (
                        <div className="space-y-1">
                          <img
                            src={msg.mediaUrl}
                            alt="Sent image"
                            className="max-h-60 rounded-xl object-cover w-full cursor-pointer hover:opacity-95 transition-opacity"
                            onClick={() => window.open(msg.mediaUrl, '_blank')}
                          />
                          {msg.content && msg.content !== msg.mediaUrl && (
                            <p className="leading-relaxed font-normal whitespace-pre-wrap">{msg.content}</p>
                          )}
                        </div>
                      ) : msg.type === 'audio' ? (
                        <div className="flex items-center gap-3 py-1 min-w-[200px]">
                          <button
                            onClick={() => togglePlayAudio(msg.id)}
                            className="w-9 h-9 rounded-full bg-white/20 hover:bg-white/30 text-white flex items-center justify-center cursor-pointer transition-transform active:scale-95 shrink-0"
                          >
                            {isPlayingThisAudio ? (
                              <Pause className="w-4 h-4 fill-current" />
                            ) : (
                              <Play className="w-4 h-4 fill-current ml-0.5" />
                            )}
                          </button>

                          {/* Sound wave visualizer */}
                          <div className="flex-1 flex items-center gap-1">
                            {[16, 24, 38, 20, 32, 14, 28, 40, 22, 12, 30, 18].map((h, i) => (
                              <span
                                key={i}
                                className={`w-1 rounded-full transition-all ${
                                  isPlayingThisAudio
                                    ? 'bg-teal-300 animate-pulse'
                                    : 'bg-white/50'
                                }`}
                                style={{ height: `${h}px` }}
                              />
                            ))}
                          </div>
                          <span className="text-[10px] opacity-80 shrink-0">
                            0:0{msg.audioDuration || 4}
                          </span>
                        </div>
                      ) : (
                        <p className="leading-relaxed font-normal whitespace-pre-wrap">{msg.content}</p>
                      )}

                      {/* Timestamp & Delivery ticks */}
                      <div className="flex items-center justify-end gap-1 mt-1 text-[9px] opacity-75">
                        <span>
                          {new Date(msg.createdAt).toLocaleTimeString([], {
                            hour: '2-digit',
                            minute: '2-digit',
                          })}
                        </span>
                        {isMe && <CheckCheck className="w-3.5 h-3.5 text-teal-300" />}
                      </div>
                    </div>
                  </div>
                );
              })}
              <div ref={messagesEndRef} />
            </div>

            {/* Input Bar */}
            <div
              className={`p-3 sm:p-4 border-t ${
                darkMode ? 'bg-[#0B0F19]/90 border-slate-800' : 'bg-white border-slate-200'
              }`}
            >
              {/* Emoji quick drawer */}
              {showEmojiPicker && (
                <div className="flex items-center gap-2 pb-3 overflow-x-auto">
                  {['😊', '🔥', '❤️', '👏', '🚀', '🎉', '👍', '🙏', '💯', '😂'].map((emoji) => (
                    <button
                      key={emoji}
                      onClick={() => setMessageText((prev) => prev + emoji)}
                      className="text-lg p-1 hover:scale-125 transition-transform cursor-pointer"
                    >
                      {emoji}
                    </button>
                  ))}
                </div>
              )}

              {/* Recording voice state bar */}
              {isRecordingVoice ? (
                <div className="flex items-center justify-between bg-rose-500/10 border border-rose-500/20 px-4 py-2.5 rounded-full text-rose-400 text-xs">
                  <div className="flex items-center gap-2">
                    <span className="w-3 h-3 rounded-full bg-rose-500 animate-ping"></span>
                    <span className="font-semibold">Recording Voice Note ({recordingSeconds}s)...</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <button
                      onClick={() => setIsRecordingVoice(false)}
                      className="text-slate-400 hover:text-white cursor-pointer"
                    >
                      Cancel
                    </button>
                    <button
                      onClick={handleFinishVoiceRecord}
                      className="px-4 py-1 rounded-full bg-rose-600 text-white font-bold cursor-pointer"
                    >
                      Send Note
                    </button>
                  </div>
                </div>
              ) : (
                <form onSubmit={handleSendTextMessage} className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setShowEmojiPicker(!showEmojiPicker)}
                    className="p-2 rounded-full text-slate-400 hover:text-white cursor-pointer transition-colors"
                  >
                    <Smile className="w-5 h-5" />
                  </button>

                  {/* Hidden Gallery file picker for chat */}
                  <input
                    ref={chatFileInputRef}
                    type="file"
                    accept="image/*,video/*"
                    onChange={handleChatFileChange}
                    className="hidden"
                  />

                  <button
                    type="button"
                    onClick={() => chatFileInputRef.current?.click()}
                    className="p-2 rounded-full text-slate-400 hover:text-white cursor-pointer transition-colors"
                    title="Send Picture / Video from Gallery"
                  >
                    <ImageIcon className="w-5 h-5" />
                  </button>

                  <input
                    type="text"
                    value={messageText}
                    onChange={(e) => setMessageText(e.target.value)}
                    placeholder="Type a message..."
                    className={`flex-1 px-4 py-2.5 rounded-full text-xs outline-none border transition-colors ${
                      darkMode
                        ? 'bg-slate-900 border-slate-800 text-white placeholder-slate-500 focus:border-blue-500'
                        : 'bg-slate-100 border-slate-200 text-slate-900 placeholder-slate-400 focus:border-blue-500'
                    }`}
                  />

                  {messageText.trim() ? (
                    <button
                      type="submit"
                      className="p-2.5 rounded-full bg-blue-600 hover:bg-blue-500 text-white cursor-pointer shadow-md shadow-blue-500/20 transition-all active:scale-95"
                    >
                      <Send className="w-4 h-4" />
                    </button>
                  ) : (
                    <button
                      type="button"
                      onClick={() => setIsRecordingVoice(true)}
                      className="p-2.5 rounded-full bg-emerald-600 hover:bg-emerald-500 text-white cursor-pointer shadow-md shadow-emerald-600/20 transition-all active:scale-95"
                      title="Record Voice Note"
                    >
                      <Mic className="w-4 h-4" />
                    </button>
                  )}
                </form>
              )}
            </div>
          </>
        ) : (
          <div className="text-center p-8 space-y-3">
            <div className="w-16 h-16 rounded-full bg-blue-500/10 text-blue-500 mx-auto flex items-center justify-center">
              <Phone className="w-8 h-8" />
            </div>
            <h3 className="font-bold text-base">Select a Chat or Start a Call</h3>
            <p className="text-xs text-slate-400 max-w-xs mx-auto">
              Private 1-on-1 chats, group conversations, audio notes, and WebRTC video calls powered by SocialOne.
            </p>
          </div>
        )}
      </div>
    </div>
  );
};
