import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import {
  X,
  Wallet,
  CheckCircle2,
  DollarSign,
  ArrowRight,
  ShieldCheck,
  Building2,
  Download,
  AlertCircle,
  Fuel,
} from 'lucide-react';
import confetti from 'canvas-confetti';

interface CreatorCashoutModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const CreatorCashoutModal: React.FC<CreatorCashoutModalProps> = ({ isOpen, onClose }) => {
  const { userProfile, withdrawCreatorEarnings, darkMode } = useAuth();

  const [method, setMethod] = useState<'jazzcash' | 'easypaisa' | 'bank'>('jazzcash');
  const [accountNumber, setAccountNumber] = useState('03701220965');
  const [accountTitle, setAccountTitle] = useState(userProfile?.displayName || 'Creator Account');
  const [cnic, setCnic] = useState('42101-*******-7');
  const [amountUsd, setAmountUsd] = useState(
    userProfile?.walletBalance ? Math.min(25, userProfile.walletBalance).toString() : '10'
  );

  const [isProcessing, setIsProcessing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [receipt, setReceipt] = useState<any | null>(null);

  if (!isOpen) return null;

  const currentBalance = userProfile?.walletBalance || 0;
  const pkrRate = 280;
  const numericAmount = parseFloat(amountUsd) || 0;
  const amountPkr = Math.round(numericAmount * pkrRate);

  const handleQuickPercent = (pct: number) => {
    const val = Number(((currentBalance * pct) / 100).toFixed(2));
    setAmountUsd(val.toString());
  };

  const handleWithdraw = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (numericAmount <= 0) {
      setError('Please enter a valid withdrawal amount.');
      return;
    }
    if (numericAmount > currentBalance) {
      setError(`Insufficient balance. You have $${currentBalance.toFixed(2)} USD.`);
      return;
    }

    setIsProcessing(true);
    try {
      const res = await withdrawCreatorEarnings({
        method,
        accountTitle,
        accountNumber,
        amountUsd: numericAmount,
        cnic,
      });

      confetti({
        particleCount: 60,
        spread: 70,
        origin: { y: 0.6 },
      });

      setReceipt(res.transaction);
    } catch (err: any) {
      setError(err?.message || 'Withdrawal processing failed.');
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="fixed inset-0 z-60 bg-black/85 flex items-center justify-center p-3 sm:p-4 backdrop-blur-md overflow-y-auto">
      <div
        className={`relative w-full max-w-lg rounded-3xl border shadow-2xl overflow-hidden my-auto transition-all ${
          darkMode ? 'bg-slate-900 border-slate-800 text-white' : 'bg-white border-slate-200 text-slate-900'
        }`}
      >
        {/* Top Gradient Banner */}
        <div className="h-2 w-full bg-gradient-to-r from-emerald-500 via-teal-500 to-indigo-600" />

        {/* Header */}
        <div className="p-5 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-emerald-600 to-teal-500 flex items-center justify-center text-white shadow-lg shadow-emerald-500/20">
              <Fuel className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-black text-lg">Creator Payout / Petrol Lena</h3>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                  Instant Disbursal
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Withdraw your 75% Live gift earnings directly to JazzCash or EasyPaisa!
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-full text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Balance Card */}
        <div className="p-4 bg-gradient-to-r from-emerald-500/10 via-teal-500/10 to-indigo-500/10 border-b border-slate-800/80 flex items-center justify-between">
          <div>
            <span className="text-xs text-slate-400 font-medium">Your Withdrawable Live Earnings:</span>
            <div className="flex items-baseline gap-2 mt-0.5">
              <span className="text-2xl font-black text-emerald-400">${currentBalance.toFixed(2)} USD</span>
              <span className="text-xs text-slate-300 font-bold">
                (~Rs. {Math.round(currentBalance * pkrRate).toLocaleString()} PKR)
              </span>
            </div>
          </div>
          <div className="text-right">
            <span className="text-[10px] font-bold px-2 py-1 rounded-lg bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
              75% Creator Share
            </span>
          </div>
        </div>

        {receipt ? (
          /* Payout Success Receipt */
          <div className="p-6 text-center space-y-4">
            <div className="w-16 h-16 rounded-3xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-400 mx-auto flex items-center justify-center shadow-lg">
              <CheckCircle2 className="w-8 h-8" />
            </div>
            <div>
              <h4 className="text-xl font-black text-white">Payout Disbursed Successfully!</h4>
              <p className="text-xs text-slate-300 mt-1">
                Your live earnings ("Petrol") have been dispatched to your mobile account.
              </p>
            </div>

            {/* Mobile SMS Preview Box */}
            <div className="p-4 rounded-2xl bg-slate-950 border border-emerald-500/30 space-y-2 text-left font-mono text-xs">
              <div className="flex items-center justify-between pb-1 border-b border-slate-800 text-[11px] text-emerald-400">
                <span>📱 {receipt.method.toUpperCase()} SMS ALERT</span>
                <span>Just Now</span>
              </div>
              <p className="text-slate-200 text-xs leading-relaxed">
                Rs. {receipt.amountPkr.toLocaleString()} credited from SocialOne Live Platform to your account ({receipt.accountNumber}). TRX: {receipt.transactionId}. New Live Balance: ${userProfile?.walletBalance?.toFixed(2)} USD.
              </p>
            </div>

            <div className="p-3.5 rounded-2xl bg-slate-800/80 border border-slate-700/60 space-y-1.5 text-xs text-left">
              <div className="flex justify-between">
                <span className="text-slate-400">Account Title:</span>
                <span className="text-white font-bold">{receipt.accountTitle}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Channel:</span>
                <span className="text-teal-300 font-bold uppercase">{receipt.method}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Transaction ID:</span>
                <span className="text-slate-300 font-mono">{receipt.transactionId}</span>
              </div>
            </div>

            <button
              onClick={() => {
                setReceipt(null);
                onClose();
              }}
              className="w-full py-3 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:opacity-90 text-white font-bold text-xs cursor-pointer shadow-lg"
            >
              Done / Return to Profile
            </button>
          </div>
        ) : (
          /* Withdrawal Form */
          <form onSubmit={handleWithdraw} className="p-5 sm:p-6 space-y-4">
            {error && (
              <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/20 text-rose-400 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{error}</span>
              </div>
            )}

            {/* Payment Method Selector */}
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-2">
                1. Select Withdrawal Method:
              </label>
              <div className="grid grid-cols-3 gap-2">
                {/* JazzCash */}
                <button
                  type="button"
                  onClick={() => setMethod('jazzcash')}
                  className={`p-3 rounded-xl border text-center transition-all cursor-pointer flex flex-col items-center gap-1 ${
                    method === 'jazzcash'
                      ? 'bg-red-500/20 border-red-500 text-red-300 font-bold ring-2 ring-red-500/20'
                      : 'bg-slate-800/60 border-slate-700 text-slate-400 hover:text-white'
                  }`}
                >
                  <span className="text-base">🔴</span>
                  <span className="text-xs font-bold">JazzCash</span>
                  <span className="text-[9px] opacity-70">Instant</span>
                </button>

                {/* EasyPaisa */}
                <button
                  type="button"
                  onClick={() => setMethod('easypaisa')}
                  className={`p-3 rounded-xl border text-center transition-all cursor-pointer flex flex-col items-center gap-1 ${
                    method === 'easypaisa'
                      ? 'bg-emerald-500/20 border-emerald-500 text-emerald-300 font-bold ring-2 ring-emerald-500/20'
                      : 'bg-slate-800/60 border-slate-700 text-slate-400 hover:text-white'
                  }`}
                >
                  <span className="text-base">🟢</span>
                  <span className="text-xs font-bold">EasyPaisa</span>
                  <span className="text-[9px] opacity-70">Instant</span>
                </button>

                {/* Bank / Raast */}
                <button
                  type="button"
                  onClick={() => setMethod('bank')}
                  className={`p-3 rounded-xl border text-center transition-all cursor-pointer flex flex-col items-center gap-1 ${
                    method === 'bank'
                      ? 'bg-blue-500/20 border-blue-500 text-blue-300 font-bold ring-2 ring-blue-500/20'
                      : 'bg-slate-800/60 border-slate-700 text-slate-400 hover:text-white'
                  }`}
                >
                  <Building2 className="w-4 h-4 text-blue-400" />
                  <span className="text-xs font-bold">Bank/Raast</span>
                  <span className="text-[9px] opacity-70">1-hr Payout</span>
                </button>
              </div>
            </div>

            {/* Account Details */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">
                  {method === 'jazzcash'
                    ? 'JazzCash Mobile Number:'
                    : method === 'easypaisa'
                    ? 'EasyPaisa Account Number:'
                    : 'Bank Account / IBAN:'}
                </label>
                <input
                  type="text"
                  required
                  value={accountNumber}
                  onChange={(e) => setAccountNumber(e.target.value)}
                  placeholder="03001234567"
                  className="w-full px-3 py-2 rounded-xl bg-slate-800/80 border border-slate-700 text-white text-xs outline-none focus:border-emerald-400 font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">
                  Account Holder Title:
                </label>
                <input
                  type="text"
                  required
                  value={accountTitle}
                  onChange={(e) => setAccountTitle(e.target.value)}
                  placeholder="Your Full Name"
                  className="w-full px-3 py-2 rounded-xl bg-slate-800/80 border border-slate-700 text-white text-xs outline-none focus:border-emerald-400"
                />
              </div>
            </div>

            {/* Amount Selection */}
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-xs font-bold text-slate-300">
                  Withdrawal Amount (USD):
                </label>
                <div className="flex items-center gap-1.5">
                  <button
                    type="button"
                    onClick={() => handleQuickPercent(25)}
                    className="px-2 py-0.5 rounded-md bg-slate-800 text-[10px] text-slate-300 hover:text-white cursor-pointer"
                  >
                    25%
                  </button>
                  <button
                    type="button"
                    onClick={() => handleQuickPercent(50)}
                    className="px-2 py-0.5 rounded-md bg-slate-800 text-[10px] text-slate-300 hover:text-white cursor-pointer"
                  >
                    50%
                  </button>
                  <button
                    type="button"
                    onClick={() => handleQuickPercent(100)}
                    className="px-2 py-0.5 rounded-md bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-[10px] font-bold cursor-pointer"
                  >
                    Max 100%
                  </button>
                </div>
              </div>

              <div className="relative">
                <DollarSign className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
                <input
                  type="number"
                  step="0.01"
                  min="1"
                  max={currentBalance}
                  value={amountUsd}
                  onChange={(e) => setAmountUsd(e.target.value)}
                  className="w-full pl-8 pr-28 py-2 rounded-xl bg-slate-800/80 border border-slate-700 text-white text-sm font-bold outline-none focus:border-emerald-400 font-mono"
                />
                <span className="absolute right-3 top-2 text-xs font-bold text-emerald-400">
                  ≈ Rs. {amountPkr.toLocaleString()} PKR
                </span>
              </div>
            </div>

            {/* Submit Payout Button */}
            <div className="pt-2">
              <button
                type="submit"
                disabled={isProcessing || numericAmount <= 0 || numericAmount > currentBalance}
                className="w-full py-3.5 px-4 rounded-2xl bg-gradient-to-r from-emerald-600 via-teal-600 to-indigo-600 hover:opacity-95 text-white font-black text-sm flex items-center justify-center gap-2 shadow-xl shadow-emerald-500/20 cursor-pointer disabled:opacity-50 transition-all active:scale-[0.99]"
              >
                {isProcessing ? (
                  <div className="flex items-center gap-2">
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    <span>Processing Instant Disbursal...</span>
                  </div>
                ) : (
                  <>
                    <Fuel className="w-4 h-4" />
                    <span>Disburse Rs. {amountPkr.toLocaleString()} PKR via {method.toUpperCase()}</span>
                  </>
                )}
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
