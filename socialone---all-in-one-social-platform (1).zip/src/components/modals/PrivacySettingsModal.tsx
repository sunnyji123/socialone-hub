import React, { useState } from 'react';
import { useAuth, DEFAULT_USER_PRIVACY } from '../../context/AuthContext';
import { useApp } from '../../context/AppContext';
import {
  X,
  Shield,
  Lock,
  Eye,
  Clock,
  CheckCheck,
  MessageSquare,
  Download,
  UserCheck,
  Users,
  CheckCircle2,
  AlertCircle,
  Sparkles,
  Phone,
  Flame,
  UserX,
} from 'lucide-react';
import { UserPrivacySettings } from '../../types';

export const PrivacySettingsModal: React.FC = () => {
  const { userProfile, updatePrivacySettings, darkMode } = useAuth();
  const { isPrivacyModalOpen, setIsPrivacyModalOpen } = useApp();

  const [activeTab, setActiveTab] = useState<'all' | 'whatsapp' | 'tiktok'>('all');
  const [saving, setSaving] = useState(false);
  const [successToast, setSuccessToast] = useState(false);

  const currentPrivacy: UserPrivacySettings =
    userProfile?.privacySettings || DEFAULT_USER_PRIVACY;

  const [settings, setSettings] = useState<UserPrivacySettings>(currentPrivacy);

  // Sync if opened
  React.useEffect(() => {
    if (userProfile?.privacySettings) {
      setSettings(userProfile.privacySettings);
    }
  }, [userProfile?.privacySettings, isPrivacyModalOpen]);

  if (!isPrivacyModalOpen) return null;

  const handleToggle = (key: keyof UserPrivacySettings) => {
    setSettings((prev) => ({
      ...prev,
      [key]: !prev[key],
    }));
  };

  const handleSelect = <K extends keyof UserPrivacySettings>(key: K, value: UserPrivacySettings[K]) => {
    setSettings((prev) => ({
      ...prev,
      [key]: value,
    }));
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      await updatePrivacySettings(settings);
      setSuccessToast(true);
      setTimeout(() => setSuccessToast(false), 2400);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-3 sm:p-4 backdrop-blur-md overflow-y-auto">
      <div
        className={`relative w-full max-w-2xl rounded-3xl border shadow-2xl overflow-hidden my-auto transition-all ${
          darkMode ? 'bg-slate-900 border-slate-800 text-white' : 'bg-white border-slate-200 text-slate-900'
        }`}
      >
        {/* Top Header Banner */}
        <div className="h-2 w-full bg-gradient-to-r from-emerald-500 via-teal-500 to-rose-500" />

        {/* Modal Header */}
        <div className="p-5 sm:p-6 border-b border-slate-800/60 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-emerald-500 to-teal-600 flex items-center justify-center text-white shadow-lg shadow-emerald-500/20">
              <Shield className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-black text-lg tracking-tight">Privacy & Safety Center</h3>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                  WhatsApp & TikTok Level
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Control who sees your status, profile, comments, chats, and videos.
              </p>
            </div>
          </div>
          <button
            onClick={() => setIsPrivacyModalOpen(false)}
            className="p-2 rounded-full text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Filter Tabs */}
        <div className="px-6 pt-4 pb-2 border-b border-slate-800/40 flex items-center gap-2">
          <button
            onClick={() => setActiveTab('all')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              activeTab === 'all'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            All Settings
          </button>
          <button
            onClick={() => setActiveTab('whatsapp')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'whatsapp'
                ? 'bg-emerald-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <Phone className="w-3.5 h-3.5" />
            <span>WhatsApp Privacy</span>
          </button>
          <button
            onClick={() => setActiveTab('tiktok')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'tiktok'
                ? 'bg-rose-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <Flame className="w-3.5 h-3.5" />
            <span>TikTok Privacy</span>
          </button>
        </div>

        {/* Modal Scrollable Body */}
        <div className="p-5 sm:p-6 space-y-6 max-h-[68vh] overflow-y-auto">
          {/* SECTION 1: WHATSAPP PRIVACY */}
          {(activeTab === 'all' || activeTab === 'whatsapp') && (
            <div className="space-y-4">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
                <h4 className="text-xs font-extrabold uppercase tracking-wider text-emerald-400">
                  WhatsApp Messaging & Status Privacy
                </h4>
              </div>

              <div
                className={`p-4 rounded-2xl border space-y-4 ${
                  darkMode ? 'bg-slate-800/40 border-slate-700/60' : 'bg-slate-50 border-slate-200'
                }`}
              >
                {/* Last Seen & Online */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800/40">
                  <div className="space-y-0.5">
                    <div className="flex items-center gap-2">
                      <Eye className="w-4 h-4 text-emerald-400" />
                      <span className="text-xs font-bold">Last Seen & Online</span>
                    </div>
                    <p className="text-[11px] text-slate-400">
                      Who can see when you were last active on SocialOne.
                    </p>
                  </div>
                  <div className="flex items-center gap-1.5 self-start sm:self-auto">
                    {(['everyone', 'contacts', 'nobody'] as const).map((opt) => (
                      <button
                        key={opt}
                        type="button"
                        onClick={() => handleSelect('lastSeenVisibility', opt)}
                        className={`px-2.5 py-1 rounded-lg text-xs font-semibold capitalize transition-all cursor-pointer ${
                          settings.lastSeenVisibility === opt
                            ? 'bg-emerald-500 text-white shadow-xs'
                            : 'bg-slate-800 text-slate-400 hover:text-white'
                        }`}
                      >
                        {opt}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Read Receipts (Blue Ticks) */}
                <div className="flex items-center justify-between gap-3 pb-3 border-b border-slate-800/40">
                  <div className="space-y-0.5">
                    <div className="flex items-center gap-2">
                      <CheckCheck
                        className={`w-4 h-4 ${
                          settings.readReceipts ? 'text-sky-400' : 'text-slate-500'
                        }`}
                      />
                      <span className="text-xs font-bold">Read Receipts (Blue Ticks)</span>
                    </div>
                    <p className="text-[11px] text-slate-400">
                      If turned off, you won't send or see read receipts for direct messages.
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => handleToggle('readReceipts')}
                    className={`w-11 h-6 rounded-full transition-colors relative cursor-pointer ${
                      settings.readReceipts ? 'bg-emerald-500' : 'bg-slate-700'
                    }`}
                  >
                    <span
                      className={`block w-5 h-5 rounded-full bg-white transition-transform ${
                        settings.readReceipts ? 'translate-x-5' : 'translate-x-0.5'
                      }`}
                    />
                  </button>
                </div>

                {/* Online Status Indicator */}
                <div className="flex items-center justify-between gap-3 pb-3 border-b border-slate-800/40">
                  <div className="space-y-0.5">
                    <div className="flex items-center gap-2">
                      <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
                      <span className="text-xs font-bold">Show Online Status Indicator</span>
                    </div>
                    <p className="text-[11px] text-slate-400">
                      Display green online dot on your avatar when you are active.
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => handleToggle('showOnlineStatus')}
                    className={`w-11 h-6 rounded-full transition-colors relative cursor-pointer ${
                      settings.showOnlineStatus ? 'bg-emerald-500' : 'bg-slate-700'
                    }`}
                  >
                    <span
                      className={`block w-5 h-5 rounded-full bg-white transition-transform ${
                        settings.showOnlineStatus ? 'translate-x-5' : 'translate-x-0.5'
                      }`}
                    />
                  </button>
                </div>

                {/* Disappearing Messages Timer */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div className="space-y-0.5">
                    <div className="flex items-center gap-2">
                      <Clock className="w-4 h-4 text-emerald-400" />
                      <span className="text-xs font-bold">Default Disappearing Messages Timer</span>
                    </div>
                    <p className="text-[11px] text-slate-400">
                      Auto-delete chat messages after the selected timeframe.
                    </p>
                  </div>
                  <div className="flex items-center gap-1.5 self-start sm:self-auto flex-wrap">
                    {(['off', '24h', '7d', '90d'] as const).map((timer) => (
                      <button
                        key={timer}
                        type="button"
                        onClick={() => handleSelect('disappearingMessagesTimer', timer)}
                        className={`px-2.5 py-1 rounded-lg text-xs font-semibold uppercase transition-all cursor-pointer ${
                          settings.disappearingMessagesTimer === timer
                            ? 'bg-emerald-500 text-white shadow-xs'
                            : 'bg-slate-800 text-slate-400 hover:text-white'
                        }`}
                      >
                        {timer === 'off' ? 'Off' : timer}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* SECTION 2: TIKTOK PRIVACY */}
          {(activeTab === 'all' || activeTab === 'tiktok') && (
            <div className="space-y-4">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-rose-500" />
                <h4 className="text-xs font-extrabold uppercase tracking-wider text-rose-400">
                  TikTok Shorts & Video Privacy
                </h4>
              </div>

              <div
                className={`p-4 rounded-2xl border space-y-4 ${
                  darkMode ? 'bg-slate-800/40 border-slate-700/60' : 'bg-slate-50 border-slate-200'
                }`}
              >
                {/* Private Account */}
                <div className="flex items-center justify-between gap-3 pb-3 border-b border-slate-800/40">
                  <div className="space-y-0.5">
                    <div className="flex items-center gap-2">
                      <Lock className="w-4 h-4 text-rose-400" />
                      <span className="text-xs font-bold">Private Account</span>
                    </div>
                    <p className="text-[11px] text-slate-400">
                      Only users you approve can follow you and view your TikTok videos and live streams.
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => handleToggle('isPrivateAccount')}
                    className={`w-11 h-6 rounded-full transition-colors relative cursor-pointer ${
                      settings.isPrivateAccount ? 'bg-rose-500' : 'bg-slate-700'
                    }`}
                  >
                    <span
                      className={`block w-5 h-5 rounded-full bg-white transition-transform ${
                        settings.isPrivateAccount ? 'translate-x-5' : 'translate-x-0.5'
                      }`}
                    />
                  </button>
                </div>

                {/* Who can comment on videos */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800/40">
                  <div className="space-y-0.5">
                    <div className="flex items-center gap-2">
                      <MessageSquare className="w-4 h-4 text-rose-400" />
                      <span className="text-xs font-bold">Who Can Comment on Your Videos</span>
                    </div>
                    <p className="text-[11px] text-slate-400">
                      Filter who is allowed to post comments on your reels and shorts.
                    </p>
                  </div>
                  <div className="flex items-center gap-1.5 self-start sm:self-auto">
                    {(['everyone', 'followers', 'nobody'] as const).map((opt) => (
                      <button
                        key={opt}
                        type="button"
                        onClick={() => handleSelect('whoCanComment', opt)}
                        className={`px-2.5 py-1 rounded-lg text-xs font-semibold capitalize transition-all cursor-pointer ${
                          settings.whoCanComment === opt
                            ? 'bg-rose-500 text-white shadow-xs'
                            : 'bg-slate-800 text-slate-400 hover:text-white'
                        }`}
                      >
                        {opt}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Who can message me */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800/40">
                  <div className="space-y-0.5">
                    <div className="flex items-center gap-2">
                      <Users className="w-4 h-4 text-rose-400" />
                      <span className="text-xs font-bold">Who Can Send You Direct Messages (DMs)</span>
                    </div>
                    <p className="text-[11px] text-slate-400">
                      Restrict incoming private chat requests from strangers.
                    </p>
                  </div>
                  <div className="flex items-center gap-1.5 self-start sm:self-auto">
                    {(['everyone', 'followers', 'nobody'] as const).map((opt) => (
                      <button
                        key={opt}
                        type="button"
                        onClick={() => handleSelect('whoCanMessageMe', opt)}
                        className={`px-2.5 py-1 rounded-lg text-xs font-semibold capitalize transition-all cursor-pointer ${
                          settings.whoCanMessageMe === opt
                            ? 'bg-rose-500 text-white shadow-xs'
                            : 'bg-slate-800 text-slate-400 hover:text-white'
                        }`}
                      >
                        {opt}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Video Downloads Permission */}
                <div className="flex items-center justify-between gap-3">
                  <div className="space-y-0.5">
                    <div className="flex items-center gap-2">
                      <Download className="w-4 h-4 text-rose-400" />
                      <span className="text-xs font-bold">Allow Video Downloads</span>
                    </div>
                    <p className="text-[11px] text-slate-400">
                      Allow other users to save and download your videos to their device gallery.
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => handleToggle('allowVideoDownloads')}
                    className={`w-11 h-6 rounded-full transition-colors relative cursor-pointer ${
                      settings.allowVideoDownloads ? 'bg-rose-500' : 'bg-slate-700'
                    }`}
                  >
                    <span
                      className={`block w-5 h-5 rounded-full bg-white transition-transform ${
                        settings.allowVideoDownloads ? 'translate-x-5' : 'translate-x-0.5'
                      }`}
                    />
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* SECTION 3: BLOCKED ACCOUNTS SUMMARY */}
          <div
            className={`p-4 rounded-2xl border flex items-center justify-between gap-3 ${
              darkMode ? 'bg-slate-800/30 border-slate-700/50' : 'bg-slate-100 border-slate-200'
            }`}
          >
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-slate-800 text-slate-300 flex items-center justify-center">
                <UserX className="w-4 h-4" />
              </div>
              <div>
                <p className="text-xs font-bold">Blocked Accounts</p>
                <p className="text-[11px] text-slate-400">
                  {settings.blockedUserIds?.length || 0} users currently blocked
                </p>
              </div>
            </div>
            <span className="text-xs font-semibold text-slate-400">Secure</span>
          </div>

          {/* Feedback banner */}
          {successToast && (
            <div className="p-3 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-bold flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 shrink-0" />
              <span>Privacy settings updated successfully & synced with cloud!</span>
            </div>
          )}
        </div>

        {/* Footer actions */}
        <div className="p-5 border-t border-slate-800/60 flex items-center justify-end gap-3">
          <button
            type="button"
            onClick={() => setIsPrivacyModalOpen(false)}
            className="px-4 py-2.5 rounded-xl text-xs font-bold text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
          >
            Close
          </button>
          <button
            type="button"
            onClick={handleSave}
            disabled={saving}
            className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 via-teal-600 to-indigo-600 hover:opacity-95 text-white font-extrabold text-xs shadow-lg shadow-emerald-500/20 flex items-center gap-2 cursor-pointer disabled:opacity-50"
          >
            {saving ? (
              <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
            ) : (
              <CheckCircle2 className="w-4 h-4" />
            )}
            <span>Save Privacy Settings</span>
          </button>
        </div>
      </div>
    </div>
  );
};
