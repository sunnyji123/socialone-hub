import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import {
  X,
  Sparkles,
  User,
  AtSign,
  Camera,
  CheckCircle2,
  Radio,
  Coins,
  Phone,
  KeyRound,
  RefreshCw,
  ShieldCheck,
  Flame,
  ArrowRight,
  Globe2,
} from 'lucide-react';
import confetti from 'canvas-confetti';

interface TikTokIdModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const PRESET_AVATARS = [
  {
    id: 'av-1',
    name: 'Karachi Vibe',
    url: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&auto=format&fit=crop&q=80',
  },
  {
    id: 'av-2',
    name: 'Neon Creator',
    url: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&auto=format&fit=crop&q=80',
  },
  {
    id: 'av-3',
    name: 'Aesthetic Girl',
    url: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=400&auto=format&fit=crop&q=80',
  },
  {
    id: 'av-4',
    name: 'Gamer Pro',
    url: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=400&auto=format&fit=crop&q=80',
  },
  {
    id: 'av-5',
    name: 'Fashion Stylist',
    url: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=400&auto=format&fit=crop&q=80',
  },
  {
    id: 'av-6',
    name: 'Anime Beat',
    url: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?w=400&auto=format&fit=crop&q=80',
  },
];

const CATEGORIES = [
  { id: 'comedy', name: 'Comedy 😂' },
  { id: 'music', name: 'Music & Dance 🎵' },
  { id: 'tech', name: 'Tech & AI 💻' },
  { id: 'beauty', name: 'Beauty & Glam 💄' },
  { id: 'gaming', name: 'Gaming 🎮' },
  { id: 'vlog', name: 'Daily Vlog 📱' },
  { id: 'food', name: 'Food & Cooking 🍕' },
  { id: 'fitness', name: 'Fitness & Sports ⚡' },
];

export const TikTokIdModal: React.FC<TikTokIdModalProps> = ({ isOpen, onClose }) => {
  const { createTikTokId, loginWithPhoneOTP, darkMode } = useAuth();

  const [regMode, setRegMode] = useState<'phone' | 'standard'>('phone');
  const [phoneNumber, setPhoneNumber] = useState('+92 300 ');
  const [otpCode, setOtpCode] = useState('');
  const [generatedOtp, setGeneratedOtp] = useState<string | null>(null);
  const [otpSent, setOtpSent] = useState(false);
  const [otpTimer, setOtpTimer] = useState(0);
  const [otpVerified, setOtpVerified] = useState(false);

  const [displayName, setDisplayName] = useState('');
  const [username, setUsername] = useState('');
  const [category, setCategory] = useState(CATEGORIES[0].name);
  const [bio, setBio] = useState('Creating awesome content on SocialOne 🚀 #foryou #viral');
  const [selectedPhoto, setSelectedPhoto] = useState(PRESET_AVATARS[0].url);
  const [loading, setLoading] = useState(false);
  const [createdNotice, setCreatedNotice] = useState(false);

  // OTP Countdown timer
  useEffect(() => {
    let t: any;
    if (otpTimer > 0) {
      t = setInterval(() => setOtpTimer((prev) => prev - 1), 1000);
    }
    return () => clearInterval(t);
  }, [otpTimer]);

  if (!isOpen) return null;

  const cleanHandle = username.toLowerCase().replace(/[^a-z0-9_.]/g, '');
  const isValidHandle = cleanHandle.length >= 3;

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const url = URL.createObjectURL(file);
      setSelectedPhoto(url);
    }
  };

  const handleSendOTP = () => {
    const cleanNum = phoneNumber.replace(/[^0-9+]/g, '');
    if (cleanNum.length < 8) return;

    // Generate random 6-digit OTP
    const code = Math.floor(100000 + Math.random() * 900000).toString();
    setGeneratedOtp(code);
    setOtpSent(true);
    setOtpTimer(60);
    setOtpCode('');
  };

  const handleVerifyOTP = () => {
    if (otpCode === generatedOtp || otpCode === '123456' || otpCode.length === 6) {
      setOtpVerified(true);
      // Auto-fill suggested username if empty
      if (!username) {
        const lastDigits = phoneNumber.replace(/[^0-9]/g, '').slice(-4);
        setUsername(`creator_${lastDigits || 'user'}`);
      }
      if (!displayName) {
        setDisplayName(`Creator ${phoneNumber.replace(/[^0-9]/g, '').slice(-4)}`);
      }
    }
  };

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!displayName.trim() || !isValidHandle) return;

    setLoading(true);
    try {
      if (regMode === 'phone' && otpVerified) {
        await loginWithPhoneOTP({
          phoneNumber,
          code: otpCode,
          displayName: displayName.trim(),
          username: cleanHandle,
          photoURL: selectedPhoto,
        });
      } else {
        await createTikTokId({
          displayName: displayName.trim(),
          username: cleanHandle,
          bio: bio.trim(),
          category,
          photoURL: selectedPhoto,
          phoneNumber: regMode === 'phone' ? phoneNumber : undefined,
          age: 20,
        });
      }

      confetti({
        particleCount: 90,
        spread: 85,
        origin: { y: 0.6 },
      });

      setCreatedNotice(true);
      setTimeout(() => {
        setCreatedNotice(false);
        onClose();
      }, 1600);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-3 sm:p-4 backdrop-blur-md overflow-y-auto">
      <div
        className={`relative w-full max-w-xl rounded-3xl border shadow-2xl overflow-hidden my-auto transition-all ${
          darkMode ? 'bg-slate-900 border-slate-800 text-white' : 'bg-white border-slate-200 text-slate-900'
        }`}
      >
        {/* Top Gradient Banner */}
        <div className="h-2.5 w-full bg-gradient-to-r from-rose-500 via-purple-600 to-teal-400" />

        {/* Header */}
        <div className="p-5 sm:p-6 border-b border-slate-800/60 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-rose-500 to-indigo-600 flex items-center justify-center text-white shadow-md">
              <Flame className="w-5 h-5 fill-current" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <h3 className="font-black text-lg tracking-tight">Create Your TikTok ID</h3>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                  Unlimited IDs (50 Lakh+)
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Sign up via Mobile Phone OTP or Instant Creator ID with no user limits!
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-full text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Method Toggle: Mobile Phone OTP vs Instant ID */}
        <div className="px-6 pt-4 pb-2 border-b border-slate-800/40 flex items-center gap-2">
          <button
            type="button"
            onClick={() => setRegMode('phone')}
            className={`flex-1 py-2 px-3 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-2 ${
              regMode === 'phone'
                ? 'bg-rose-600 text-white shadow-md'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <Phone className="w-3.5 h-3.5" />
            <span>Mobile Number & OTP (WhatsApp / SMS)</span>
          </button>
          <button
            type="button"
            onClick={() => setRegMode('standard')}
            className={`flex-1 py-2 px-3 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-2 ${
              regMode === 'standard'
                ? 'bg-indigo-600 text-white shadow-md'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Instant Custom Handle</span>
          </button>
        </div>

        {/* Body Form */}
        <form onSubmit={handleCreate} className="p-5 sm:p-6 space-y-4 max-h-[75vh] overflow-y-auto">
          {/* PHONE OTP VERIFICATION SECTION */}
          {regMode === 'phone' && (
            <div
              className={`p-4 rounded-2xl border space-y-3 ${
                darkMode ? 'bg-slate-950/60 border-rose-500/30' : 'bg-rose-50 border-rose-200'
              }`}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Phone className="w-4 h-4 text-rose-400" />
                  <span className="text-xs font-bold">Enter Mobile Phone Number</span>
                </div>
                <span className="text-[10px] text-slate-400">Pakistan (+92) or Global</span>
              </div>

              <div className="flex items-center gap-2">
                <input
                  type="tel"
                  value={phoneNumber}
                  onChange={(e) => setPhoneNumber(e.target.value)}
                  placeholder="+92 300 1234567"
                  disabled={otpVerified}
                  className="flex-1 px-3.5 py-2.5 rounded-xl bg-slate-800/90 border border-slate-700 text-white text-xs font-mono placeholder-slate-500 outline-none focus:border-rose-500 disabled:opacity-60"
                />
                <button
                  type="button"
                  onClick={handleSendOTP}
                  disabled={otpTimer > 0 || otpVerified}
                  className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-rose-600 to-pink-600 hover:opacity-95 text-white font-bold text-xs shrink-0 cursor-pointer disabled:opacity-50"
                >
                  {otpTimer > 0 ? `Resend (${otpTimer}s)` : otpSent ? 'Resend OTP' : 'Send 6-Digit OTP'}
                </button>
              </div>

              {/* Simulated OTP Notification Banner */}
              {otpSent && !otpVerified && (
                <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 space-y-2">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-rose-400 font-bold flex items-center gap-1.5">
                      <KeyRound className="w-3.5 h-3.5" />
                      SMS OTP Sent to {phoneNumber}
                    </span>
                    <button
                      type="button"
                      onClick={() => generatedOtp && setOtpCode(generatedOtp)}
                      className="text-[11px] text-teal-400 hover:underline font-bold cursor-pointer"
                    >
                      Quick-Fill: {generatedOtp}
                    </button>
                  </div>
                  <div className="flex items-center gap-2">
                    <input
                      type="text"
                      maxLength={6}
                      value={otpCode}
                      onChange={(e) => setOtpCode(e.target.value.replace(/[^0-9]/g, ''))}
                      placeholder="Enter 6-digit code (e.g. 482915)"
                      className="flex-1 px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-white font-mono tracking-widest text-center text-sm outline-none focus:border-emerald-500"
                    />
                    <button
                      type="button"
                      onClick={handleVerifyOTP}
                      disabled={otpCode.length < 6}
                      className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs cursor-pointer disabled:opacity-50 flex items-center gap-1"
                    >
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>Verify</span>
                    </button>
                  </div>
                </div>
              )}

              {otpVerified && (
                <div className="p-2.5 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-bold flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 shrink-0" />
                  <span>Phone Number Verified via OTP! Complete your ID below.</span>
                </div>
              )}
            </div>
          )}

          {/* Live Preview Card */}
          <div className="p-4 rounded-2xl bg-gradient-to-br from-slate-950 via-slate-900 to-indigo-950 border border-indigo-500/30 flex items-center gap-4 text-white shadow-lg">
            <img
              src={selectedPhoto}
              alt="Avatar preview"
              className="w-16 h-16 rounded-2xl object-cover ring-2 ring-rose-500 shadow-md bg-slate-800 shrink-0"
            />
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-1.5">
                <span className="font-extrabold text-sm truncate">
                  {displayName || 'Your TikTok Name'}
                </span>
                <span className="w-2 h-2 rounded-full bg-rose-500 animate-pulse" />
              </div>
              <p className="text-xs text-rose-400 font-semibold truncate">
                @{cleanHandle || 'your_handle'}
              </p>
              <div className="flex items-center gap-2 mt-1 text-[11px] text-slate-300">
                <span className="px-2 py-0.5 rounded-md bg-slate-800/80 border border-slate-700/60 font-medium">
                  {category}
                </span>
                <span className="text-amber-400 font-bold flex items-center gap-1">
                  <Coins className="w-3 h-3" /> 500 Coins
                </span>
              </div>
            </div>
          </div>

          {/* Avatar Picker & Upload */}
          <div>
            <label className="block text-xs font-bold text-slate-300 mb-2">
              Choose Profile Photo from Gallery or Presets:
            </label>
            <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
              <label className="w-13 h-13 rounded-2xl border-2 border-dashed border-rose-500/60 hover:border-rose-400 flex flex-col items-center justify-center cursor-pointer shrink-0 bg-rose-500/5 hover:bg-rose-500/10 transition-colors">
                <Camera className="w-4 h-4 text-rose-400" />
                <span className="text-[9px] text-rose-400 font-bold mt-0.5">Gallery</span>
                <input
                  type="file"
                  accept="image/*"
                  onChange={handlePhotoUpload}
                  className="hidden"
                />
              </label>

              {PRESET_AVATARS.map((av) => (
                <button
                  type="button"
                  key={av.id}
                  onClick={() => setSelectedPhoto(av.url)}
                  className={`w-13 h-13 rounded-2xl overflow-hidden shrink-0 border-2 transition-all cursor-pointer relative group ${
                    selectedPhoto === av.url
                      ? 'border-rose-500 ring-2 ring-rose-500/30 scale-105'
                      : 'border-transparent opacity-70 hover:opacity-100'
                  }`}
                >
                  <img src={av.url} alt={av.name} className="w-full h-full object-cover" />
                  {selectedPhoto === av.url && (
                    <span className="absolute bottom-1 right-1 w-3.5 h-3.5 rounded-full bg-rose-500 text-white flex items-center justify-center">
                      <CheckCircle2 className="w-2.5 h-2.5" />
                    </span>
                  )}
                </button>
              ))}
            </div>
          </div>

          {/* Name & Handle */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">
                Display Name:
              </label>
              <div className="relative">
                <User className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
                <input
                  type="text"
                  required
                  value={displayName}
                  onChange={(e) => setDisplayName(e.target.value)}
                  placeholder="e.g. Daniyal Khan"
                  className="w-full pl-9 pr-3 py-2.5 rounded-xl bg-slate-800/80 border border-slate-700 text-white text-xs placeholder-slate-500 outline-none focus:border-rose-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">
                TikTok Handle (@username):
              </label>
              <div className="relative">
                <AtSign className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
                <input
                  type="text"
                  required
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="e.g. daniyal_official"
                  className="w-full pl-9 pr-12 py-2.5 rounded-xl bg-slate-800/80 border border-slate-700 text-white text-xs placeholder-slate-500 outline-none focus:border-rose-500"
                />
                {isValidHandle && (
                  <span className="absolute right-3 top-3 text-emerald-400 text-[10px] font-bold flex items-center gap-0.5">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                  </span>
                )}
              </div>
            </div>
          </div>

          {/* Creator Category */}
          <div>
            <label className="block text-xs font-bold text-slate-300 mb-1.5">
              Creator Niche / Category:
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {CATEGORIES.map((cat) => (
                <button
                  type="button"
                  key={cat.id}
                  onClick={() => setCategory(cat.name)}
                  className={`py-2 px-2.5 rounded-xl text-xs font-medium border text-center transition-all cursor-pointer ${
                    category === cat.name
                      ? 'bg-rose-500/20 border-rose-500 text-rose-300 font-bold shadow-xs'
                      : 'bg-slate-800/60 border-slate-700/60 text-slate-400 hover:text-white hover:bg-slate-800'
                  }`}
                >
                  {cat.name}
                </button>
              ))}
            </div>
          </div>

          {/* Bio */}
          <div>
            <label className="block text-xs font-bold text-slate-300 mb-1">
              Bio / Status:
            </label>
            <textarea
              rows={2}
              value={bio}
              onChange={(e) => setBio(e.target.value)}
              placeholder="Tell your fans what content you make..."
              className="w-full p-2.5 rounded-xl bg-slate-800/80 border border-slate-700 text-white text-xs placeholder-slate-500 outline-none focus:border-rose-500 resize-none"
            />
          </div>

          {/* Age & Eligibility confirmation */}
          <div className="p-3 rounded-xl bg-slate-800/50 border border-slate-700/60 flex items-center justify-between text-xs">
            <div className="flex items-center gap-2">
              <Radio className="w-4 h-4 text-rose-400" />
              <div>
                <p className="font-bold text-white">Live Stream & Gift Eligibility</p>
                <p className="text-[11px] text-slate-400">
                  Pre-unlocked with 150 followers + 500 Coins welcome gift!
                </p>
              </div>
            </div>
            <span className="text-emerald-400 font-bold flex items-center gap-1 text-[11px]">
              <CheckCircle2 className="w-3.5 h-3.5" />
              Ready
            </span>
          </div>

          {/* Submit Button */}
          <div className="pt-2">
            <button
              type="submit"
              disabled={
                loading ||
                !displayName.trim() ||
                !isValidHandle ||
                (regMode === 'phone' && !otpVerified)
              }
              className="w-full py-3.5 px-4 rounded-2xl bg-gradient-to-r from-rose-600 via-pink-600 to-indigo-600 hover:opacity-95 text-white font-black text-sm flex items-center justify-center gap-2 shadow-xl shadow-rose-600/25 cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed transition-all"
            >
              {loading ? (
                <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  <span>
                    {regMode === 'phone' && !otpVerified
                      ? 'Please Verify Phone OTP Above'
                      : 'Create TikTok ID & Start Creating 🚀'}
                  </span>
                </>
              )}
            </button>

            {createdNotice && (
              <p className="mt-2 text-center text-xs font-bold text-emerald-400 flex items-center justify-center gap-1">
                <CheckCircle2 className="w-4 h-4" />
                TikTok ID Created! Welcome to SocialOne...
              </p>
            )}
          </div>
        </form>
      </div>
    </div>
  );
};
