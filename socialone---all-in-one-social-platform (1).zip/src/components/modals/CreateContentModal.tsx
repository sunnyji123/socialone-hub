import React, { useState, useRef } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useApp } from '../../context/AppContext';
import {
  X,
  FileText,
  Video,
  Flame,
  Users,
  Image as ImageIcon,
  Music,
  Camera,
  FolderOpen,
  Film,
  Sparkles,
} from 'lucide-react';

export const CreateContentModal: React.FC = () => {
  const { userProfile, darkMode } = useAuth();
  const {
    isCreateModalOpen,
    setIsCreateModalOpen,
    createPost,
    uploadShortVideo,
    createStory,
    createGroup,
    groups,
    setActiveTab,
    setIsTikTokStudioOpen,
  } = useApp();

  const [createTab, setCreateTab] = useState<'post' | 'video' | 'story' | 'group'>('post');

  // Post form state
  const [postContent, setPostContent] = useState('');
  const [postMediaUrl, setPostMediaUrl] = useState('');
  const [postMediaType, setPostMediaType] = useState<'none' | 'image' | 'video'>('none');
  const [postMediaName, setPostMediaName] = useState('');
  const [selectedGroupId, setSelectedGroupId] = useState('');

  // Short video form state
  const [videoUrl, setVideoUrl] = useState('');
  const [videoCaption, setVideoCaption] = useState('');
  const [videoMusic, setVideoMusic] = useState('Original Sound - ' + (userProfile?.displayName || 'Creator'));
  const [videoTags, setVideoTags] = useState('socialone, viral, shorts');
  const [videoFileName, setVideoFileName] = useState('');

  // Story form state
  const [storyImageUrl, setStoryImageUrl] = useState('');
  const [storyCaption, setStoryCaption] = useState('');
  const [storyFileName, setStoryFileName] = useState('');

  // Group form state
  const [groupName, setGroupName] = useState('');
  const [groupDesc, setGroupDesc] = useState('');
  const [groupCover, setGroupCover] = useState('https://images.unsplash.com/photo-1519389950473-47ba0277781c?w=1000&auto=format&fit=crop&q=80');

  // File input refs for Gallery
  const postFileRef = useRef<HTMLInputElement | null>(null);
  const videoFileRef = useRef<HTMLInputElement | null>(null);
  const storyFileRef = useRef<HTMLInputElement | null>(null);

  if (!isCreateModalOpen) return null;

  // Handle Post Gallery File Pick (image or video)
  const handlePostFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const isVideo = file.type.startsWith('video/');
    const url = URL.createObjectURL(file);
    setPostMediaUrl(url);
    setPostMediaType(isVideo ? 'video' : 'image');
    setPostMediaName(file.name);
  };

  // Handle Short Video Gallery Pick
  const handleVideoFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const url = URL.createObjectURL(file);
    setVideoUrl(url);
    setVideoFileName(file.name);
    if (!videoCaption) {
      setVideoCaption(file.name.replace(/\.[^/.]+$/, ''));
    }
  };

  // Handle Story Gallery Pick
  const handleStoryFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const url = URL.createObjectURL(file);
    setStoryImageUrl(url);
    setStoryFileName(file.name);
  };

  const handlePostSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!postContent.trim()) return;
    const mediaUrls = postMediaUrl.trim() ? [postMediaUrl.trim()] : [];
    await createPost(
      postContent.trim(),
      mediaUrls,
      mediaUrls.length > 0 ? postMediaType : 'none',
      selectedGroupId || undefined
    );
    setIsCreateModalOpen(false);
    setPostContent('');
    setPostMediaUrl('');
    setPostMediaType('none');
    setActiveTab('home');
  };

  const handleVideoSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!videoUrl.trim() || !videoCaption.trim()) return;
    const tags = videoTags
      .split(',')
      .map((t) => t.trim().replace(/^#/, ''))
      .filter(Boolean);
    await uploadShortVideo(videoUrl.trim(), videoCaption.trim(), tags, videoMusic.trim());
    setIsCreateModalOpen(false);
    setActiveTab('videos');
  };

  const handleStorySubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!storyImageUrl.trim()) return;
    await createStory(storyImageUrl.trim(), storyCaption.trim() || undefined);
    setIsCreateModalOpen(false);
    setActiveTab('home');
  };

  const handleGroupSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!groupName.trim() || !groupDesc.trim()) return;
    await createGroup(
      groupName.trim(),
      groupDesc.trim(),
      groupCover.trim(),
      'https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?w=400&auto=format&fit=crop&q=80',
      false,
      ['Be respectful to all members', 'Constructive discussions only']
    );
    setIsCreateModalOpen(false);
    setActiveTab('groups');
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4">
          <div
            className={`max-w-xl w-full rounded-3xl border shadow-2xl overflow-hidden flex flex-col transition-colors ${
              darkMode ? 'bg-slate-900 border-slate-800 text-white' : 'bg-white border-slate-200 text-slate-900'
            }`}
          >
            {/* Header */}
            <div className="p-4 sm:p-5 border-b border-slate-800/40 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-blue-600 to-indigo-600 flex items-center justify-center text-white font-bold text-sm">
                  +
                </div>
                <h3 className="font-bold text-base">Create & Upload Content</h3>
              </div>
              <button
                onClick={() => setIsCreateModalOpen(false)}
                className="p-1.5 rounded-full hover:bg-slate-800 text-slate-400 hover:text-white cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Tab Picker */}
            <div
              className={`flex items-center justify-around p-1.5 border-b border-slate-800/40 text-xs font-bold ${
                darkMode ? 'bg-slate-950/40' : 'bg-slate-100/70'
              }`}
            >
              <button
                onClick={() => setCreateTab('post')}
                className={`flex-1 py-2 rounded-xl transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                  createTab === 'post'
                    ? 'bg-blue-600 text-white shadow-xs'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <FileText className="w-4 h-4" />
                <span>Feed Post</span>
              </button>

              <button
                onClick={() => setCreateTab('video')}
                className={`flex-1 py-2 rounded-xl transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                  createTab === 'video'
                    ? 'bg-blue-600 text-white shadow-xs'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <Video className="w-4 h-4" />
                <span>Short Reel</span>
              </button>

              <button
                onClick={() => setCreateTab('story')}
                className={`flex-1 py-2 rounded-xl transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                  createTab === 'story'
                    ? 'bg-blue-600 text-white shadow-xs'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <Flame className="w-4 h-4" />
                <span>24h Story</span>
              </button>

              <button
                onClick={() => setCreateTab('group')}
                className={`flex-1 py-2 rounded-xl transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                  createTab === 'group'
                    ? 'bg-blue-600 text-white shadow-xs'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <Users className="w-4 h-4" />
                <span>Community</span>
              </button>
            </div>

            {/* Tab Bodies */}
            <div className="p-5 overflow-y-auto max-h-[70vh]">
              {/* TAB 1: Feed Post with Gallery */}
              {createTab === 'post' && (
                <form onSubmit={handlePostSubmit} className="space-y-4">
                  {/* Hidden file input for Gallery */}
                  <input
                    ref={postFileRef}
                    type="file"
                    accept="image/*,video/*"
                    onChange={handlePostFileChange}
                    className="hidden"
                  />

                  <textarea
                    value={postContent}
                    onChange={(e) => setPostContent(e.target.value)}
                    placeholder="What's on your mind? Share your thoughts, story, or questions..."
                    rows={4}
                    className={`w-full p-4 rounded-2xl text-xs sm:text-sm border outline-none ${
                      darkMode ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-100 border-slate-300 text-slate-900'
                    }`}
                    autoFocus
                  />

                  {/* Gallery Upload Card */}
                  <div className="space-y-2">
                    <label className="block text-xs font-semibold text-slate-400">
                      Picture / Video Attachment
                    </label>

                    {postMediaUrl ? (
                      <div className="relative rounded-2xl overflow-hidden border border-slate-700 bg-black/40">
                        {postMediaType === 'video' ? (
                          <video
                            src={postMediaUrl}
                            controls
                            className="w-full max-h-56 object-contain"
                          />
                        ) : (
                          <img
                            src={postMediaUrl}
                            alt="Selected"
                            className="w-full max-h-56 object-cover"
                          />
                        )}

                        <div className="p-2.5 bg-slate-900/90 flex items-center justify-between text-xs">
                          <span className="truncate text-slate-300 font-medium">
                            {postMediaName || 'Attached Media'}
                          </span>
                          <button
                            type="button"
                            onClick={() => {
                              setPostMediaUrl('');
                              setPostMediaType('none');
                              setPostMediaName('');
                            }}
                            className="text-rose-400 hover:text-rose-300 font-bold cursor-pointer"
                          >
                            Remove
                          </button>
                        </div>
                      </div>
                    ) : (
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                        {/* Gallery Button */}
                        <button
                          type="button"
                          onClick={() => postFileRef.current?.click()}
                          className={`p-4 rounded-2xl border-2 border-dashed flex items-center justify-center gap-2 cursor-pointer transition-all ${
                            darkMode
                              ? 'border-blue-500/40 hover:border-blue-500 hover:bg-blue-500/10 text-blue-400'
                              : 'border-blue-400 hover:border-blue-600 hover:bg-blue-50 text-blue-600'
                          }`}
                        >
                          <FolderOpen className="w-5 h-5" />
                          <span className="text-xs font-bold">Choose from Gallery / Files</span>
                        </button>

                        {/* Optional URL button */}
                        <button
                          type="button"
                          onClick={() => {
                            const url = prompt('Enter image or video URL:');
                            if (url) {
                              setPostMediaUrl(url);
                              setPostMediaType(url.endsWith('.mp4') ? 'video' : 'image');
                            }
                          }}
                          className={`p-4 rounded-2xl border flex items-center justify-center gap-2 cursor-pointer transition-all ${
                            darkMode
                              ? 'border-slate-800 hover:border-slate-700 text-slate-400 hover:text-white'
                              : 'border-slate-200 hover:border-slate-300 text-slate-600'
                          }`}
                        >
                          <ImageIcon className="w-5 h-5" />
                          <span className="text-xs font-medium">Paste Image/Video URL</span>
                        </button>
                      </div>
                    )}
                  </div>

                  {/* Group attachment selector */}
                  <div>
                    <label className="block text-xs text-slate-400 mb-1">
                      Post to Community Group (Optional)
                    </label>
                    <select
                      value={selectedGroupId}
                      onChange={(e) => setSelectedGroupId(e.target.value)}
                      className={`w-full px-3.5 py-2.5 rounded-xl text-xs border outline-none ${
                        darkMode ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-100 border-slate-300 text-slate-900'
                      }`}
                    >
                      <option value="">Public SocialOne Feed (Default)</option>
                      {groups.map((g) => (
                        <option key={g.id} value={g.id}>
                          {g.name}
                        </option>
                      ))}
                    </select>
                  </div>

                  <button
                    type="submit"
                    disabled={!postContent.trim()}
                    className="w-full py-3 rounded-2xl font-bold text-sm text-white bg-blue-600 hover:bg-blue-500 disabled:opacity-50 cursor-pointer shadow-md transition-all active:scale-[0.99]"
                  >
                    Publish Post
                  </button>
                </form>
              )}

              {/* TAB 2: Short Reel (TikTok Camera Studio OR Gallery Video) */}
              {createTab === 'video' && (
                <div className="space-y-5">
                  {/* Hidden file input for Video & Photo Gallery */}
                  <input
                    ref={videoFileRef}
                    type="file"
                    accept="video/*,image/*"
                    onChange={handleVideoFileChange}
                    className="hidden"
                  />

                  {/* Big TikTok Camera Recording Studio Banner */}
                  <div className="p-5 rounded-3xl bg-gradient-to-r from-rose-600 via-purple-600 to-indigo-600 text-white shadow-xl flex flex-col sm:flex-row items-center justify-between gap-4">
                    <div className="space-y-1 text-center sm:text-left">
                      <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-white/20 text-[10px] font-bold">
                        <Sparkles className="w-3 h-3 text-amber-300" />
                        <span>TikTok Camera Experience</span>
                      </div>
                      <h4 className="text-base font-black">Record Video Like TikTok</h4>
                      <p className="text-xs text-white/80">
                        Live camera recording, 15s/60s timer, beauty filters, and trending sound tracks.
                      </p>
                    </div>

                    <button
                      type="button"
                      onClick={() => {
                        setIsCreateModalOpen(false);
                        setIsTikTokStudioOpen(true);
                      }}
                      className="px-5 py-3 rounded-2xl font-bold text-xs bg-white text-slate-900 hover:bg-slate-100 shadow-lg flex items-center gap-2 cursor-pointer transition-transform active:scale-95 shrink-0"
                    >
                      <Camera className="w-4 h-4 text-rose-600" />
                      <span>Open TikTok Camera</span>
                    </button>
                  </div>

                  {/* Or Pick from Gallery */}
                  <div className="relative flex items-center justify-center my-3">
                    <span className="h-px bg-slate-800 w-full" />
                    <span className="px-3 text-[11px] text-slate-400 uppercase font-bold shrink-0">
                      OR Pick Picture / Video From Phone Gallery
                    </span>
                    <span className="h-px bg-slate-800 w-full" />
                  </div>

                  <form onSubmit={handleVideoSubmit} className="space-y-4">
                    {/* Gallery Video/Photo Selection Card */}
                    {videoUrl ? (
                      <div className="relative rounded-2xl overflow-hidden border border-slate-700 bg-black">
                        {videoFileName?.match(/\.(jpeg|jpg|gif|png|webp)$/i) || videoUrl.startsWith('data:image/') ? (
                          <img
                            src={videoUrl}
                            alt="Reel preview"
                            className="w-full max-h-56 object-contain"
                          />
                        ) : (
                          <video
                            src={videoUrl}
                            controls
                            className="w-full max-h-56 object-contain"
                          />
                        )}
                        <div className="p-2.5 bg-slate-900 flex items-center justify-between text-xs">
                          <span className="truncate font-medium text-slate-300">
                            {videoFileName || 'Selected Gallery Media'}
                          </span>
                          <button
                            type="button"
                            onClick={() => {
                              setVideoUrl('');
                              setVideoFileName('');
                            }}
                            className="text-rose-400 hover:text-rose-300 font-bold cursor-pointer"
                          >
                            Remove
                          </button>
                        </div>
                      </div>
                    ) : (
                      <div className="space-y-2">
                        <button
                          type="button"
                          onClick={() => videoFileRef.current?.click()}
                          className={`w-full p-6 rounded-2xl border-2 border-dashed flex flex-col items-center justify-center gap-2 cursor-pointer transition-all ${
                            darkMode
                              ? 'border-purple-500/40 hover:border-purple-500 hover:bg-purple-500/10 text-purple-400'
                              : 'border-purple-400 hover:border-purple-600 hover:bg-purple-50 text-purple-600'
                          }`}
                        >
                          <Film className="w-8 h-8" />
                          <span className="text-xs font-bold">
                            Select Video from Phone / PC Gallery
                          </span>
                          <span className="text-[10px] text-slate-400">
                            Supports MP4, MOV, WebM vertical videos
                          </span>
                        </button>
                      </div>
                    )}

                    <div>
                      <label className="block text-xs text-slate-400 mb-1">Reel Caption</label>
                      <input
                        type="text"
                        value={videoCaption}
                        onChange={(e) => setVideoCaption(e.target.value)}
                        placeholder="Caption for your short video..."
                        className={`w-full px-3.5 py-2.5 rounded-xl text-xs border outline-none ${
                          darkMode ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-100 border-slate-300 text-slate-900'
                        }`}
                      />
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div>
                        <label className="block text-xs text-slate-400 mb-1 flex items-center gap-1">
                          <Music className="w-3.5 h-3.5 text-indigo-400" />
                          <span>Music Track</span>
                        </label>
                        <input
                          type="text"
                          value={videoMusic}
                          onChange={(e) => setVideoMusic(e.target.value)}
                          className={`w-full px-3.5 py-2.5 rounded-xl text-xs border outline-none ${
                            darkMode ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-100 border-slate-300 text-slate-900'
                          }`}
                        />
                      </div>

                      <div>
                        <label className="block text-xs text-slate-400 mb-1">Hashtags</label>
                        <input
                          type="text"
                          value={videoTags}
                          onChange={(e) => setVideoTags(e.target.value)}
                          placeholder="tag1, tag2, tag3"
                          className={`w-full px-3.5 py-2.5 rounded-xl text-xs border outline-none ${
                            darkMode ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-100 border-slate-300 text-slate-900'
                          }`}
                        />
                      </div>
                    </div>

                    <button
                      type="submit"
                      disabled={!videoCaption.trim() || !videoUrl.trim()}
                      className="w-full py-3 rounded-2xl font-bold text-sm text-white bg-gradient-to-r from-blue-600 to-indigo-600 hover:opacity-95 disabled:opacity-50 cursor-pointer shadow-md transition-all active:scale-[0.99]"
                    >
                      Publish Short Video
                    </button>
                  </form>
                </div>
              )}

              {/* TAB 3: 24h Story with Gallery */}
              {createTab === 'story' && (
                <form onSubmit={handleStorySubmit} className="space-y-4">
                  <input
                    ref={storyFileRef}
                    type="file"
                    accept="image/*"
                    onChange={handleStoryFileChange}
                    className="hidden"
                  />

                  {storyImageUrl ? (
                    <div className="relative rounded-2xl overflow-hidden border border-slate-700 bg-black">
                      <img
                        src={storyImageUrl}
                        alt="Story preview"
                        className="w-full max-h-60 object-cover"
                      />
                      <div className="p-2.5 bg-slate-900 flex items-center justify-between text-xs">
                        <span className="truncate font-medium text-slate-300">
                          {storyFileName || 'Selected Story Photo'}
                        </span>
                        <button
                          type="button"
                          onClick={() => {
                            setStoryImageUrl('');
                            setStoryFileName('');
                          }}
                          className="text-rose-400 hover:text-rose-300 font-bold cursor-pointer"
                        >
                          Change Photo
                        </button>
                      </div>
                    </div>
                  ) : (
                    <button
                      type="button"
                      onClick={() => storyFileRef.current?.click()}
                      className={`w-full p-6 rounded-2xl border-2 border-dashed flex flex-col items-center justify-center gap-2 cursor-pointer transition-all ${
                        darkMode
                          ? 'border-pink-500/40 hover:border-pink-500 hover:bg-pink-500/10 text-pink-400'
                          : 'border-pink-400 hover:border-pink-600 hover:bg-pink-50 text-pink-600'
                      }`}
                    >
                      <FolderOpen className="w-8 h-8" />
                      <span className="text-xs font-bold">Pick Story Photo from Gallery</span>
                      <span className="text-[10px] text-slate-400">
                        Choose any picture from your device camera roll
                      </span>
                    </button>
                  )}

                  <div>
                    <label className="block text-xs text-slate-400 mb-1">Story Caption / Note</label>
                    <input
                      type="text"
                      value={storyCaption}
                      onChange={(e) => setStoryCaption(e.target.value)}
                      placeholder="Add a quick note on your story..."
                      className={`w-full px-3.5 py-2.5 rounded-xl text-xs border outline-none ${
                        darkMode ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-100 border-slate-300 text-slate-900'
                      }`}
                    />
                  </div>

                  <div className="p-3 rounded-2xl bg-indigo-500/10 border border-indigo-500/20 text-xs text-indigo-300">
                    ✨ Stories remain visible for 24 hours on the SocialOne gradient story bar.
                  </div>

                  <button
                    type="submit"
                    disabled={!storyImageUrl.trim()}
                    className="w-full py-3 rounded-2xl font-bold text-sm text-white bg-gradient-to-r from-purple-600 to-pink-600 hover:opacity-95 disabled:opacity-50 cursor-pointer shadow-md transition-all active:scale-[0.99]"
                  >
                    Publish 24h Story
                  </button>
                </form>
              )}

              {/* TAB 4: Community Group */}
              {createTab === 'group' && (
                <form onSubmit={handleGroupSubmit} className="space-y-4">
                  <div>
                    <label className="block text-xs text-slate-400 mb-1">Community Name</label>
                    <input
                      type="text"
                      value={groupName}
                      onChange={(e) => setGroupName(e.target.value)}
                      placeholder="e.g. AI & Robotics Founders Club"
                      className={`w-full px-3.5 py-2.5 rounded-xl text-xs border outline-none ${
                        darkMode ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-100 border-slate-300 text-slate-900'
                      }`}
                    />
                  </div>

                  <div>
                    <label className="block text-xs text-slate-400 mb-1">Description & Mission</label>
                    <textarea
                      value={groupDesc}
                      onChange={(e) => setGroupDesc(e.target.value)}
                      placeholder="What is this community about? Who should join?"
                      rows={3}
                      className={`w-full px-3.5 py-2.5 rounded-xl text-xs border outline-none ${
                        darkMode ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-100 border-slate-300 text-slate-900'
                      }`}
                    />
                  </div>

                  <div>
                    <label className="block text-xs text-slate-400 mb-1">Cover Photo URL</label>
                    <input
                      type="url"
                      value={groupCover}
                      onChange={(e) => setGroupCover(e.target.value)}
                      className={`w-full px-3.5 py-2.5 rounded-xl text-xs border outline-none ${
                        darkMode ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-100 border-slate-300 text-slate-900'
                      }`}
                    />
                  </div>

                  <button
                    type="submit"
                    disabled={!groupName.trim() || !groupDesc.trim()}
                    className="w-full py-3 rounded-2xl font-bold text-sm text-white bg-gradient-to-r from-blue-600 to-teal-500 hover:opacity-95 disabled:opacity-50 cursor-pointer shadow-md transition-all active:scale-[0.99]"
                  >
                    Create Community
                  </button>
                </form>
              )}
            </div>
          </div>
        </div>
  );
};
