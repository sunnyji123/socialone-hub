import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import {
  X,
  Coins,
  Sparkles,
  CreditCard,
  CheckCircle2,
  ShieldCheck,
  Zap,
  ArrowRight,
  Flame,
  Wallet,
} from 'lucide-react';
import confetti from 'canvas-confetti';

interface CoinRechargeModalProps {
  isOpen: boolean;
  onClose: () => void;
}

interface CoinPackage {
  id: string;
  coins: number;
  bonusCoins?: number;
  pricePkr: number;
  priceUsd: number;
  tag?: string;
  isPopular?: boolean;
}

const COIN_PACKAGES: CoinPackage[] = [
  {
    id: 'pkg-70',
    coins: 70,
    pricePkr: 120,
    priceUsd: 0.45,
  },
  {
    id: 'pkg-350',
    coins: 350,
    bonusCoins: 25,
    pricePkr: 580,
    priceUsd: 2.1,
    tag: 'Popular 🔥',
    isPopular: true,
  },
  {
    id: 'pkg-700',
    coins: 700,
    bonusCoins: 70,
    pricePkr: 1150,
    priceUsd: 4.1,
    tag: '+10% Free',
  },
  {
    id: 'pkg-1400',
    coins: 1400,
    bonusCoins: 180,
    pricePkr: 2250,
    priceUsd: 8.0,
    tag: 'Best Value ⚡',
  },
  {
    id: 'pkg-3500',
    coins: 3500,
    bonusCoins: 500,
    pricePkr: 5500,
    priceUsd: 19.5,
    tag: 'Super Saver',
  },
  {
    id: 'pkg-7000',
    coins: 7000,
    bonusCoins: 1200,
    pricePkr: 10800,
    priceUsd: 38.5,
    tag: 'Streamer VIP',
  },
  {
    id: 'pkg-17500',
    coins: 17500,
    bonusCoins: 3500,
    pricePkr: 26500,
    priceUsd: 95.0,
    tag: 'Whale 🐋',
  },
];

type PaymentChannel = 'jazzcash' | 'easypaisa' | 'card' | 'raast';

export const CoinRechargeModal: React.FC<CoinRechargeModalProps> = ({ isOpen, onClose }) => {
  const { userProfile, addCoins, darkMode } = useAuth();

  const [selectedPkg, setSelectedPkg] = useState<CoinPackage>(COIN_PACKAGES[1]);
  const [paymentChannel, setPaymentChannel] = useState<PaymentChannel>('jazzcash');
  const [mobileNumber, setMobileNumber] = useState('03011234567');
  const [accountTitle, setAccountTitle] = useState(userProfile?.displayName || 'Intekhab Alam');
  const [cnicLast4, setCnicLast4] = useState('4201');
  const [cardNumber, setCardNumber] = useState('4242 •••• •••• 4242');

  const [isProcessing, setIsProcessing] = useState(false);
  const [receiptData, setReceiptData] = useState<{
    trxId: string;
    coinsCredited: number;
    amountPkr: number;
    channel: string;
  } | null>(null);

  if (!isOpen) return null;

  const currentCoins = userProfile?.coinsBalance || 0;
  const totalCoinsToAdd = selectedPkg.coins + (selectedPkg.bonusCoins || 0);

  const handlePurchase = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsProcessing(true);

    // Simulate authentic mobile gateway response
    await new Promise((res) => setTimeout(res, 1200));

    const prefix =
      paymentChannel === 'jazzcash'
        ? 'JC-PAY'
        : paymentChannel === 'easypaisa'
        ? 'EP-PAY'
        : paymentChannel === 'raast'
        ? 'RAAST'
        : 'CARD';
    const trxId = `${prefix}-${Math.floor(100000000 + Math.random() * 900000000)}`;

    await addCoins(totalCoinsToAdd);

    confetti({
      particleCount: 70,
      spread: 70,
      origin: { y: 0.6 },
    });

    setReceiptData({
      trxId,
      coinsCredited: totalCoinsToAdd,
      amountPkr: selectedPkg.pricePkr,
      channel:
        paymentChannel === 'jazzcash'
          ? 'JazzCash Mobile Account'
          : paymentChannel === 'easypaisa'
          ? 'EasyPaisa Wallet'
          : paymentChannel === 'raast'
          ? 'Raast Instant Pay'
          : 'Debit/Credit Card',
    });

    setIsProcessing(false);
  };

  return (
    <div className="fixed inset-0 z-60 bg-black/85 flex items-center justify-center p-3 sm:p-4 backdrop-blur-md overflow-y-auto">
      <div
        className={`relative w-full max-w-lg rounded-3xl border shadow-2xl overflow-hidden my-auto transition-all ${
          darkMode ? 'bg-slate-900 border-slate-800 text-white' : 'bg-white border-slate-200 text-slate-900'
        }`}
      >
        {/* Top Gold Gradient Banner */}
        <div className="h-2 w-full bg-gradient-to-r from-amber-400 via-rose-500 to-indigo-600" />

        {/* Header */}
        <div className="p-5 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-amber-500 to-rose-500 flex items-center justify-center text-white shadow-lg shadow-amber-500/20">
              <Coins className="w-5 h-5 fill-current" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-black text-lg">SocialOne Coins Store</h3>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30">
                  Instant Top-Up
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Sikka kharidein to send TikTok live gifts & support creators!
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-full text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Balance Status Banner */}
        <div className="px-5 py-3 bg-gradient-to-r from-amber-500/10 via-rose-500/10 to-indigo-500/10 border-b border-slate-800/80 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Coins className="w-4 h-4 text-amber-400" />
            <span className="text-xs text-slate-300 font-medium">Your Current Balance:</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="text-lg font-black text-amber-400">{currentCoins.toLocaleString()}</span>
            <span className="text-xs text-amber-300/80 font-bold">Coins</span>
          </div>
        </div>

        {/* If Receipt is active */}
        {receiptData ? (
          <div className="p-6 text-center space-y-4">
            <div className="w-16 h-16 rounded-3xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-400 mx-auto flex items-center justify-center shadow-lg">
              <CheckCircle2 className="w-8 h-8" />
            </div>
            <div>
              <h4 className="text-xl font-black text-white">Payment Successful!</h4>
              <p className="text-xs text-slate-300 mt-1">
                Your coins have been deposited into your SocialOne account.
              </p>
            </div>

            <div className="p-4 rounded-2xl bg-slate-800/80 border border-slate-700/60 space-y-2 text-left text-xs">
              <div className="flex justify-between">
                <span className="text-slate-400">Coins Credited:</span>
                <strong className="text-amber-400 font-black text-sm">
                  +{receiptData.coinsCredited.toLocaleString()} Coins 🪙
                </strong>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Amount Paid:</span>
                <strong className="text-white">Rs. {receiptData.amountPkr.toLocaleString()} PKR</strong>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Payment Gateway:</span>
                <span className="text-teal-300 font-semibold">{receiptData.channel}</span>
              </div>
              <div className="flex justify-between pt-1 border-t border-slate-700/60 font-mono text-[11px]">
                <span className="text-slate-400">Transaction ID:</span>
                <span className="text-slate-300">{receiptData.trxId}</span>
              </div>
            </div>

            <div className="flex gap-2 pt-2">
              <button
                onClick={() => {
                  setReceiptData(null);
                  onClose();
                }}
                className="w-full py-3 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:opacity-90 text-white font-bold text-xs cursor-pointer shadow-lg"
              >
                Done / Back to Live Gifting
              </button>
            </div>
          </div>
        ) : (
          /* Package & Payment Selection Form */
          <form onSubmit={handlePurchase} className="p-5 sm:p-6 space-y-5">
            {/* Packages Grid */}
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-2">
                1. Select Coin Bundle:
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 max-h-56 overflow-y-auto pr-1 scrollbar-none">
                {COIN_PACKAGES.map((pkg) => {
                  const isSelected = selectedPkg.id === pkg.id;
                  const total = pkg.coins + (pkg.bonusCoins || 0);
                  return (
                    <button
                      type="button"
                      key={pkg.id}
                      onClick={() => setSelectedPkg(pkg)}
                      className={`p-3 rounded-2xl border text-left transition-all relative flex flex-col justify-between cursor-pointer ${
                        isSelected
                          ? 'bg-amber-500/15 border-amber-400 ring-2 ring-amber-400/30'
                          : 'bg-slate-800/60 border-slate-700/70 hover:border-slate-600 hover:bg-slate-800'
                      }`}
                    >
                      {pkg.tag && (
                        <span
                          className={`absolute -top-2 right-2 px-1.5 py-0.5 rounded-full text-[9px] font-black uppercase tracking-wider ${
                            pkg.isPopular
                              ? 'bg-rose-500 text-white shadow-xs'
                              : 'bg-amber-500 text-black shadow-xs'
                          }`}
                        >
                          {pkg.tag}
                        </span>
                      )}

                      <div className="flex items-center gap-1.5 mb-1">
                        <Coins className="w-4 h-4 text-amber-400 fill-amber-400" />
                        <span className="font-black text-sm text-white">{total.toLocaleString()}</span>
                      </div>

                      <div className="text-[11px] text-slate-300 font-semibold">
                        Rs. {pkg.pricePkr.toLocaleString()}
                      </div>
                      <div className="text-[10px] text-slate-500">
                        (${pkg.priceUsd.toFixed(2)} USD)
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Payment Method Selector */}
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-2">
                2. Choose Payment Method (Pakistan & Global):
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {/* JazzCash */}
                <button
                  type="button"
                  onClick={() => setPaymentChannel('jazzcash')}
                  className={`p-2.5 rounded-xl border text-center transition-all cursor-pointer flex flex-col items-center gap-1 ${
                    paymentChannel === 'jazzcash'
                      ? 'bg-red-500/20 border-red-500 text-red-300 font-bold ring-2 ring-red-500/20'
                      : 'bg-slate-800/60 border-slate-700 text-slate-400 hover:text-white hover:bg-slate-800'
                  }`}
                >
                  <span className="text-base">🔴</span>
                  <span className="text-xs font-bold">JazzCash</span>
                  <span className="text-[9px] opacity-70">Mobile Acc</span>
                </button>

                {/* EasyPaisa */}
                <button
                  type="button"
                  onClick={() => setPaymentChannel('easypaisa')}
                  className={`p-2.5 rounded-xl border text-center transition-all cursor-pointer flex flex-col items-center gap-1 ${
                    paymentChannel === 'easypaisa'
                      ? 'bg-emerald-500/20 border-emerald-500 text-emerald-300 font-bold ring-2 ring-emerald-500/20'
                      : 'bg-slate-800/60 border-slate-700 text-slate-400 hover:text-white hover:bg-slate-800'
                  }`}
                >
                  <span className="text-base">🟢</span>
                  <span className="text-xs font-bold">EasyPaisa</span>
                  <span className="text-[9px] opacity-70">Wallet</span>
                </button>

                {/* Raast */}
                <button
                  type="button"
                  onClick={() => setPaymentChannel('raast')}
                  className={`p-2.5 rounded-xl border text-center transition-all cursor-pointer flex flex-col items-center gap-1 ${
                    paymentChannel === 'raast'
                      ? 'bg-orange-500/20 border-orange-500 text-orange-300 font-bold ring-2 ring-orange-500/20'
                      : 'bg-slate-800/60 border-slate-700 text-slate-400 hover:text-white hover:bg-slate-800'
                  }`}
                >
                  <span className="text-base">⚡</span>
                  <span className="text-xs font-bold">Raast ID</span>
                  <span className="text-[9px] opacity-70">Zero Fee</span>
                </button>

                {/* Debit / Credit Card */}
                <button
                  type="button"
                  onClick={() => setPaymentChannel('card')}
                  className={`p-2.5 rounded-xl border text-center transition-all cursor-pointer flex flex-col items-center gap-1 ${
                    paymentChannel === 'card'
                      ? 'bg-blue-500/20 border-blue-500 text-blue-300 font-bold ring-2 ring-blue-500/20'
                      : 'bg-slate-800/60 border-slate-700 text-slate-400 hover:text-white hover:bg-slate-800'
                  }`}
                >
                  <CreditCard className="w-4 h-4 text-blue-400" />
                  <span className="text-xs font-bold">Debit Card</span>
                  <span className="text-[9px] opacity-70">Visa/Master</span>
                </button>
              </div>
            </div>

            {/* Input Details based on channel */}
            <div className="p-3.5 rounded-2xl bg-slate-800/70 border border-slate-700/60 space-y-2.5">
              {paymentChannel === 'jazzcash' || paymentChannel === 'easypaisa' || paymentChannel === 'raast' ? (
                <>
                  <div className="flex justify-between items-center text-xs">
                    <span className="text-slate-300 font-bold">
                      {paymentChannel === 'jazzcash'
                        ? 'JazzCash Account Number:'
                        : paymentChannel === 'easypaisa'
                        ? 'EasyPaisa Mobile Number:'
                        : 'Raast ID / Registered Mobile:'}
                    </span>
                    <span className="text-[10px] text-emerald-400 font-bold">Instant SMS Prompt</span>
                  </div>
                  <input
                    type="text"
                    required
                    value={mobileNumber}
                    onChange={(e) => setMobileNumber(e.target.value)}
                    placeholder="03001234567"
                    className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs outline-none focus:border-amber-400 font-mono"
                  />
                  <div className="grid grid-cols-2 gap-2 pt-1 text-xs">
                    <div>
                      <span className="block text-[11px] text-slate-400 mb-0.5">Account Title:</span>
                      <input
                        type="text"
                        value={accountTitle}
                        onChange={(e) => setAccountTitle(e.target.value)}
                        className="w-full px-2.5 py-1.5 rounded-lg bg-slate-900 border border-slate-700 text-white text-xs"
                      />
                    </div>
                    <div>
                      <span className="block text-[11px] text-slate-400 mb-0.5">CNIC Last 4 Digits:</span>
                      <input
                        type="text"
                        maxLength={4}
                        value={cnicLast4}
                        onChange={(e) => setCnicLast4(e.target.value)}
                        className="w-full px-2.5 py-1.5 rounded-lg bg-slate-900 border border-slate-700 text-white text-xs font-mono"
                      />
                    </div>
                  </div>
                </>
              ) : (
                <>
                  <div className="flex justify-between items-center text-xs">
                    <span className="text-slate-300 font-bold">Card Number:</span>
                    <span className="text-[10px] text-emerald-400 font-bold">256-Bit SSL Encrypted</span>
                  </div>
                  <input
                    type="text"
                    value={cardNumber}
                    onChange={(e) => setCardNumber(e.target.value)}
                    placeholder="4242 •••• •••• 4242"
                    className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs outline-none focus:border-amber-400 font-mono"
                  />
                </>
              )}
            </div>

            {/* Total Summary & Checkout Button */}
            <div className="space-y-2 pt-1">
              <div className="flex items-center justify-between text-xs px-1">
                <span className="text-slate-400">Total Recharge:</span>
                <span className="text-amber-400 font-black text-sm">
                  {totalCoinsToAdd.toLocaleString()} Coins (Rs. {selectedPkg.pricePkr.toLocaleString()} PKR)
                </span>
              </div>

              <button
                type="submit"
                disabled={isProcessing}
                className="w-full py-3.5 px-4 rounded-2xl bg-gradient-to-r from-amber-500 via-rose-500 to-indigo-600 hover:opacity-95 text-white font-black text-sm flex items-center justify-center gap-2 shadow-xl shadow-amber-500/20 cursor-pointer disabled:opacity-50 transition-all active:scale-[0.99]"
              >
                {isProcessing ? (
                  <div className="flex items-center gap-2">
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    <span>Verifying {paymentChannel.toUpperCase()} Gateway...</span>
                  </div>
                ) : (
                  <>
                    <Coins className="w-4 h-4 fill-current" />
                    <span>Pay Rs. {selectedPkg.pricePkr.toLocaleString()} & Get {totalCoinsToAdd.toLocaleString()} Coins</span>
                  </>
                )}
              </button>

              <p className="text-[10px] text-center text-slate-400 pt-1">
                🔒 Secure transaction powered by SocialOne Gateway. 75% goes directly to creators, 25% platform share.
              </p>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
