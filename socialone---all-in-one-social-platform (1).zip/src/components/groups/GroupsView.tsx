import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useApp } from '../../context/AppContext';
import { Users, Plus, ShieldCheck, Heart, MessageCircle, Share2, Sparkles } from 'lucide-react';

export const GroupsView: React.FC = () => {
  const { userProfile, darkMode } = useAuth();
  const {
    groups,
    toggleJoinGroup,
    posts,
    createPost,
    toggleLikePost,
    activeGroupId,
    setActiveGroupId,
    setIsCreateModalOpen,
  } = useApp();

  const [groupPostText, setGroupPostText] = useState('');

  const currentGroup = groups.find((g) => g.id === activeGroupId) || groups[0];
  const isMember = currentGroup?.memberIds?.includes(userProfile?.uid || '');

  const groupPosts = posts.filter((p) => p.groupId === currentGroup?.id);

  const handleCreateGroupPost = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!groupPostText.trim() || !currentGroup) return;
    await createPost(groupPostText.trim(), [], 'none', currentGroup.id);
    setGroupPostText('');
  };

  return (
    <div className="max-w-4xl mx-auto w-full pb-20 space-y-6">
      {/* Top Banner & Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-black tracking-tight flex items-center gap-2">
            <span>Communities & Groups</span>
            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
              Facebook Style
            </span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Connect around tech, art, startups, photography, and lifestyles.
          </p>
        </div>

        <button
          onClick={() => setIsCreateModalOpen(true)}
          className="px-4 py-2 rounded-2xl text-xs font-bold text-white bg-gradient-to-r from-blue-600 to-indigo-600 hover:opacity-95 shadow-md flex items-center gap-1.5 cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>Create Community</span>
        </button>
      </div>

      {/* Community Selector Tabs */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        {groups.map((group) => {
          const isSelected = currentGroup?.id === group.id;
          const joined = group.memberIds?.includes(userProfile?.uid || '');

          return (
            <div
              key={group.id}
              onClick={() => setActiveGroupId(group.id)}
              className={`p-4 rounded-3xl border transition-all cursor-pointer relative overflow-hidden ${
                isSelected
                  ? 'border-blue-500 shadow-md ring-2 ring-blue-500/20'
                  : darkMode
                  ? 'bg-slate-900/60 border-slate-800 hover:border-slate-700'
                  : 'bg-white border-slate-200 hover:border-slate-300'
              }`}
            >
              <div className="flex items-center gap-3">
                <img
                  src={group.avatarUrl}
                  alt={group.name}
                  className="w-12 h-12 rounded-2xl object-cover ring-2 ring-blue-500/30"
                />
                <div className="flex-1 min-w-0">
                  <h4 className="font-bold text-xs truncate">{group.name}</h4>
                  <p className="text-[11px] text-slate-400 mt-0.5 flex items-center gap-1">
                    <Users className="w-3 h-3" />
                    <span>{group.membersCount} members</span>
                  </p>
                </div>
              </div>

              {joined && (
                <span className="absolute top-2 right-2 text-[10px] font-bold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-full">
                  Joined
                </span>
              )}
            </div>
          );
        })}
      </div>

      {/* Selected Group Workspace */}
      {currentGroup && (
        <div
          className={`rounded-3xl border overflow-hidden shadow-xs transition-colors ${
            darkMode ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200'
          }`}
        >
          {/* Cover Photo */}
          <div className="h-44 sm:h-56 w-full relative bg-slate-800">
            <img
              src={currentGroup.coverUrl}
              alt={currentGroup.name}
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />

            <div className="absolute bottom-4 left-4 right-4 flex flex-col sm:flex-row items-start sm:items-end justify-between gap-3 text-white">
              <div className="flex items-center gap-3">
                <img
                  src={currentGroup.avatarUrl}
                  alt={currentGroup.name}
                  className="w-14 h-14 rounded-2xl object-cover ring-2 ring-white/70 shadow-lg"
                />
                <div>
                  <h3 className="font-black text-lg sm:text-xl drop-shadow">{currentGroup.name}</h3>
                  <p className="text-xs text-white/80">
                    Created by {currentGroup.creatorName} • {currentGroup.membersCount} Members
                  </p>
                </div>
              </div>

              <button
                onClick={() => toggleJoinGroup(currentGroup.id)}
                className={`px-5 py-2 rounded-2xl text-xs font-bold transition-all shadow-md cursor-pointer ${
                  isMember
                    ? 'bg-white/20 text-white hover:bg-white/30 backdrop-blur-md'
                    : 'bg-blue-600 hover:bg-blue-500 text-white'
                }`}
              >
                {isMember ? 'Joined Community ✓' : 'Join Group'}
              </button>
            </div>
          </div>

          {/* Group Info & Rules */}
          <div className="p-4 sm:p-6 border-b border-slate-800/40 grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="md:col-span-2 space-y-2">
              <h4 className="font-bold text-xs text-slate-400 uppercase tracking-wider">
                About this community
              </h4>
              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed font-normal">
                {currentGroup.description}
              </p>
            </div>

            <div className="space-y-2">
              <h4 className="font-bold text-xs text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
                <ShieldCheck className="w-3.5 h-3.5 text-blue-500" />
                Community Rules
              </h4>
              <ul className="text-xs text-slate-400 space-y-1.5 list-disc pl-4">
                {currentGroup.rules.map((rule, idx) => (
                  <li key={idx}>{rule}</li>
                ))}
              </ul>
            </div>
          </div>

          {/* Post in Group Prompt */}
          <div className="p-4 sm:p-6 border-b border-slate-800/40">
            <form onSubmit={handleCreateGroupPost} className="space-y-3">
              <div className="flex items-center gap-3">
                <img
                  src={
                    userProfile?.photoURL ||
                    'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&auto=format&fit=crop&q=80'
                  }
                  alt="You"
                  className="w-9 h-9 rounded-full object-cover"
                />
                <input
                  type="text"
                  value={groupPostText}
                  onChange={(e) => setGroupPostText(e.target.value)}
                  placeholder={`Share something with ${currentGroup.name}...`}
                  className={`flex-1 px-4 py-2.5 rounded-2xl text-xs outline-none border transition-colors ${
                    darkMode
                      ? 'bg-slate-900 border-slate-700 text-white placeholder-slate-500 focus:border-blue-500'
                      : 'bg-slate-100 border-slate-200 text-slate-900 placeholder-slate-400 focus:border-blue-500'
                  }`}
                />
                <button
                  type="submit"
                  disabled={!groupPostText.trim()}
                  className="px-4 py-2.5 rounded-2xl text-xs font-bold bg-blue-600 hover:bg-blue-500 text-white disabled:opacity-50 cursor-pointer shadow-sm"
                >
                  Post
                </button>
              </div>
            </form>
          </div>

          {/* Group Posts Feed */}
          <div className="p-4 sm:p-6 space-y-4">
            <h4 className="font-bold text-sm">Community Discussions</h4>
            {groupPosts.length === 0 ? (
              <p className="text-xs text-slate-400 py-4 text-center">
                No discussions in this group yet. Post the first message above!
              </p>
            ) : (
              groupPosts.map((post) => (
                <div
                  key={post.id}
                  className={`p-4 rounded-2xl border ${
                    darkMode ? 'bg-slate-800/40 border-slate-800' : 'bg-slate-50 border-slate-200'
                  }`}
                >
                  <div className="flex items-center gap-2.5 mb-2">
                    <img
                      src={post.authorPhoto}
                      alt={post.authorName}
                      className="w-8 h-8 rounded-full object-cover"
                    />
                    <div>
                      <p className="font-bold text-xs">{post.authorName}</p>
                      <p className="text-[10px] text-slate-400">
                        {new Date(post.createdAt).toLocaleDateString([], {
                          month: 'short',
                          day: 'numeric',
                        })}
                      </p>
                    </div>
                  </div>
                  <p className="text-xs leading-relaxed text-slate-300 font-normal">{post.content}</p>

                  <div className="flex items-center gap-4 mt-3 pt-2 border-t border-slate-800/20 text-xs text-slate-400">
                    <button
                      onClick={() => toggleLikePost(post.id)}
                      className="flex items-center gap-1 hover:text-rose-500 cursor-pointer"
                    >
                      <Heart className="w-3.5 h-3.5" />
                      <span>{post.likesCount}</span>
                    </button>
                    <span className="flex items-center gap-1">
                      <MessageCircle className="w-3.5 h-3.5" />
                      <span>{post.commentsCount}</span>
                    </span>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      )}
    </div>
  );
};
