import React from 'react';
import { DailyProfitSettlement } from '../../lib/jazzcashPayoutService';
import {
  X,
  ShieldCheck,
  CheckCircle2,
  AlertTriangle,
  Smartphone,
  Download,
  Calendar,
  DollarSign,
  TrendingUp,
  Percent,
  FileText,
  Clock,
  Building2,
} from 'lucide-react';

interface FounderDailySettlementModalProps {
  settlement: DailyProfitSettlement | null;
  onClose: () => void;
}

export const FounderDailySettlementModal: React.FC<FounderDailySettlementModalProps> = ({
  settlement,
  onClose,
}) => {
  if (!settlement) return null;

  const isCompleted = settlement.status === 'completed';

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4">
      <div className="max-w-lg w-full rounded-3xl bg-slate-900 border border-amber-500/40 text-white shadow-2xl p-6 sm:p-7 space-y-5 max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-white/10">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-red-600 to-amber-500 flex items-center justify-center text-white shadow-lg shadow-amber-500/20">
              <Smartphone className="w-5 h-5" />
            </div>
            <div>
              <span className="text-[10px] font-black uppercase tracking-wider text-amber-400">
                Official Payout Statement
              </span>
              <h3 className="text-base font-black text-white">JazzCash Daily Disbursement</h3>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-slate-400 hover:text-white cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Status Badge & Amount Banner */}
        <div className="p-4 rounded-2xl bg-gradient-to-r from-emerald-950/80 via-slate-950 to-amber-950/70 border border-emerald-500/40 text-center space-y-1">
          <div className="inline-flex items-center gap-1.5 px-3 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
            {isCompleted ? (
              <>
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                <span>Transferred &amp; Verified (Code 000)</span>
              </>
            ) : (
              <>
                <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
                <span className="capitalize">{settlement.status}</span>
              </>
            )}
          </div>

          <div className="pt-1">
            <span className="text-3xl sm:text-4xl font-black text-emerald-300 tracking-tight">
              Rs. {settlement.founder25SharePkr.toLocaleString()}
            </span>
            <span className="text-xs font-bold text-slate-400 ml-1.5">PKR</span>
          </div>

          <p className="text-xs text-amber-300 font-bold">
            ${settlement.founder25ShareUsd.toFixed(2)} USD (25% Daily Net Profit Share)
          </p>

          <p className="text-[11px] text-slate-400">
            Credited to JazzCash: <strong className="text-white font-mono">{settlement.beneficiaryMobile}</strong>
          </p>
        </div>

        {/* Transaction Reference & Timing */}
        <div className="bg-slate-950/80 p-3.5 rounded-2xl border border-slate-800 space-y-2 text-xs">
          <div className="flex justify-between items-center">
            <span className="text-slate-400">JazzCash Txn Ref:</span>
            <span className="font-mono font-bold text-amber-300 select-all">
              {settlement.jazzCashTxnRef || 'PENDING_GENERATION'}
            </span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-slate-400">Settlement Date (PKT):</span>
            <span className="font-semibold text-white">{settlement.datePkt}</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-slate-400">Execution Schedule:</span>
            <span className="font-semibold text-teal-300">8:00 PM Pakistan Standard Time (PKT)</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-slate-400">Beneficiary:</span>
            <span className="font-semibold text-white">{settlement.beneficiaryTitle}</span>
          </div>
        </div>

        {/* Net Profit Mathematical Breakdown (Rule 1 & 2) */}
        <div className="space-y-2 text-xs">
          <p className="font-bold text-slate-300 flex items-center gap-1.5 uppercase tracking-wider text-[11px]">
            <FileText className="w-3.5 h-3.5 text-amber-400" />
            <span>Audited Profit &amp; Loss Breakdown (Daily)</span>
          </p>

          <div className="p-3.5 rounded-2xl bg-slate-950/60 border border-slate-800 space-y-2 font-mono text-[11px]">
            <div className="flex justify-between items-center">
              <span className="text-slate-400">Settled Gross Revenue:</span>
              <span className="text-white font-bold">${settlement.settledRevenueUsd.toFixed(2)} USD</span>
            </div>

            <div className="flex justify-between items-center text-rose-400">
              <span>- Gateway Fees (2.5%):</span>
              <span>-${settlement.gatewayFeesUsd.toFixed(2)} USD</span>
            </div>

            <div className="flex justify-between items-center text-rose-400">
              <span>- Operating &amp; CDN Expenses (5.0%):</span>
              <span>-${settlement.operatingExpensesUsd.toFixed(2)} USD</span>
            </div>

            <div className="flex justify-between items-center text-rose-400">
              <span>- Refunds / Chargebacks (1.0%):</span>
              <span>-${settlement.refundsReserveUsd.toFixed(2)} USD</span>
            </div>

            <div className="pt-1.5 border-t border-slate-800 flex justify-between items-center text-emerald-400 font-bold">
              <span>= Net Platform Profit:</span>
              <span>${settlement.netPlatformProfitUsd.toFixed(2)} USD</span>
            </div>

            <div className="flex justify-between items-center text-amber-300 font-black pt-1 border-t border-amber-500/20">
              <span>Founder 25% Profit Share:</span>
              <span>${settlement.founder25ShareUsd.toFixed(2)} USD</span>
            </div>

            <div className="flex justify-between items-center text-slate-400 text-[10px]">
              <span>Exchange Rate (PKR/USD):</span>
              <span>Rs. {settlement.exchangeRatePkr}</span>
            </div>
          </div>
        </div>

        {/* Compliance & Security Callout (Rule 9 & 10) */}
        <div className="p-3 rounded-xl bg-blue-500/10 border border-blue-500/20 text-[11px] text-blue-300 flex items-start gap-2">
          <ShieldCheck className="w-4 h-4 text-blue-400 shrink-0 mt-0.5" />
          <p className="leading-relaxed">
            Automatic disbursement authorized under verified mandate. Funds transferred directly to verified JazzCash mobile wallet with zero manual approval required. Anti-duplicate idempotency verified.
          </p>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-3 pt-2">
          <button
            type="button"
            onClick={handlePrint}
            className="flex-1 py-2.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs flex items-center justify-center gap-1.5 border border-slate-700 cursor-pointer"
          >
            <Download className="w-4 h-4 text-amber-400" />
            <span>Print / Save Receipt</span>
          </button>

          <button
            type="button"
            onClick={onClose}
            className="flex-1 py-2.5 px-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs cursor-pointer shadow-md transition-colors"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
