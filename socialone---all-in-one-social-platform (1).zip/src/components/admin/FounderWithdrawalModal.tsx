import React, { useState } from 'react';
import {
  Wallet,
  CheckCircle2,
  ArrowRight,
  ShieldCheck,
  Sparkles,
  Smartphone,
  CreditCard,
  Download,
  AlertCircle,
  Clock,
  Check,
  RefreshCw,
  X,
} from 'lucide-react';
import { FounderWithdrawal } from '../../types';

interface FounderWithdrawalModalProps {
  isOpen: boolean;
  onClose: () => void;
  availableBalanceUsd: number;
  totalRevenueUsd: number;
  withdrawnTotalUsd: number;
  onWithdraw: (
    method: 'jazzcash' | 'easypaisa',
    accountTitle: string,
    accountNumber: string,
    amountUsd: number,
    cnic?: string
  ) => Promise<{ success: boolean; transaction: FounderWithdrawal }>;
  onAddDemoFunds?: (amount: number) => void;
}

export const FounderWithdrawalModal: React.FC<FounderWithdrawalModalProps> = ({
  isOpen,
  onClose,
  availableBalanceUsd,
  totalRevenueUsd,
  withdrawnTotalUsd,
  onWithdraw,
  onAddDemoFunds,
}) => {
  const [method, setMethod] = useState<'jazzcash' | 'easypaisa'>('jazzcash');
  const [accountTitle, setAccountTitle] = useState('Intekhab Alam (Founder & CEO)');
  const [accountNumber, setAccountNumber] = useState('03701220965');
  const [cnic, setCnic] = useState('42101-9876543-1');
  const [amountUsd, setAmountUsd] = useState<string>(
    availableBalanceUsd > 0 ? Math.min(availableBalanceUsd, 25).toString() : '10'
  );

  const [isProcessing, setIsProcessing] = useState(false);
  const [processStep, setProcessStep] = useState<string>('');
  const [completedTx, setCompletedTx] = useState<FounderWithdrawal | null>(null);
  const [errorMsg, setErrorMsg] = useState<string>('');

  if (!isOpen) return null;

  const PKR_RATE = 280;
  const numAmountUsd = parseFloat(amountUsd) || 0;
  const estimatedPkr = Math.round(numAmountUsd * PKR_RATE);

  const handleMaxClick = () => {
    if (availableBalanceUsd > 0) {
      setAmountUsd(availableBalanceUsd.toFixed(2));
      setErrorMsg('');
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    if (numAmountUsd <= 0) {
      setErrorMsg('Please enter a valid amount greater than $0.');
      return;
    }
    if (numAmountUsd > availableBalanceUsd) {
      setErrorMsg(
        `Insufficient balance. You currently have $${availableBalanceUsd.toFixed(
          2
        )} USD available to withdraw.`
      );
      return;
    }
    const cleanNumber = accountNumber.replace(/\D/g, '');
    if (cleanNumber.length < 11) {
      setErrorMsg('Please enter a valid 11-digit Pakistani mobile number (e.g., 03012345678).');
      return;
    }

    setIsProcessing(true);
    setProcessStep(`Connecting to ${method === 'jazzcash' ? 'JazzCash' : 'EasyPaisa'} Gateway...`);

    setTimeout(() => {
      setProcessStep('Verifying Account Title: Intekhab Alam via 1Link/Raast...');
    }, 700);

    setTimeout(async () => {
      setProcessStep(`Disbursing Rs. ${estimatedPkr.toLocaleString()} PKR instantly...`);
      try {
        const res = await onWithdraw(
          method,
          accountTitle,
          accountNumber,
          numAmountUsd,
          cnic
        );
        setIsProcessing(false);
        setCompletedTx(res.transaction);
      } catch (err: any) {
        setIsProcessing(false);
        setErrorMsg('Failed to process withdrawal. Please try again.');
      }
    }, 1500);
  };

  const handleReset = () => {
    setCompletedTx(null);
    setAmountUsd(availableBalanceUsd > 0 ? Math.min(availableBalanceUsd, 25).toString() : '10');
    setErrorMsg('');
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className="max-w-lg w-full bg-slate-900 border border-slate-800 rounded-3xl p-5 sm:p-7 space-y-5 shadow-2xl text-white my-8 relative">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 rounded-full bg-slate-800/80 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors cursor-pointer"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Modal Header */}
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-wider bg-amber-500/15 text-amber-400 border border-amber-500/30 mb-1.5">
            <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
            <span>Founder & CEO Direct Payout</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-black tracking-tight text-white flex items-center gap-2">
            <span>JazzCash & EasyPaisa Withdrawal</span>
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Disburse your 25% platform revenue directly to your Pakistani mobile account.
          </p>
        </div>

        {/* Balance Overview Card */}
        <div className="grid grid-cols-2 gap-3 p-4 rounded-2xl bg-gradient-to-r from-slate-950 via-slate-900 to-slate-950 border border-slate-800">
          <div>
            <span className="text-[11px] text-slate-400 font-medium">Available Treasury:</span>
            <div className="flex items-baseline gap-1 mt-0.5">
              <span className="text-xl sm:text-2xl font-black text-emerald-400">
                ${availableBalanceUsd.toFixed(2)}
              </span>
              <span className="text-[10px] text-slate-400">USD</span>
            </div>
            <span className="text-[11px] text-emerald-300/90 font-bold block mt-0.5">
              ≈ Rs. {Math.round(availableBalanceUsd * PKR_RATE).toLocaleString()} PKR
            </span>
          </div>

          <div className="text-right border-l border-slate-800/80 pl-3">
            <span className="text-[11px] text-slate-400 font-medium">Lifetime 25% Share:</span>
            <p className="text-sm font-bold text-slate-200 mt-0.5">
              ${totalRevenueUsd.toFixed(2)} USD
            </p>
            <span className="text-[10px] text-slate-400">
              Withdrawn: ${withdrawnTotalUsd.toFixed(2)}
            </span>
          </div>
        </div>

        {/* COMPLETED RECEIPT VIEW */}
        {completedTx ? (
          <div className="space-y-4 animate-in fade-in zoom-in-95 duration-200">
            <div
              className={`p-5 rounded-3xl border text-center space-y-3 ${
                completedTx.method === 'jazzcash'
                  ? 'bg-gradient-to-b from-rose-950/40 via-slate-900 to-slate-900 border-rose-500/40'
                  : 'bg-gradient-to-b from-emerald-950/40 via-slate-900 to-slate-900 border-emerald-500/40'
              }`}
            >
              <div
                className={`w-14 h-14 rounded-full mx-auto flex items-center justify-center ${
                  completedTx.method === 'jazzcash'
                    ? 'bg-rose-500/20 text-rose-400'
                    : 'bg-emerald-500/20 text-emerald-400'
                }`}
              >
                <CheckCircle2 className="w-8 h-8" />
              </div>

              <div>
                <span className="text-xs font-bold text-slate-400 uppercase tracking-widest">
                  Official Transfer Receipt
                </span>
                <h3 className="text-2xl font-black text-white mt-1">
                  Rs. {completedTx.amountPkr.toLocaleString()} PKR
                </h3>
                <span className="text-xs text-slate-300 font-medium">
                  (${completedTx.amountUsd.toFixed(2)} USD Disbursed)
                </span>
              </div>

              {/* Transaction details card */}
              <div className="bg-black/40 rounded-2xl p-4 border border-white/10 text-left text-xs space-y-2">
                <div className="flex justify-between py-1 border-b border-white/5">
                  <span className="text-slate-400">Gateway:</span>
                  <span className="font-bold uppercase tracking-wider text-white flex items-center gap-1.5">
                    {completedTx.method === 'jazzcash' ? (
                      <span className="text-rose-400 font-black">🔴 JazzCash</span>
                    ) : (
                      <span className="text-emerald-400 font-black">🟢 EasyPaisa</span>
                    )}
                  </span>
                </div>

                <div className="flex justify-between py-1 border-b border-white/5">
                  <span className="text-slate-400">Beneficiary:</span>
                  <span className="font-bold text-white">{completedTx.accountTitle}</span>
                </div>

                <div className="flex justify-between py-1 border-b border-white/5">
                  <span className="text-slate-400">Mobile Account:</span>
                  <span className="font-bold text-slate-200">{completedTx.accountNumber}</span>
                </div>

                <div className="flex justify-between py-1 border-b border-white/5">
                  <span className="text-slate-400">Transaction ID (TID):</span>
                  <span className="font-mono font-bold text-amber-400">{completedTx.transactionId}</span>
                </div>

                <div className="flex justify-between py-1 border-b border-white/5">
                  <span className="text-slate-400">Exchange Rate:</span>
                  <span className="font-semibold text-slate-300">1 USD = 280 PKR</span>
                </div>

                <div className="flex justify-between py-1 border-b border-white/5">
                  <span className="text-slate-400">Founder Platform Fee:</span>
                  <span className="font-bold text-emerald-400">Rs. 0 (Free Exemption)</span>
                </div>

                <div className="flex justify-between py-1">
                  <span className="text-slate-400">Payment Status:</span>
                  <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-black bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                    <Check className="w-3 h-3 text-emerald-400" />
                    SUCCESSFUL
                  </span>
                </div>
              </div>

              {/* Official 8558 SMS Alert Confirmation */}
              <div className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800 text-left text-[11px] text-slate-300">
                <div className="flex items-center gap-1.5 text-[10px] font-bold text-emerald-400 mb-1">
                  <Smartphone className="w-3.5 h-3.5 text-emerald-400" />
                  <span>
                    Official {completedTx.method === 'jazzcash' ? 'JazzCash 8558' : 'EasyPaisa 3737'} Transfer Confirmation
                  </span>
                </div>
                <p className="font-mono text-slate-200 leading-snug">
                  &quot;Trx ID {completedTx.transactionId}: Rs. {completedTx.amountPkr.toLocaleString()} has been
                  transferred to your {completedTx.method === 'jazzcash' ? 'JazzCash' : 'EasyPaisa'} Account{' '}
                  {completedTx.accountNumber} by SocialOne Platform (Founder &amp; CEO Intekhab Alam). Fee: Rs. 0.00.&quot;
                </p>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <button
                onClick={handleReset}
                className="flex-1 py-3 rounded-2xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs cursor-pointer transition-colors"
              >
                Make Another Transfer
              </button>
              <button
                onClick={onClose}
                className="flex-1 py-3 rounded-2xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:opacity-90 text-white font-bold text-xs cursor-pointer shadow-md transition-opacity"
              >
                Close &amp; Return to Dashboard
              </button>
            </div>
          </div>
        ) : (
          /* FORM VIEW */
          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Payment Method Selector: JazzCash vs EasyPaisa */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-300">Select Mobile Wallet:</label>
              <div className="grid grid-cols-2 gap-3">
                {/* JazzCash Tab */}
                <button
                  type="button"
                  onClick={() => setMethod('jazzcash')}
                  className={`p-3.5 rounded-2xl border text-left transition-all cursor-pointer relative ${
                    method === 'jazzcash'
                      ? 'bg-gradient-to-br from-rose-950/60 via-red-950/40 to-slate-900 border-rose-500 ring-2 ring-rose-500/30'
                      : 'bg-slate-800/60 border-slate-700/80 hover:bg-slate-800 text-slate-400'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xl">🔴</span>
                    {method === 'jazzcash' && (
                      <span className="w-2 h-2 rounded-full bg-rose-500 animate-pulse" />
                    )}
                  </div>
                  <h4 className="font-black text-sm text-white">JazzCash</h4>
                  <p className="text-[10px] text-slate-400 mt-0.5">
                    Direct to Mobilink / Jazz mobile account
                  </p>
                </button>

                {/* EasyPaisa Tab */}
                <button
                  type="button"
                  onClick={() => setMethod('easypaisa')}
                  className={`p-3.5 rounded-2xl border text-left transition-all cursor-pointer relative ${
                    method === 'easypaisa'
                      ? 'bg-gradient-to-br from-emerald-950/60 via-green-950/40 to-slate-900 border-emerald-500 ring-2 ring-emerald-500/30'
                      : 'bg-slate-800/60 border-slate-700/80 hover:bg-slate-800 text-slate-400'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xl">🟢</span>
                    {method === 'easypaisa' && (
                      <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                    )}
                  </div>
                  <h4 className="font-black text-sm text-white">EasyPaisa</h4>
                  <p className="text-[10px] text-slate-400 mt-0.5">
                    Direct to Telenor / EasyPaisa wallet
                  </p>
                </button>
              </div>
            </div>

            {/* Account Title */}
            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-300">
                Account Title (Beneficiary Name)
              </label>
              <input
                type="text"
                value={accountTitle}
                onChange={(e) => setAccountTitle(e.target.value)}
                placeholder="Intekhab Alam (Founder & CEO)"
                required
                className="w-full px-4 py-2.5 rounded-2xl text-xs bg-slate-800 border border-slate-700 text-white outline-none focus:border-indigo-500 transition-colors"
              />
            </div>

            {/* Mobile Number & CNIC */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-300 flex items-center justify-between">
                  <span>{method === 'jazzcash' ? 'JazzCash' : 'EasyPaisa'} Mobile No.</span>
                  <span className="text-[10px] text-slate-400">03XXXXXXXXX</span>
                </label>
                <div className="relative">
                  <span className="absolute left-3 top-2.5 text-xs text-slate-400 flex items-center gap-1 font-semibold">
                    🇵🇰 +92
                  </span>
                  <input
                    type="text"
                    value={method === 'jazzcash' ? '03701220965' : accountNumber}
                    onChange={(e) => {
                      if (method !== 'jazzcash') {
                        setAccountNumber(e.target.value);
                      }
                    }}
                    readOnly={method === 'jazzcash'}
                    placeholder="03701220965"
                    maxLength={13}
                    required
                    className={`w-full pl-16 pr-4 py-2.5 rounded-2xl text-xs border text-white font-mono outline-none transition-colors ${
                      method === 'jazzcash'
                        ? 'bg-slate-950/70 border-emerald-500/40 text-emerald-300 cursor-not-allowed'
                        : 'bg-slate-800 border-slate-700 focus:border-indigo-500'
                    }`}
                  />
                </div>
                <p className="text-[10px] text-emerald-400 font-bold flex items-center gap-1 mt-1">
                  <ShieldCheck className="w-3 h-3 text-emerald-400" />
                  <span>🔒 Registered Founder JazzCash Account (03701220965 — Locked & Protected)</span>
                </p>
              </div>

              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-300 flex items-center justify-between">
                  <span>CNIC (Verification)</span>
                  <span className="text-[10px] text-slate-400">13-digit</span>
                </label>
                <input
                  type="text"
                  value={cnic}
                  onChange={(e) => setCnic(e.target.value)}
                  placeholder="42101-9876543-1"
                  className="w-full px-4 py-2.5 rounded-2xl text-xs bg-slate-800 border border-slate-700 text-white font-mono outline-none focus:border-indigo-500 transition-colors"
                />
              </div>
            </div>

            {/* Amount in USD & Quick Chips */}
            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs font-semibold text-slate-300">
                <label>Withdrawal Amount (USD)</label>
                <button
                  type="button"
                  onClick={handleMaxClick}
                  className="text-amber-400 hover:text-amber-300 font-bold underline cursor-pointer"
                >
                  Max (${availableBalanceUsd.toFixed(2)})
                </button>
              </div>

              <div className="relative">
                <span className="absolute left-3.5 top-2.5 text-slate-400 font-bold text-sm">$</span>
                <input
                  type="number"
                  step="0.01"
                  min="1"
                  max={Math.max(1, availableBalanceUsd)}
                  value={amountUsd}
                  onChange={(e) => {
                    setAmountUsd(e.target.value);
                    setErrorMsg('');
                  }}
                  className="w-full pl-8 pr-28 py-2.5 rounded-2xl text-sm font-bold bg-slate-800 border border-slate-700 text-white outline-none focus:border-emerald-500 transition-colors"
                />
                <span className="absolute right-3.5 top-2.5 text-xs font-bold text-emerald-400">
                  ≈ Rs. {estimatedPkr.toLocaleString()} PKR
                </span>
              </div>

              {/* Quick Preset Buttons */}
              <div className="flex items-center gap-2 pt-1 flex-wrap">
                {[10, 25, 50, 100].map((amt) => (
                  <button
                    key={amt}
                    type="button"
                    onClick={() => {
                      setAmountUsd(amt.toString());
                      setErrorMsg('');
                    }}
                    className={`px-3 py-1 rounded-xl text-xs font-bold border transition-colors cursor-pointer ${
                      amountUsd === amt.toString()
                        ? 'bg-amber-500/20 border-amber-500 text-amber-300'
                        : 'bg-slate-800/80 border-slate-700 hover:bg-slate-700 text-slate-300'
                    }`}
                  >
                    ${amt} (Rs. {(amt * PKR_RATE).toLocaleString()})
                  </button>
                ))}
              </div>
            </div>

            {/* Live Exchange Rate & 0% Fee Guarantee */}
            <div className="p-3.5 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-1.5 text-xs">
              <div className="flex items-center justify-between text-slate-400">
                <span>Official Live Conversion Rate:</span>
                <strong className="text-white font-mono">1 USD = 280.00 PKR</strong>
              </div>
              <div className="flex items-center justify-between text-slate-400">
                <span>Founder Payout Fee:</span>
                <strong className="text-emerald-400 font-bold">0% (Rs. 0 Fee)</strong>
              </div>
              <div className="flex items-center justify-between text-slate-400">
                <span>Total Disbursed to {method === 'jazzcash' ? 'JazzCash' : 'EasyPaisa'}:</span>
                <strong className="text-emerald-300 font-black text-sm">
                  Rs. {estimatedPkr.toLocaleString()} PKR
                </strong>
              </div>
            </div>

            {/* Error Message */}
            {errorMsg && (
              <div className="p-3 rounded-2xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
                <span>{errorMsg}</span>
              </div>
            )}

            {/* If balance is 0, give user a convenient button to simulate test incoming commission */}
            {availableBalanceUsd <= 0 && onAddDemoFunds && (
              <div className="p-3 rounded-2xl bg-blue-500/10 border border-blue-500/30 text-xs flex items-center justify-between gap-2">
                <span className="text-blue-300">
                  Treasury balance is $0.00. Add test live commission to try withdrawal:
                </span>
                <button
                  type="button"
                  onClick={() => onAddDemoFunds(50)}
                  className="px-3 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold cursor-pointer shrink-0"
                >
                  + Add $50 Demo
                </button>
              </div>
            )}

            {/* Submit Button */}
            <button
              type="submit"
              disabled={isProcessing}
              className={`w-full py-3.5 rounded-2xl font-black text-xs sm:text-sm text-white flex items-center justify-center gap-2 shadow-xl cursor-pointer active:scale-95 transition-all ${
                method === 'jazzcash'
                  ? 'bg-gradient-to-r from-red-600 via-rose-600 to-amber-600 hover:opacity-90'
                  : 'bg-gradient-to-r from-emerald-600 via-teal-600 to-green-600 hover:opacity-90'
              }`}
            >
              {isProcessing ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>{processStep || 'Processing Instant Transfer...'}</span>
                </>
              ) : (
                <>
                  <Wallet className="w-4 h-4" />
                  <span>
                    Withdraw Rs. {estimatedPkr.toLocaleString()} PKR to{' '}
                    {method === 'jazzcash' ? 'JazzCash' : 'EasyPaisa'}
                  </span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </form>
        )}
      </div>
    </div>
  );
};
