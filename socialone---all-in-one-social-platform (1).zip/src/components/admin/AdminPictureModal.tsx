import React, { useState, useRef } from 'react';
import { useAuth } from '../../context/AuthContext';
import { X, Camera, Upload, Check, User, Sparkles, Image as ImageIcon } from 'lucide-react';

interface AdminPictureModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const EXECUTIVE_PRESETS = [
  {
    name: 'Intekhab Alam (Founder & CEO - Official)',
    url: '/assets/aistudio/file_00000000a0a08208a8c468d7ead758ff_e2572f23.png',
  },
  {
    name: 'Executive Tech Leader (Dark Suit)',
    url: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&auto=format&fit=crop&q=80',
  },
  {
    name: 'Founder & Visionary (Studio Portrait)',
    url: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=400&auto=format&fit=crop&q=80',
  },
  {
    name: 'Modern CEO (Blazer & Glasses)',
    url: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400&auto=format&fit=crop&q=80',
  },
];

export const AdminPictureModal: React.FC<AdminPictureModalProps> = ({ isOpen, onClose }) => {
  const { userProfile, updateAdminPicture } = useAuth();
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const [selectedPhoto, setSelectedPhoto] = useState<string>(
    userProfile?.photoURL || EXECUTIVE_PRESETS[0].url
  );
  const [customUrl, setCustomUrl] = useState<string>('');
  const [isSaving, setIsSaving] = useState(false);
  const [savedSuccess, setSavedSuccess] = useState(false);

  if (!isOpen) return null;

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        setSelectedPhoto(reader.result);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleApplyUrl = () => {
    if (customUrl.trim().startsWith('http')) {
      setSelectedPhoto(customUrl.trim());
      setCustomUrl('');
    }
  };

  const handleSave = async () => {
    setIsSaving(true);
    try {
      await updateAdminPicture(selectedPhoto);
      setSavedSuccess(true);
      setTimeout(() => {
        setSavedSuccess(false);
        onClose();
      }, 1000);
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
      <div className="max-w-md w-full rounded-3xl bg-slate-900 border border-amber-500/30 text-white shadow-2xl p-6 space-y-5">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-white/10">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center border border-amber-500/30">
              <Camera className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-black text-white">Admin Picture / Photo Update</h3>
              <p className="text-[11px] text-slate-400">Intekhab Alam (Founder &amp; CEO)</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-slate-400 hover:text-white cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Current Preview */}
        <div className="flex flex-col items-center justify-center py-2 space-y-3">
          <div className="relative group">
            <img
              src={selectedPhoto}
              alt="Admin Preview"
              className="w-32 h-32 rounded-3xl object-cover ring-4 ring-amber-400 shadow-2xl bg-slate-800"
            />
            <button
              onClick={() => fileInputRef.current?.click()}
              className="absolute inset-0 bg-black/50 rounded-3xl opacity-0 group-hover:opacity-100 flex flex-col items-center justify-center text-white text-xs font-bold transition-opacity cursor-pointer gap-1"
            >
              <Upload className="w-6 h-6 text-amber-300" />
              <span>Upload New</span>
            </button>
          </div>
          <span className="text-xs text-amber-300 font-semibold flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5" />
            Founder &amp; CEO Official Avatar
          </span>
        </div>

        {/* Hidden File Input */}
        <input
          ref={fileInputRef}
          type="file"
          accept="image/*"
          onChange={handleFileUpload}
          className="hidden"
        />

        {/* Upload Buttons */}
        <div className="space-y-3 text-xs">
          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            className="w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-amber-500 to-rose-600 hover:opacity-95 text-white font-bold flex items-center justify-center gap-2 cursor-pointer shadow-md active:scale-98 transition-transform"
          >
            <Upload className="w-4 h-4" />
            <span>Upload Picture from Device / Gallery</span>
          </button>

          {/* Custom URL Input */}
          <div className="flex items-center gap-2">
            <input
              type="url"
              value={customUrl}
              onChange={(e) => setCustomUrl(e.target.value)}
              placeholder="Or paste direct image URL (https://...)"
              className="flex-1 px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs outline-none focus:border-amber-400 font-mono"
            />
            <button
              type="button"
              onClick={handleApplyUrl}
              disabled={!customUrl.trim().startsWith('http')}
              className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-amber-300 font-bold border border-slate-700 disabled:opacity-40 cursor-pointer"
            >
              Apply
            </button>
          </div>
        </div>

        {/* Executive Presets Grid */}
        <div className="space-y-2 pt-1">
          <p className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
            Executive Founder Presets:
          </p>
          <div className="grid grid-cols-4 gap-2">
            {EXECUTIVE_PRESETS.map((preset, idx) => {
              const isSelected = selectedPhoto === preset.url;
              return (
                <button
                  key={idx}
                  type="button"
                  onClick={() => setSelectedPhoto(preset.url)}
                  className={`relative rounded-2xl overflow-hidden aspect-square border-2 transition-all cursor-pointer group ${
                    isSelected
                      ? 'border-amber-400 ring-2 ring-amber-400/50 scale-105'
                      : 'border-slate-700 hover:border-slate-500'
                  }`}
                  title={preset.name}
                >
                  <img
                    src={preset.url}
                    alt={preset.name}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform"
                  />
                  {isSelected && (
                    <div className="absolute top-1 right-1 w-4 h-4 rounded-full bg-amber-400 text-slate-950 flex items-center justify-center">
                      <Check className="w-3 h-3 stroke-[3]" />
                    </div>
                  )}
                </button>
              );
            })}
          </div>
        </div>

        {/* Save & Confirm */}
        <div className="pt-2">
          <button
            type="button"
            onClick={handleSave}
            disabled={isSaving}
            className="w-full py-3 rounded-2xl bg-gradient-to-r from-emerald-600 via-teal-600 to-indigo-600 hover:opacity-95 text-white font-black text-xs shadow-xl cursor-pointer flex items-center justify-center gap-2 active:scale-98 transition-all"
          >
            {savedSuccess ? (
              <>
                <Check className="w-4 h-4 text-emerald-300" />
                <span>Admin Picture Updated Successfully!</span>
              </>
            ) : isSaving ? (
              <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
            ) : (
              <>
                <Check className="w-4 h-4" />
                <span>Save &amp; Apply Admin Picture</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
