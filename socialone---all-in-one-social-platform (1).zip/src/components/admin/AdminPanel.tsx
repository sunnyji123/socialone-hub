import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useApp } from '../../context/AppContext';

import {
  ShieldCheck,
  Users,
  Video,
  FileText,
  AlertTriangle,
  CheckCircle,
  XCircle,
  Sparkles,
  Settings,
  Activity,
  Trash2,
  Lock,
  DollarSign,
  Gift,
  Crown,
  Wallet,
  ArrowUpRight,
  Smartphone,
  CheckCircle2,
  Check,
  PlusCircle,
  ExternalLink,
  Camera,
  Clock,
  TrendingUp,
  RefreshCw,
  PlayCircle,
  Sliders,
  Calendar,
  Percent,
} from 'lucide-react';
import { FounderWithdrawalModal } from './FounderWithdrawalModal';
import { AdminPictureModal } from './AdminPictureModal';
import { FounderDailySettlementModal } from './FounderDailySettlementModal';
import { AutoPayoutSettingsModal } from './AutoPayoutSettingsModal';
import { FounderWithdrawal } from '../../types';
import {
  DailyProfitSettlement,
  getPakistanTime,
  calculateDailyNetProfit,
} from '../../lib/jazzcashPayoutService';

export const AdminPanel: React.FC = () => {
  const { userProfile, darkMode, isAdmin, loginAsFounder, loginWithAdminCredentials } = useAuth();
  const {
    posts,
    videos,
    reports,
    resolveReport,
    deletePost,
    deleteVideo,
    ownerPlatformRevenue,
    ownerWithdrawnRevenue,
    founderWithdrawals,
    withdrawFounderRevenue,
    founderProfitWallet,
    initiateFounderManualWithdrawal,
    refreshFounderWallet,
    addOwnerCommission,
    liveGiftingHistory,
    autoPayoutConfig,
    dailySettlementLedger,
    updateAutoPayoutSettings,
    triggerManualAutoPayoutRun,
    countdown8Pm,
  } = useApp();

  const [isWithdrawModalOpen, setIsWithdrawModalOpen] = useState(false);
  const [isAdminPicModalOpen, setIsAdminPicModalOpen] = useState(false);
  const [isAutoSettingsModalOpen, setIsAutoSettingsModalOpen] = useState(false);
  const [selectedReceipt, setSelectedReceipt] = useState<FounderWithdrawal | null>(null);
  const [selectedDailyReceipt, setSelectedDailyReceipt] = useState<DailyProfitSettlement | null>(null);
  const [revenueTab, setRevenueTab] = useState<'wallet' | 'settings' | 'history' | 'gifts'>('wallet');
  const [isExecutingDisbursement, setIsExecutingDisbursement] = useState(false);
  const [executionMessage, setExecutionMessage] = useState<{ text: string; type: 'success' | 'error' } | null>(null);

  const [platformAnnouncement, setPlatformAnnouncement] = useState(
    'SocialOne v1.0 Live: All-in-One Social Ecosystem is officially running!'
  );
  const [isSavedAnnouncement, setIsSavedAnnouncement] = useState(false);
  const [maintenanceMode, setMaintenanceMode] = useState(false);

  // Dedicated Admin Security Credentials Gate (gulamaftab74@gmail.com & password 03701220965)
  const [isSecurityUnlocked, setIsSecurityUnlocked] = useState<boolean>(() => {
    return (
      sessionStorage.getItem('socialone_admin_unlocked') === 'true' ||
      localStorage.getItem('socialone_admin_pin_verified') === 'true'
    );
  });
  const [adminEmail, setAdminEmail] = useState('gulamaftab74@gmail.com');
  const [adminPassword, setAdminPassword] = useState('');
  const [authError, setAuthError] = useState<string | null>(null);
  const [isVerifying, setIsVerifying] = useState(false);

  const handleUnlockAdmin = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsVerifying(true);
    setAuthError(null);
    try {
      const cleanEmail = adminEmail.trim().toLowerCase();
      const cleanPass = adminPassword.trim();
      const isMatch =
        (cleanEmail === 'gulamaftab74@gmail.com' ||
          cleanEmail === 'sunnyjiansari456@gmail.com' ||
          cleanEmail === 'admin') &&
        cleanPass === '03701220965';

      if (isMatch) {
        await loginWithAdminCredentials(cleanEmail, cleanPass);
        setIsSecurityUnlocked(true);
        sessionStorage.setItem('socialone_admin_unlocked', 'true');
        localStorage.setItem('socialone_admin_pin_verified', 'true');
      } else {
        setAuthError('Ghalat Email ya Password. Barah-e-karam apna durust admin password darj karein.');
      }
    } finally {
      setIsVerifying(false);
    }
  };

  const handleLockAdmin = () => {
    setIsSecurityUnlocked(false);
    sessionStorage.removeItem('socialone_admin_unlocked');
    localStorage.removeItem('socialone_admin_pin_verified');
    setAdminPassword('');
  };

  // If Admin Security Gate is locked, prompt for gulamaftab74@gmail.com and password 03701220965
  if (!isSecurityUnlocked) {
    return (
      <div className="max-w-md mx-auto my-14 p-6 sm:p-8 rounded-3xl border text-center space-y-5 bg-slate-900 border-slate-800 text-white shadow-2xl">
        <div className="w-16 h-16 rounded-3xl bg-gradient-to-tr from-amber-500 to-rose-600 text-white mx-auto flex items-center justify-center shadow-lg shadow-amber-500/20">
          <Lock className="w-8 h-8" />
        </div>

        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-wider bg-amber-500/15 text-amber-400 border border-amber-500/30 mb-2">
            <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
            <span>Admin Security Lock & Treasury Gate</span>
          </div>
          <h3 className="text-xl sm:text-2xl font-black">Admin Panel Authorization</h3>
          <p className="text-xs text-slate-400 mt-1">
            Apna authorized admin email aur password darj karein taake 25% revenue treasury aur platform control open ho sakay.
          </p>
        </div>

        {authError && (
          <div className="p-3 rounded-2xl bg-rose-500/10 border border-rose-500/30 text-rose-400 text-xs font-semibold text-left">
            {authError}
          </div>
        )}

        <form onSubmit={handleUnlockAdmin} className="space-y-3.5 text-left">
          <div>
            <label className="block text-xs font-bold text-slate-300 mb-1">
              Admin Email Address:
            </label>
            <input
              type="email"
              required
              value={adminEmail}
              onChange={(e) => setAdminEmail(e.target.value)}
              placeholder="gulamaftab74@gmail.com"
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs outline-none focus:border-amber-400 font-mono"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-300 mb-1 flex items-center justify-between">
              <span>Admin Password / Security PIN:</span>
              <span className="text-[10px] text-amber-400 font-normal">Encrypted</span>
            </label>
            <input
              type="password"
              required
              value={adminPassword}
              onChange={(e) => setAdminPassword(e.target.value)}
              placeholder="••••••••••••"
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs outline-none focus:border-amber-400 font-mono tracking-wider"
            />
          </div>

          <div className="pt-1">
            <button
              type="submit"
              disabled={isVerifying}
              className="w-full py-3 px-4 rounded-2xl bg-gradient-to-r from-amber-500 via-rose-500 to-indigo-600 hover:opacity-95 text-white font-black text-xs shadow-xl cursor-pointer transition-all active:scale-95 flex items-center justify-center gap-2"
            >
              {isVerifying ? (
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
              ) : (
                <>
                  <ShieldCheck className="w-4 h-4" />
                  <span>Unlock Admin Security Panel</span>
                </>
              )}
            </button>
          </div>
        </form>

        <div className="pt-2 border-t border-slate-800 text-[11px] text-slate-500 flex items-center justify-center gap-1.5">
          <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
          <span>Admin Security Gate Active &amp; Protected</span>
        </div>
      </div>
    );
  }

  const handleSaveAnnouncement = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSavedAnnouncement(true);
    setTimeout(() => setIsSavedAnnouncement(false), 2500);
  };

  const handleRemoveReportedItem = (reportId: string, targetType: string, targetId: string) => {
    if (targetType === 'post') {
      deletePost(targetId);
    } else if (targetType === 'video') {
      deleteVideo(targetId);
    }
    resolveReport(reportId, 'resolve');
  };

  return (
    <div className="max-w-5xl mx-auto w-full pb-20 space-y-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 p-6 rounded-3xl bg-gradient-to-r from-blue-900/40 via-indigo-900/40 to-teal-900/30 border border-blue-500/30">
        <div className="flex items-center gap-4">
          {/* Admin / Founder Picture Avatar Card */}
          <div className="relative group shrink-0">
            <img
              src={
                userProfile?.photoURL ||
                '/assets/aistudio/file_00000000a0a08208a8c468d7ead758ff_e2572f23.png'
              }
              alt="Intekhab Alam"
              className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl object-cover ring-2 ring-amber-400 shadow-xl bg-slate-800"
            />
            <button
              onClick={() => setIsAdminPicModalOpen(true)}
              className="absolute -bottom-1 -right-1 p-1.5 rounded-xl bg-gradient-to-r from-amber-500 to-rose-600 text-white shadow-md hover:scale-110 transition-transform cursor-pointer"
              title="Change Admin Picture (Gallery / Presets)"
            >
              <Camera className="w-3.5 h-3.5" />
            </button>
          </div>

          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-bold bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 mb-1">
              <ShieldCheck className="w-4 h-4 text-amber-400" />
              <span>SocialOne Founder &amp; CEO Console</span>
            </div>
            <h1 className="text-xl sm:text-2xl font-black tracking-tight text-white flex items-center gap-2">
              <span>Intekhab Alam</span>
              <span className="px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 text-[10px] font-bold border border-amber-500/30">
                25% Shareholder
              </span>
            </h1>
            <p className="text-xs text-slate-300 mt-0.5">
              Automated daily profit disbursement scheduled for <strong className="text-teal-300">8:00 PM PKT</strong>.
            </p>
            <div className="flex items-center gap-2 mt-2 flex-wrap text-[11px]">
              <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 font-mono font-bold flex items-center gap-1">
                <ShieldCheck className="w-3 h-3 text-emerald-400" />
                gulamaftab74@gmail.com
              </span>
              <span className="px-2.5 py-0.5 rounded-full bg-rose-500/15 border border-rose-500/30 text-rose-300 font-mono font-bold flex items-center gap-1">
                🔴 JazzCash: 03701220965
              </span>
              <button
                type="button"
                onClick={() => setIsAdminPicModalOpen(true)}
                className="px-2.5 py-0.5 rounded-full bg-amber-500/15 border border-amber-500/30 text-amber-300 text-[11px] font-bold hover:bg-amber-500/25 transition-colors cursor-pointer flex items-center gap-1"
              >
                <Camera className="w-3 h-3" />
                <span>Admin Picture</span>
              </button>
            </div>
          </div>
        </div>

        <div className="flex flex-col sm:items-end gap-2 text-xs">
          <div className="flex items-center gap-2">
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-400 font-semibold border border-emerald-500/30">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              Session Authenticated &amp; Secured
            </span>
            <button
              onClick={handleLockAdmin}
              className="px-3 py-1 rounded-full bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 border border-rose-500/40 text-[11px] font-bold cursor-pointer transition-colors"
              title="Lock Admin Panel"
            >
              🔒 Lock Panel
            </button>
          </div>
          <p className="text-[10px] text-slate-400">Private &amp; Encrypted to Owner</p>
        </div>
      </div>

      {/* Analytics Metric Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div
          className={`p-4 rounded-3xl border ${
            darkMode ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200 shadow-xs'
          }`}
        >
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-semibold">Active Posts</span>
            <FileText className="w-4 h-4 text-blue-500" />
          </div>
          <p className="text-2xl font-black">{posts.length}</p>
          <span className="text-[10px] text-emerald-400 font-medium">Realtime database</span>
        </div>

        <div
          className={`p-4 rounded-3xl border ${
            darkMode ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200 shadow-xs'
          }`}
        >
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-semibold">Short Videos</span>
            <Video className="w-4 h-4 text-purple-500" />
          </div>
          <p className="text-2xl font-black">{videos.length}</p>
          <span className="text-[10px] text-emerald-400 font-medium">TikTok stream active</span>
        </div>

        <div
          className={`p-4 rounded-3xl border ${
            darkMode ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200 shadow-xs'
          }`}
        >
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-semibold">Moderation Reports</span>
            <AlertTriangle className="w-4 h-4 text-amber-500" />
          </div>
          <p className="text-2xl font-black">
            {reports.filter((r) => r.status === 'pending').length}
          </p>
          <span className="text-[10px] text-amber-400 font-medium">Pending reviews</span>
        </div>

        <div
          className={`p-4 rounded-3xl border ${
            darkMode ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200 shadow-xs'
          }`}
        >
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-semibold">WebRTC Calls</span>
            <Activity className="w-4 h-4 text-emerald-500" />
          </div>
          <p className="text-2xl font-black">100%</p>
          <span className="text-[10px] text-emerald-400 font-medium">STUN/TURN Signaling</span>
        </div>
      </div>

      {/* Owner Revenue & 25% Platform Commission Section */}
      {(() => {
        const availableBalance = Math.max(
          0,
          Number((ownerPlatformRevenue - (ownerWithdrawnRevenue || 0)).toFixed(2))
        );
        const withdrawnBalance = ownerWithdrawnRevenue || 0;
        const PKR_RATE = 280;

        return (
          <div className="p-6 rounded-3xl bg-gradient-to-r from-amber-950/40 via-slate-900/90 to-slate-900/90 border border-amber-500/40 space-y-6 shadow-xl">
            {/* Header & Founder Credentials */}
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-4 border-b border-amber-500/20">
              <div>
                <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-wider bg-amber-500/20 text-amber-300 border border-amber-500/30">
                  <Crown className="w-3.5 h-3.5 text-amber-400" />
                  <span>Founder & CEO Treasury</span>
                </div>
                <h2 className="text-xl sm:text-2xl font-black text-white mt-1 flex items-center gap-2">
                  <span>Intekhab Alam — Platform Monetization</span>
                </h2>
                <p className="text-xs text-slate-300">
                  Direct 25% platform cut from all TikTok Live gifts. Disbursal connected to dedicated private JazzCash account: <strong className="text-emerald-400 font-mono">03701220965</strong>.
                </p>
              </div>

              {/* Direct Withdrawal Actions */}
              <div className="flex items-center gap-2 flex-wrap">
                <button
                  type="button"
                  onClick={() => setIsWithdrawModalOpen(true)}
                  className="px-5 py-2.5 rounded-2xl bg-gradient-to-r from-red-600 via-rose-600 to-emerald-600 hover:opacity-95 text-white font-black text-xs flex items-center gap-2 shadow-lg cursor-pointer active:scale-95 transition-all"
                >
                  <Wallet className="w-4 h-4" />
                  <span>Withdraw to JazzCash (03701220965)</span>
                  <ArrowUpRight className="w-4 h-4" />
                </button>

                <button
                  type="button"
                  onClick={() => addOwnerCommission(50)}
                  title="Simulate incoming TikTok live gifts ($50 USD = Rs. 14,000 PKR)"
                  className="px-3.5 py-2.5 rounded-2xl bg-slate-800 hover:bg-slate-700 text-amber-300 font-bold text-xs flex items-center gap-1.5 border border-slate-700 cursor-pointer transition-colors"
                >
                  <PlusCircle className="w-3.5 h-3.5" />
                  <span>+$50 Demo Cut</span>
                </button>
              </div>
            </div>

            {/* Treasury Balance Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              {/* Card 1: Available Balance */}
              <div className="p-4 rounded-2xl bg-slate-950/70 border border-emerald-500/30 space-y-1">
                <span className="text-[11px] font-semibold text-emerald-400 flex items-center justify-between">
                  <span>Available to Withdraw</span>
                  <span className="text-[10px] px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300">Instant</span>
                </span>
                <p className="text-2xl sm:text-3xl font-black text-emerald-300">
                  ${availableBalance.toFixed(2)}{' '}
                  <span className="text-xs font-normal text-slate-400">USD</span>
                </p>
                <p className="text-xs font-bold text-emerald-400/90">
                  ≈ Rs. {Math.round(availableBalance * PKR_RATE).toLocaleString()} PKR
                </p>
              </div>

              {/* Card 2: Total Disbursed */}
              <div className="p-4 rounded-2xl bg-slate-950/70 border border-slate-800 space-y-1">
                <span className="text-[11px] font-semibold text-slate-400 flex items-center justify-between">
                  <span>Total Disbursed (JazzCash / EasyPaisa)</span>
                  <Smartphone className="w-3.5 h-3.5 text-slate-400" />
                </span>
                <p className="text-2xl sm:text-3xl font-black text-slate-200">
                  ${withdrawnBalance.toFixed(2)}{' '}
                  <span className="text-xs font-normal text-slate-400">USD</span>
                </p>
                <p className="text-xs font-bold text-slate-400">
                  ≈ Rs. {Math.round(withdrawnBalance * PKR_RATE).toLocaleString()} PKR
                </p>
              </div>

              {/* Card 3: Total Lifetime 25% Share */}
              <div className="p-4 rounded-2xl bg-slate-950/70 border border-amber-500/30 space-y-1">
                <span className="text-[11px] font-semibold text-amber-400 flex items-center justify-between">
                  <span>Lifetime 25% Commission</span>
                  <Crown className="w-3.5 h-3.5 text-amber-400" />
                </span>
                <p className="text-2xl sm:text-3xl font-black text-amber-300">
                  ${ownerPlatformRevenue.toFixed(2)}{' '}
                  <span className="text-xs font-normal text-slate-400">USD</span>
                </p>
                <p className="text-xs font-bold text-amber-400/80">
                  ≈ Rs. {Math.round(ownerPlatformRevenue * PKR_RATE).toLocaleString()} PKR
                </p>
              </div>
            </div>

            {/* Sub-Tabs: Founder Profit Wallet vs Payout Settings vs Live Gifts */}
            <div className="space-y-4">
              <div className="flex items-center gap-2 border-b border-white/10 pb-2 flex-wrap">
                <button
                  type="button"
                  onClick={() => setRevenueTab('wallet')}
                  className={`px-4 py-2 rounded-xl text-xs font-black transition-all cursor-pointer flex items-center gap-1.5 ${
                    revenueTab === 'wallet'
                      ? 'bg-gradient-to-r from-amber-500 via-rose-500 to-indigo-600 text-white shadow-md'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  <Wallet className="w-3.5 h-3.5" />
                  <span>💼 Founder Profit Wallet ({founderWithdrawals.length})</span>
                </button>

                <button
                  type="button"
                  onClick={() => setRevenueTab('settings')}
                  className={`px-4 py-2 rounded-xl text-xs font-black transition-colors cursor-pointer flex items-center gap-1.5 ${
                    revenueTab === 'settings'
                      ? 'bg-amber-500 text-slate-950 shadow-sm'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  <Sliders className="w-3.5 h-3.5" />
                  <span>⚙️ Founder Payout Settings &amp; Formula</span>
                </button>

                <button
                  type="button"
                  onClick={() => setRevenueTab('gifts')}
                  className={`px-4 py-2 rounded-xl text-xs font-black transition-colors cursor-pointer flex items-center gap-1.5 ${
                    revenueTab === 'gifts'
                      ? 'bg-amber-500 text-slate-950 shadow-sm'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  <Gift className="w-3.5 h-3.5" />
                  <span>TikTok Live Gifts Split ({liveGiftingHistory.length})</span>
                </button>
              </div>

              {/* TAB 1: SOCIALONE — FOUNDER PROFIT WALLET (RULES 1 - 12) */}
              {revenueTab === 'wallet' && (
                <div className="space-y-5">
                  {/* Founder Profile & Wallet Credentials Card */}
                  <div className="p-5 rounded-2xl bg-gradient-to-br from-slate-950 via-slate-900 to-amber-950/30 border border-amber-500/30 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 shadow-lg">
                    <div className="flex items-center gap-4">
                      <div className="relative group shrink-0">
                        <img
                          src="/assets/aistudio/file_00000000a0a08208a8c468d7ead758ff_e2572f23.png"
                          alt="Intekhab Alam"
                          className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl object-cover ring-2 ring-amber-400 shadow-xl bg-slate-800"
                        />
                        <button
                          type="button"
                          onClick={() => setIsAdminPicModalOpen(true)}
                          className="absolute -bottom-1 -right-1 p-1 rounded-lg bg-amber-500 text-slate-950 hover:bg-amber-400 shadow cursor-pointer transition-transform hover:scale-110"
                          title="Change Photo"
                        >
                          <Camera className="w-3 h-3" />
                        </button>
                      </div>

                      <div className="space-y-1">
                        <div className="flex items-center gap-2 flex-wrap">
                          <h3 className="font-black text-white text-base sm:text-lg">
                            Intekhab Alam
                          </h3>
                          <span className="px-2 py-0.5 rounded-full bg-gradient-to-r from-amber-500 to-rose-600 text-white text-[10px] font-black uppercase tracking-wider">
                            Founder &amp; CEO
                          </span>
                          <span className="px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30 text-[10px] font-bold">
                            25% Monthly Net Profit
                          </span>
                        </div>
                        <p className="text-xs text-slate-300">
                          Registered JazzCash Account:{' '}
                          <strong className="text-emerald-400 font-mono tracking-wider">
                            03701220965
                          </strong>{' '}
                          (Title: <span className="text-white">Intekhab Alam</span>)
                        </p>
                        <p className="text-[11px] text-slate-400 flex items-center gap-1.5 pt-0.5">
                          <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                          <span>Owner Protected: Locked exclusively to Founder Intekhab Alam.</span>
                        </p>
                      </div>
                    </div>

                    {/* Manual Withdrawal Trigger Button (Rule 6 & 7) */}
                    <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2 w-full md:w-auto">
                      <button
                        type="button"
                        onClick={() => setIsWithdrawModalOpen(true)}
                        className="px-5 py-3 rounded-2xl bg-gradient-to-r from-amber-500 via-rose-500 to-emerald-600 hover:opacity-95 text-white font-black text-xs shadow-xl cursor-pointer active:scale-95 transition-all flex items-center justify-center gap-2"
                      >
                        <Wallet className="w-4 h-4" />
                        <span>Withdraw to JazzCash (03701220965)</span>
                        <ArrowUpRight className="w-4 h-4" />
                      </button>

                      <button
                        type="button"
                        onClick={() => setIsAutoSettingsModalOpen(true)}
                        className="px-3.5 py-3 rounded-2xl bg-slate-800 hover:bg-slate-700 text-amber-300 border border-slate-700 font-bold text-xs cursor-pointer flex items-center justify-center gap-1.5 transition-colors"
                        title="Configure Payout Settings & Formula"
                      >
                        <Sliders className="w-3.5 h-3.5" />
                        <span>Settings</span>
                      </button>
                    </div>
                  </div>

                  {/* Rule 5 Notice: Safe Account Recording without Auto-Disbursement */}
                  <div className="p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 flex items-start gap-3 text-xs text-slate-300">
                    <ShieldCheck className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
                    <div className="space-y-1">
                      <p className="font-bold text-white">
                        Rule 4 &amp; 5 Protection: 25% Profit Safely Recorded in Founder&apos;s Account
                      </p>
                      <p className="text-[11px] text-slate-300 leading-relaxed">
                        Per Founder specifications, <strong>automatic transfers are DISABLED</strong>. The platform automatically calculates your 25% net profit share from all platform activities and credits it safely to your available balance. Money is <em>never</em> transferred automatically — you maintain complete control and can initiate a manual withdrawal to your registered JazzCash account <strong className="font-mono text-emerald-400">03701220965</strong> whenever you desire.
                      </p>
                    </div>
                  </div>

                  {/* 4 Financial Overview Cards (Rule 3) */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-xs">
                    {/* Available Balance */}
                    <div className="p-4 rounded-2xl bg-slate-950/80 border border-emerald-500/30 space-y-1">
                      <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-400 flex items-center justify-between">
                        <span>Available Balance</span>
                        <span className="px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300 text-[9px]">Ready</span>
                      </span>
                      <p className="text-2xl font-black text-emerald-300">
                        ${availableBalance.toFixed(2)}{' '}
                        <span className="text-xs font-normal text-slate-400">USD</span>
                      </p>
                      <p className="text-xs font-bold text-emerald-400">
                        ≈ Rs. {Math.round(availableBalance * PKR_RATE).toLocaleString()} PKR
                      </p>
                      <p className="text-[10px] text-slate-400 pt-1">
                        Stored safely in Founder Wallet
                      </p>
                    </div>

                    {/* Total Lifetime Earnings */}
                    <div className="p-4 rounded-2xl bg-slate-950/80 border border-amber-500/30 space-y-1">
                      <span className="text-[10px] font-bold uppercase tracking-wider text-amber-400 flex items-center justify-between">
                        <span>Total 25% Earnings</span>
                        <Crown className="w-3.5 h-3.5 text-amber-400" />
                      </span>
                      <p className="text-2xl font-black text-amber-300">
                        ${ownerPlatformRevenue.toFixed(2)}{' '}
                        <span className="text-xs font-normal text-slate-400">USD</span>
                      </p>
                      <p className="text-xs font-bold text-amber-400">
                        ≈ Rs. {Math.round(ownerPlatformRevenue * PKR_RATE).toLocaleString()} PKR
                      </p>
                      <p className="text-[10px] text-slate-400 pt-1">
                        Cumulative 25% net profit
                      </p>
                    </div>

                    {/* Total Withdrawn */}
                    <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-1">
                      <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 flex items-center justify-between">
                        <span>Total Withdrawn</span>
                        <Smartphone className="w-3.5 h-3.5 text-slate-400" />
                      </span>
                      <p className="text-2xl font-black text-white">
                        ${withdrawnBalance.toFixed(2)}{' '}
                        <span className="text-xs font-normal text-slate-400">USD</span>
                      </p>
                      <p className="text-xs font-bold text-slate-300">
                        ≈ Rs. {Math.round(withdrawnBalance * PKR_RATE).toLocaleString()} PKR
                      </p>
                      <p className="text-[10px] text-slate-400 pt-1">
                        Transferred to 03701220965
                      </p>
                    </div>

                    {/* Registered JazzCash Account */}
                    <div className="p-4 rounded-2xl bg-slate-950/80 border border-rose-500/30 space-y-1">
                      <span className="text-[10px] font-bold uppercase tracking-wider text-rose-400 flex items-center justify-between">
                        <span>Registered Account</span>
                        <span className="px-1.5 py-0.5 rounded bg-rose-500/20 text-rose-300 text-[9px]">Protected</span>
                      </span>
                      <p className="text-lg font-black font-mono text-white pt-1">
                        03701220965
                      </p>
                      <p className="text-xs font-semibold text-rose-300">
                        JazzCash Mobile Account
                      </p>
                      <p className="text-[10px] text-emerald-400 flex items-center gap-1 pt-1">
                        <Check className="w-3 h-3" />
                        <span>Verified 1Link / Raast</span>
                      </p>
                    </div>
                  </div>

                  {/* Transaction History & Payment Status Ledger (Rules 10, 11, 12) */}
                  <div className="space-y-3 pt-2">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                      <div>
                        <h4 className="font-black text-sm text-white flex items-center gap-2">
                          <Calendar className="w-4 h-4 text-amber-400" />
                          <span>Complete Founder Withdrawal &amp; Transaction History (Rule 11)</span>
                        </h4>
                        <p className="text-[11px] text-slate-400">
                          Accurate payment statuses: <span className="text-emerald-400 font-bold">Successful</span>, <span className="text-amber-400 font-bold">Pending</span>, <span className="text-indigo-400 font-bold">Processing</span>, <span className="text-rose-400 font-bold">Failed</span> (Rule 10). Real settled records only (Rule 12).
                        </p>
                      </div>

                      <div className="flex items-center gap-2">
                        <span className="text-[10px] font-mono text-slate-400 bg-slate-800 px-2.5 py-1 rounded-xl">
                          {founderWithdrawals.length} Total Disbursements
                        </span>
                      </div>
                    </div>

                    {founderWithdrawals.length === 0 ? (
                      <div className="p-8 rounded-2xl bg-black/40 border border-white/5 text-center text-xs text-slate-400 space-y-2">
                        <Wallet className="w-8 h-8 text-slate-500 mx-auto" />
                        <p>No manual withdrawals requested yet.</p>
                        <p className="text-[11px] text-slate-500">
                          Your available balance of <strong>${availableBalance.toFixed(2)} USD (Rs. {Math.round(availableBalance * PKR_RATE).toLocaleString()} PKR)</strong> is safely recorded and ready to withdraw anytime.
                        </p>
                      </div>
                    ) : (
                      <div className="space-y-2.5">
                        {founderWithdrawals.map((fwd) => {
                          const isSuccess = fwd.status === 'completed' || fwd.status === 'successful';
                          const isPending = fwd.status === 'pending';
                          const isProcessing = fwd.status === 'processing';
                          const isFailed = fwd.status === 'failed';

                          return (
                            <div
                              key={fwd.id}
                              className="p-4 rounded-2xl bg-black/40 border border-white/10 hover:border-amber-500/30 transition-colors flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs"
                            >
                              <div className="flex items-center gap-3">
                                <span
                                  className={`w-10 h-10 rounded-xl flex items-center justify-center text-xs font-black shrink-0 ${
                                    isSuccess
                                      ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                                      : isPending
                                      ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                                      : isProcessing
                                      ? 'bg-indigo-500/20 text-indigo-400 border border-indigo-500/30'
                                      : 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                                  }`}
                                >
                                  {isSuccess ? '✓' : isPending ? '⏳' : isProcessing ? '⚡' : '✕'}
                                </span>

                                <div className="space-y-0.5">
                                  <div className="flex items-center gap-2 flex-wrap">
                                    <span className="font-bold text-white text-xs sm:text-sm">
                                      {fwd.accountTitle}
                                    </span>

                                    {/* Accurate Status Badge (Rule 10) */}
                                    <span
                                      className={`text-[9px] font-black uppercase px-2.5 py-0.5 rounded-full border ${
                                        isSuccess
                                          ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30'
                                          : isPending
                                          ? 'bg-amber-500/20 text-amber-300 border-amber-500/30'
                                          : isProcessing
                                          ? 'bg-indigo-500/20 text-indigo-300 border-indigo-500/30'
                                          : 'bg-rose-500/20 text-rose-300 border-rose-500/30'
                                      }`}
                                    >
                                      {isSuccess ? 'Successful' : isPending ? 'Pending' : isProcessing ? 'Processing' : 'Failed'}
                                    </span>

                                    <span className="px-2 py-0.5 rounded-md bg-rose-500/15 text-rose-300 font-mono text-[10px] font-semibold">
                                      🔴 JazzCash: {fwd.accountNumber}
                                    </span>
                                  </div>

                                  <p className="text-[10px] text-slate-400 font-mono">
                                    TID: <strong className="text-amber-300">{fwd.transactionId}</strong> •{' '}
                                    {new Date(fwd.timestamp).toLocaleDateString()} at{' '}
                                    {new Date(fwd.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                                  </p>

                                  {fwd.note && (
                                    <p className="text-[10px] text-slate-400 line-clamp-1">
                                      {fwd.note}
                                    </p>
                                  )}
                                </div>
                              </div>

                              <div className="flex items-center justify-between sm:justify-end gap-3 shrink-0">
                                <div className="text-left sm:text-right">
                                  <p className="font-black text-sm text-emerald-400">
                                    Rs. {fwd.amountPkr.toLocaleString()} PKR
                                  </p>
                                  <span className="text-[10px] text-slate-400">
                                    (${fwd.amountUsd.toFixed(2)} USD • Exchange: 280)
                                  </span>
                                </div>

                                <button
                                  type="button"
                                  onClick={() => setSelectedReceipt(fwd)}
                                  className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-[10px] font-bold text-slate-300 hover:text-white border border-slate-700 cursor-pointer flex items-center gap-1 transition-colors"
                                >
                                  <span>Voucher</span>
                                  <ExternalLink className="w-3 h-3" />
                                </button>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* TAB 2: FOUNDER PAYOUT SETTINGS & CALCULATION FORMULA (RULES 1, 2, 9, 10) */}
              {revenueTab === 'settings' && (
                <div className="space-y-4">
                  {/* Settings Overview Card */}
                  <div className="p-5 rounded-2xl bg-slate-950/80 border border-amber-500/30 space-y-4">
                    <div className="flex items-center justify-between pb-3 border-b border-white/10">
                      <div>
                        <h4 className="font-black text-sm text-white flex items-center gap-2">
                          <Sliders className="w-4 h-4 text-amber-400" />
                          <span>Founder Payout Settings &amp; Protected Configuration</span>
                        </h4>
                        <p className="text-[11px] text-slate-400 mt-0.5">
                          Enforced by secure backend. Only Intekhab Alam can authorize changes.
                        </p>
                      </div>
                      <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-[10px] font-bold">
                        🔒 Owner-Locked
                      </span>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-xs">
                      <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 space-y-1">
                        <span className="text-[10px] text-slate-400">Registered JazzCash Account:</span>
                        <p className="font-mono font-bold text-emerald-300 text-sm">03701220965</p>
                        <p className="text-[10px] text-slate-400">Title: Intekhab Alam (Founder &amp; CEO)</p>
                      </div>

                      <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 space-y-1">
                        <span className="text-[10px] text-slate-400">Profit Share Entitlement:</span>
                        <p className="font-bold text-amber-300 text-sm">25% Monthly Net Profit</p>
                        <p className="text-[10px] text-slate-400">Calculated automatically</p>
                      </div>

                      <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 space-y-1">
                        <span className="text-[10px] text-slate-400">Automatic Payout Mode:</span>
                        <p className="font-bold text-rose-300 text-sm">DISABLED (Manual Only)</p>
                        <p className="text-[10px] text-slate-400">Rule 5: No auto-transfers</p>
                      </div>

                      <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 space-y-1">
                        <span className="text-[10px] text-slate-400">Exchange Rate:</span>
                        <p className="font-bold text-white text-sm">1 USD = 280 PKR</p>
                        <p className="text-[10px] text-emerald-400">Corporate Spot Rate</p>
                      </div>
                    </div>
                  </div>

                  {/* Today's Net Profit Calculation Breakdown (Rule 1 & Rule 2) */}
                  {(() => {
                    const todayCalc = calculateDailyNetProfit(
                      Math.max(ownerPlatformRevenue * 4, 120),
                      Math.max(ownerPlatformRevenue * 4, 120),
                      autoPayoutConfig
                    );

                    return (
                      <div className="p-4 rounded-2xl bg-gradient-to-r from-slate-950 via-slate-900 to-amber-950/40 border border-amber-500/25 space-y-3">
                        <div className="flex items-center justify-between pb-2 border-b border-white/10">
                          <div className="flex items-center gap-2 text-xs">
                            <Percent className="w-4 h-4 text-amber-400" />
                            <h5 className="font-bold text-white">
                              Audited Net Profit &amp; 25% Share Mathematical Breakdown (Rule 1 &amp; 2)
                            </h5>
                          </div>
                          <span className="text-[10px] font-mono text-emerald-400 bg-emerald-500/15 px-2 py-0.5 rounded-full border border-emerald-500/30">
                            Live Audit Formula
                          </span>
                        </div>

                        <div className="grid grid-cols-2 sm:grid-cols-6 gap-2 text-xs font-mono">
                          <div className="p-2.5 rounded-xl bg-black/40 border border-white/5 space-y-0.5">
                            <span className="text-[10px] text-slate-400">Gross Settled:</span>
                            <p className="font-bold text-white">${todayCalc.grossRevenueUsd.toFixed(2)}</p>
                          </div>

                          <div className="p-2.5 rounded-xl bg-black/40 border border-white/5 space-y-0.5 text-rose-300">
                            <span className="text-[10px] text-slate-400">- Gateway (2.5%):</span>
                            <p className="font-bold">-${todayCalc.gatewayFeesUsd.toFixed(2)}</p>
                          </div>

                          <div className="p-2.5 rounded-xl bg-black/40 border border-white/5 space-y-0.5 text-rose-300">
                            <span className="text-[10px] text-slate-400">- Opex (5.0%):</span>
                            <p className="font-bold">-${todayCalc.operatingExpensesUsd.toFixed(2)}</p>
                          </div>

                          <div className="p-2.5 rounded-xl bg-black/40 border border-white/5 space-y-0.5 text-rose-300">
                            <span className="text-[10px] text-slate-400">- Refunds (1.0%):</span>
                            <p className="font-bold">-${todayCalc.refundsReserveUsd.toFixed(2)}</p>
                          </div>

                          <div className="p-2.5 rounded-xl bg-emerald-950/40 border border-emerald-500/30 space-y-0.5 text-emerald-300">
                            <span className="text-[10px] text-emerald-400 font-bold">= Net Profit:</span>
                            <p className="font-bold">${todayCalc.netPlatformProfitUsd.toFixed(2)}</p>
                          </div>

                          <div className="p-2.5 rounded-xl bg-amber-500/20 border border-amber-500/40 space-y-0.5 text-amber-300">
                            <span className="text-[10px] text-amber-400 font-black">Founder 25%:</span>
                            <p className="font-black text-sm">Rs. {todayCalc.founder25SharePkr.toLocaleString()}</p>
                            <span className="text-[9px] text-slate-400">(${todayCalc.founder25ShareUsd.toFixed(2)})</span>
                          </div>
                        </div>

                        <p className="text-[10px] text-slate-400 leading-relaxed">
                          🛡️ <strong>Rule 9 Settlement Protection:</strong> Money is never transferred until it is fully received and settled in the platform account. Unsettled reserves and pending chargebacks remain excluded.
                        </p>
                      </div>
                    );
                  })()}
                </div>
              )}

              {/* TAB 3: Live Gifting Split */}
              {revenueTab === 'gifts' && (
                <div className="space-y-2">
                  <div className="space-y-2 max-h-56 overflow-y-auto pr-1">
                    {liveGiftingHistory.map((tx) => (
                      <div
                        key={tx.id}
                        className="p-3 rounded-2xl bg-black/40 border border-white/10 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs"
                      >
                        <div className="flex items-center gap-2">
                          <span className="text-2xl">{tx.gift.icon}</span>
                          <div>
                            <div className="flex items-center gap-1.5 font-bold">
                              <span className="text-white">{tx.senderName}</span>
                              <span className="text-slate-400">gifted</span>
                              <span className="text-amber-400">{tx.gift.name}</span>
                              <span className="text-[10px] text-slate-400">(${tx.gift.costUsd.toFixed(2)})</span>
                            </div>
                            <p className="text-[10px] text-slate-400">
                              Host: <span className="text-blue-300 font-semibold">{tx.hostName}</span> •{' '}
                              {new Date(tx.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                            </p>
                          </div>
                        </div>

                        <div className="flex items-center gap-3 text-right">
                          <div className="px-2.5 py-1 rounded-xl bg-blue-500/10 border border-blue-500/30 text-[10px]">
                            <span className="text-slate-400">Creator 75%: </span>
                            <strong className="text-blue-300 font-bold">${tx.hostShare.toFixed(2)}</strong>
                          </div>
                          <div className="px-2.5 py-1 rounded-xl bg-amber-500/15 border border-amber-500/40 text-[10px]">
                            <span className="text-slate-400">Owner Intekhab 25%: </span>
                            <strong className="text-amber-300 font-black">${tx.ownerShare.toFixed(2)}</strong>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Modal for Withdrawal */}
            <FounderWithdrawalModal
              isOpen={isWithdrawModalOpen}
              onClose={() => setIsWithdrawModalOpen(false)}
              availableBalanceUsd={availableBalance}
              totalRevenueUsd={ownerPlatformRevenue}
              withdrawnTotalUsd={withdrawnBalance}
              onWithdraw={withdrawFounderRevenue}
              onAddDemoFunds={addOwnerCommission}
            />

            {/* Modal for Admin Picture Upload / Selection */}
            <AdminPictureModal
              isOpen={isAdminPicModalOpen}
              onClose={() => setIsAdminPicModalOpen(false)}
            />

            {/* Modal for Daily Settlement Receipt Statement */}
            <FounderDailySettlementModal
              settlement={selectedDailyReceipt}
              onClose={() => setSelectedDailyReceipt(null)}
            />

            {/* Modal for Auto Payout Settings */}
            <AutoPayoutSettingsModal
              isOpen={isAutoSettingsModalOpen}
              onClose={() => setIsAutoSettingsModalOpen(false)}
              config={autoPayoutConfig}
              onConfigUpdated={(cfg) => updateAutoPayoutSettings(cfg)}
            />

            {/* Modal for Saved Receipt View */}
            {selectedReceipt && (
              <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4">
                <div className="max-w-md w-full bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-4 shadow-2xl text-white relative">
                  <button
                    onClick={() => setSelectedReceipt(null)}
                    className="absolute top-4 right-4 p-2 rounded-full bg-slate-800 text-slate-400 hover:text-white"
                  >
                    ✕
                  </button>

                  <div className="text-center space-y-2">
                    <div
                      className={`w-12 h-12 rounded-full mx-auto flex items-center justify-center ${
                        selectedReceipt.method === 'jazzcash'
                          ? 'bg-rose-500/20 text-rose-400'
                          : 'bg-emerald-500/20 text-emerald-400'
                      }`}
                    >
                      <CheckCircle2 className="w-6 h-6" />
                    </div>
                    <h3 className="font-black text-lg text-white">Official Payout Voucher</h3>
                    <p className="text-xs text-slate-400">SocialOne Founder &amp; CEO Disbursal</p>
                  </div>

                  <div className="bg-black/50 p-4 rounded-2xl border border-white/10 space-y-2 text-xs">
                    <div className="flex justify-between py-1 border-b border-white/5">
                      <span className="text-slate-400">Method:</span>
                      <strong className="uppercase text-white">
                        {selectedReceipt.method === 'jazzcash' ? '🔴 JazzCash' : '🟢 EasyPaisa'}
                      </strong>
                    </div>
                    <div className="flex justify-between py-1 border-b border-white/5">
                      <span className="text-slate-400">Beneficiary:</span>
                      <strong className="text-white">{selectedReceipt.accountTitle}</strong>
                    </div>
                    <div className="flex justify-between py-1 border-b border-white/5">
                      <span className="text-slate-400">Account Number:</span>
                      <strong className="text-slate-200">{selectedReceipt.accountNumber}</strong>
                    </div>
                    <div className="flex justify-between py-1 border-b border-white/5">
                      <span className="text-slate-400">Amount Transferred:</span>
                      <strong className="text-emerald-400 text-sm">
                        Rs. {selectedReceipt.amountPkr.toLocaleString()} PKR (${selectedReceipt.amountUsd.toFixed(2)})
                      </strong>
                    </div>
                    <div className="flex justify-between py-1 border-b border-white/5">
                      <span className="text-slate-400">Transaction ID (TID):</span>
                      <span className="font-mono text-amber-300 font-bold">{selectedReceipt.transactionId}</span>
                    </div>
                    <div className="flex justify-between py-1">
                      <span className="text-slate-400">Status:</span>
                      <span className="text-emerald-400 font-bold">COMPLETED / DISBURSED</span>
                    </div>
                  </div>

                  <button
                    onClick={() => setSelectedReceipt(null)}
                    className="w-full py-2.5 rounded-2xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs cursor-pointer"
                  >
                    Done
                  </button>
                </div>
              </div>
            )}
          </div>
        );
      })()}

      {/* Content Moderation Queue */}
      <div
        className={`p-6 rounded-3xl border space-y-4 ${
          darkMode ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200 shadow-xs'
        }`}
      >
        <div className="flex items-center justify-between border-b border-slate-800/40 pb-3">
          <h3 className="font-bold text-base flex items-center gap-2">
            <AlertTriangle className="w-5 h-5 text-amber-500" />
            <span>Community Moderation Queue</span>
          </h3>
          <span className="text-xs text-slate-400">
            {reports.length} total flagged incident(s)
          </span>
        </div>

        {reports.length === 0 ? (
          <p className="text-xs text-slate-400 py-4 text-center">
            No active reports. Community is clean and healthy!
          </p>
        ) : (
          <div className="divide-y divide-slate-800/30">
            {reports.map((report) => (
              <div
                key={report.id}
                className="py-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4"
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase bg-rose-500/10 text-rose-400 border border-rose-500/20">
                      {report.targetType}
                    </span>
                    <span className="font-bold text-xs">{report.targetTitle || report.targetId}</span>
                    <span
                      className={`text-[10px] px-2 py-0.5 rounded-full font-semibold ${
                        report.status === 'pending'
                          ? 'bg-amber-500/10 text-amber-400'
                          : report.status === 'resolved'
                          ? 'bg-emerald-500/10 text-emerald-400'
                          : 'bg-slate-500/10 text-slate-400'
                      }`}
                    >
                      {report.status}
                    </span>
                  </div>
                  <p className="text-xs text-slate-300">
                    <strong>Reason:</strong> {report.reason}
                  </p>
                  <p className="text-[10px] text-slate-400">
                    Reported by {report.reporterEmail || 'Member'} •{' '}
                    {new Date(report.createdAt).toLocaleDateString()}
                  </p>
                </div>

                {report.status === 'pending' && (
                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      onClick={() =>
                        handleRemoveReportedItem(report.id, report.targetType, report.targetId)
                      }
                      className="px-3 py-1.5 rounded-xl text-xs font-bold bg-rose-600 hover:bg-rose-500 text-white flex items-center gap-1 cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>Remove Content</span>
                    </button>

                    <button
                      onClick={() => resolveReport(report.id, 'dismiss')}
                      className="px-3 py-1.5 rounded-xl text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-300 cursor-pointer"
                    >
                      Dismiss
                    </button>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Platform Announcements & Configuration */}
      <div
        className={`p-6 rounded-3xl border space-y-4 ${
          darkMode ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200 shadow-xs'
        }`}
      >
        <h3 className="font-bold text-base flex items-center gap-2">
          <Settings className="w-5 h-5 text-indigo-400" />
          <span>Platform Announcements & Global Settings</span>
        </h3>

        <form onSubmit={handleSaveAnnouncement} className="space-y-3">
          <label className="block text-xs text-slate-400 font-semibold">
            Global SocialOne Broadcast Banner
          </label>
          <div className="flex items-center gap-3">
            <input
              type="text"
              value={platformAnnouncement}
              onChange={(e) => setPlatformAnnouncement(e.target.value)}
              className={`flex-1 px-4 py-2.5 rounded-2xl text-xs border outline-none ${
                darkMode
                  ? 'bg-slate-800 border-slate-700 text-white'
                  : 'bg-slate-100 border-slate-300 text-slate-900'
              }`}
            />
            <button
              type="submit"
              className="px-5 py-2.5 rounded-2xl text-xs font-bold bg-blue-600 hover:bg-blue-500 text-white cursor-pointer shadow-sm"
            >
              Update Banner
            </button>
          </div>
          {isSavedAnnouncement && (
            <p className="text-xs text-emerald-400 flex items-center gap-1">
              <CheckCircle className="w-3.5 h-3.5" />
              <span>Broadcast announcement updated across all connected devices!</span>
            </p>
          )}
        </form>

        <div className="pt-4 border-t border-slate-800/40 flex items-center justify-between">
          <div>
            <p className="font-bold text-xs">System Maintenance Mode</p>
            <p className="text-[11px] text-slate-400">
              Temporarily restrict new registrations while keeping read access alive.
            </p>
          </div>
          <button
            onClick={() => setMaintenanceMode(!maintenanceMode)}
            className={`px-4 py-2 rounded-xl text-xs font-bold cursor-pointer transition-colors ${
              maintenanceMode
                ? 'bg-amber-600 text-white'
                : 'bg-slate-800 text-slate-400 hover:text-white'
            }`}
          >
            {maintenanceMode ? 'Enabled' : 'Disabled'}
          </button>
        </div>
      </div>
    </div>
  );
};
