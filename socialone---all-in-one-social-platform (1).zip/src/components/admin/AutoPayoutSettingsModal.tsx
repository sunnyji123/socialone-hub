import React, { useState } from 'react';
import {
  FounderAutoPayoutConfig,
  updateAutoPayoutConfig,
} from '../../lib/jazzcashPayoutService';
import {
  X,
  ShieldCheck,
  Smartphone,
  Lock,
  Save,
  Clock,
  Percent,
  CheckCircle2,
  AlertCircle,
  Building2,
  Sliders,
} from 'lucide-react';

interface AutoPayoutSettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  config: FounderAutoPayoutConfig;
  onConfigUpdated: (config: FounderAutoPayoutConfig) => void;
}

export const AutoPayoutSettingsModal: React.FC<AutoPayoutSettingsModalProps> = ({
  isOpen,
  onClose,
  config,
  onConfigUpdated,
}) => {
  const [enabled, setEnabled] = useState(config.enabled);
  const [jazzCashNumber, setJazzCashNumber] = useState(config.jazzCashNumber);
  const [cnic, setCnic] = useState(config.cnic);
  const [payoutTimePkt, setPayoutTimePkt] = useState(config.payoutTimePkt || '20:00');
  const [merchantApiMode, setMerchantApiMode] = useState<'live' | 'sandbox'>(config.merchantApiMode);
  const [merchantId, setMerchantId] = useState(config.merchantId);
  const [operatingExpensePercent, setOperatingExpensePercent] = useState(
    config.operatingExpensePercent.toString()
  );
  const [gatewayFeePercent, setGatewayFeePercent] = useState(
    config.paymentGatewayFeePercent.toString()
  );
  const [refundReservePercent, setRefundReservePercent] = useState(
    config.refundReservePercent.toString()
  );

  // Security Gate: Protect with Owner PIN
  const [ownerPin, setOwnerPin] = useState('');
  const [pinError, setPinError] = useState<string | null>(null);
  const [saveSuccess, setSaveSuccess] = useState(false);

  if (!isOpen) return null;

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    setPinError(null);

    // Rule 10 & 11: Only Intekhab Alam can change payout destination or disable payouts
    // Verify PIN 03701220965
    if (ownerPin.trim() !== '03701220965') {
      setPinError('Security PIN incorrect. Only Founder Intekhab Alam can modify automatic payout rules.');
      return;
    }

    const res = updateAutoPayoutConfig(
      {
        enabled,
        jazzCashNumber: jazzCashNumber.trim(),
        cnic: cnic.trim(),
        payoutTimePkt,
        merchantApiMode,
        merchantId: merchantId.trim(),
        operatingExpensePercent: parseFloat(operatingExpensePercent) || 5.0,
        paymentGatewayFeePercent: parseFloat(gatewayFeePercent) || 2.5,
        refundReservePercent: parseFloat(refundReservePercent) || 1.0,
      },
      'gulamaftab74@gmail.com'
    );

    if (res.success) {
      onConfigUpdated(res.config);
      setSaveSuccess(true);
      setTimeout(() => {
        setSaveSuccess(false);
        onClose();
      }, 1200);
    } else {
      setPinError(res.error || 'Failed to save settings');
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4">
      <div className="max-w-lg w-full rounded-3xl bg-slate-900 border border-amber-500/40 text-white shadow-2xl p-6 sm:p-7 space-y-5 max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-white/10">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-amber-500/20 text-amber-400 flex items-center justify-center border border-amber-500/30">
              <Sliders className="w-5 h-5" />
            </div>
            <div>
              <span className="text-[10px] font-black uppercase tracking-wider text-amber-400">
                Founder Security Controls
              </span>
              <h3 className="text-base font-black text-white">Automatic Payout Settings</h3>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-slate-400 hover:text-white cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Notice on Rule 11 */}
        <div className="p-3.5 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs flex items-start gap-2.5">
          <ShieldCheck className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
          <p className="leading-relaxed">
            <strong>Owner Authority Policy:</strong> Only Founder &amp; CEO <strong>Intekhab Alam</strong> is authorized to adjust destination numbers, disbursement gateway credentials, or profit sharing rules.
          </p>
        </div>

        {pinError && (
          <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-400 text-xs font-semibold">
            {pinError}
          </div>
        )}

        <form onSubmit={handleSave} className="space-y-4 text-xs">
          {/* Toggle Enable / Disable */}
          <div className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800 flex items-center justify-between">
            <div>
              <p className="font-bold text-white text-sm">Automatic 8:00 PM PKT Payouts</p>
              <p className="text-[11px] text-slate-400">
                Disburse 25% daily net profit automatically without manual approval
              </p>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={enabled}
                onChange={(e) => setEnabled(e.target.checked)}
                className="sr-only peer"
              />
              <div className="w-11 h-6 bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-emerald-600"></div>
            </label>
          </div>

          {/* Registered JazzCash Destination */}
          <div className="space-y-1">
            <label className="block text-slate-300 font-bold">
              Registered JazzCash Mobile Number:
            </label>
            <div className="relative">
              <Smartphone className="w-4 h-4 absolute left-3.5 top-3 text-slate-400" />
              <input
                type="text"
                required
                value={jazzCashNumber}
                onChange={(e) => setJazzCashNumber(e.target.value)}
                placeholder="03701220965"
                className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white font-mono text-xs outline-none focus:border-amber-400"
              />
            </div>
          </div>

          {/* CNIC */}
          <div className="space-y-1">
            <label className="block text-slate-300 font-bold">Founder Verified CNIC:</label>
            <input
              type="text"
              required
              value={cnic}
              onChange={(e) => setCnic(e.target.value)}
              placeholder="42101-9876543-1"
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white font-mono text-xs outline-none focus:border-amber-400"
            />
          </div>

          {/* Daily Schedule Time */}
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1">
              <label className="block text-slate-300 font-bold">Daily Payout Time (PKT):</label>
              <div className="relative">
                <Clock className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
                <input
                  type="text"
                  value={payoutTimePkt}
                  onChange={(e) => setPayoutTimePkt(e.target.value)}
                  placeholder="20:00 (8:00 PM)"
                  className="w-full pl-9 pr-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white font-mono text-xs outline-none focus:border-amber-400"
                />
              </div>
            </div>

            <div className="space-y-1">
              <label className="block text-slate-300 font-bold">Merchant Gateway Mode:</label>
              <select
                value={merchantApiMode}
                onChange={(e) => setMerchantApiMode(e.target.value as any)}
                className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white font-semibold text-xs outline-none focus:border-amber-400 cursor-pointer"
              >
                <option value="live">Live Corporate Merchant</option>
                <option value="sandbox">Sandbox Testing Mode</option>
              </select>
            </div>
          </div>

          {/* Deductions & Opex Formulas (Rule 1) */}
          <div className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
            <p className="font-bold text-slate-300 text-[11px] uppercase tracking-wider">
              Net Profit Deduction Rates (Rule 1):
            </p>
            <div className="grid grid-cols-3 gap-2">
              <div>
                <label className="block text-[10px] text-slate-400">Gateway Fee:</label>
                <div className="flex items-center gap-1 mt-0.5">
                  <input
                    type="number"
                    step="0.1"
                    value={gatewayFeePercent}
                    onChange={(e) => setGatewayFeePercent(e.target.value)}
                    className="w-full px-2 py-1.5 rounded-lg bg-slate-800 border border-slate-700 text-white font-mono text-xs outline-none focus:border-amber-400"
                  />
                  <span className="text-[10px] text-slate-400">%</span>
                </div>
              </div>

              <div>
                <label className="block text-[10px] text-slate-400">Opex / CDN:</label>
                <div className="flex items-center gap-1 mt-0.5">
                  <input
                    type="number"
                    step="0.1"
                    value={operatingExpensePercent}
                    onChange={(e) => setOperatingExpensePercent(e.target.value)}
                    className="w-full px-2 py-1.5 rounded-lg bg-slate-800 border border-slate-700 text-white font-mono text-xs outline-none focus:border-amber-400"
                  />
                  <span className="text-[10px] text-slate-400">%</span>
                </div>
              </div>

              <div>
                <label className="block text-[10px] text-slate-400">Refund Reserve:</label>
                <div className="flex items-center gap-1 mt-0.5">
                  <input
                    type="number"
                    step="0.1"
                    value={refundReservePercent}
                    onChange={(e) => setRefundReservePercent(e.target.value)}
                    className="w-full px-2 py-1.5 rounded-lg bg-slate-800 border border-slate-700 text-white font-mono text-xs outline-none focus:border-amber-400"
                  />
                  <span className="text-[10px] text-slate-400">%</span>
                </div>
              </div>
            </div>
          </div>

          {/* Owner Verification PIN Gate */}
          <div className="p-3.5 rounded-2xl bg-amber-950/40 border border-amber-500/40 space-y-1.5">
            <label className="block text-amber-300 font-bold flex items-center gap-1.5">
              <Lock className="w-3.5 h-3.5" />
              <span>Enter Founder Security PIN to Confirm Changes:</span>
            </label>
            <input
              type="password"
              required
              value={ownerPin}
              onChange={(e) => setOwnerPin(e.target.value)}
              placeholder="••••••••••••"
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-amber-500/50 text-white font-mono text-xs outline-none focus:border-amber-400 tracking-wider"
            />
            <p className="text-[10px] text-slate-400">
              Only authorized Founder credentials can commit changes to the automatic payout system.
            </p>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center gap-3 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 py-2.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs cursor-pointer"
            >
              Cancel
            </button>

            <button
              type="submit"
              className="flex-[2] py-2.5 px-4 rounded-xl bg-gradient-to-r from-amber-500 to-rose-600 hover:opacity-95 text-white font-black text-xs shadow-xl cursor-pointer flex items-center justify-center gap-1.5 active:scale-98 transition-all"
            >
              {saveSuccess ? (
                <>
                  <CheckCircle2 className="w-4 h-4 text-emerald-300" />
                  <span>Settings Saved Successfully!</span>
                </>
              ) : (
                <>
                  <Save className="w-4 h-4" />
                  <span>Authorize &amp; Save Settings</span>
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
