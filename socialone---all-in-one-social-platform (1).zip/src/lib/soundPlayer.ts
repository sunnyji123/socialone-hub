/**
 * Web Audio Synthesizer & Soundtrack Engine for SocialOne TikTok Studio
 * Generates authentic rhythmic music (808 bass, punchy kicks, hi-hats, synth leads, arpeggios, chords)
 * so music actually plays aloud during recording, preview, and can be merged into recorded video streams!
 */

export interface SoundTrack {
  id: string;
  title: string;
  artist: string;
  category: 'trending' | 'desi' | 'lofi' | 'pop' | 'edm' | 'custom';
  bpm: number;
  durationSec: number;
  tags: string[];
  vibeColor: string;
  scale?: number[]; // Frequencies for melodic arpeggios
  bassNote?: number; // Base frequency in Hz
  customAudioUrl?: string; // For user uploaded MP3 from gallery / storage
}

export const SOUND_TRACKS: SoundTrack[] = [
  // Trending / Viral
  {
    id: 'sound-trending-1',
    title: 'Intekhab Drift Beat (Viral Phonk)',
    artist: 'Intekhab Sound Lab',
    category: 'trending',
    bpm: 132,
    durationSec: 30,
    tags: ['drift', 'phonk', 'viral', 'bass'],
    vibeColor: '#EC4899',
    scale: [220, 261.63, 293.66, 329.63, 392.0, 440],
    bassNote: 55, // A1
  },
  {
    id: 'sound-trending-2',
    title: 'SocialOne Anthem 2026',
    artist: 'Official SocialOne Records',
    category: 'trending',
    bpm: 126,
    durationSec: 25,
    tags: ['hype', 'foryou', 'trend', 'anthem'],
    vibeColor: '#8B5CF6',
    scale: [261.63, 293.66, 329.63, 392.0, 440.0, 523.25],
    bassNote: 65.41, // C2
  },
  {
    id: 'sound-trending-3',
    title: 'Aesthetic Slowed + Reverb',
    artist: 'NightDrive Audio',
    category: 'trending',
    bpm: 82,
    durationSec: 35,
    tags: ['slowed', 'reverb', 'aesthetic', 'sadlofi'],
    vibeColor: '#6366F1',
    scale: [196.0, 220.0, 246.94, 293.66, 329.63, 392.0],
    bassNote: 49.0, // G1
  },

  // Desi / Punjabi / Drill
  {
    id: 'sound-desi-1',
    title: 'Punjabi Dhol Drill Drop',
    artist: 'Lahore Bass Cartel',
    category: 'desi',
    bpm: 104,
    durationSec: 30,
    tags: ['punjabi', 'dhol', 'drill', 'karachi'],
    vibeColor: '#F59E0B',
    scale: [220, 246.94, 277.18, 329.63, 370.0, 440],
    bassNote: 55,
  },
  {
    id: 'sound-desi-2',
    title: 'Sufi Flute & Tabla Echo',
    artist: 'Indus Valley Beats',
    category: 'desi',
    bpm: 92,
    durationSec: 40,
    tags: ['sufi', 'tabla', 'flute', 'spiritual'],
    vibeColor: '#10B981',
    scale: [293.66, 329.63, 369.99, 440.0, 493.88, 587.33],
    bassNote: 73.42,
  },
  {
    id: 'sound-desi-3',
    title: 'Desi Trap Gaddi Groove',
    artist: 'Grand Trunk Audio',
    category: 'desi',
    bpm: 98,
    durationSec: 28,
    tags: ['desitrap', 'carvibe', 'punjabi', 'swag'],
    vibeColor: '#EF4444',
    scale: [207.65, 233.08, 261.63, 311.13, 349.23],
    bassNote: 51.91,
  },

  // Lo-Fi & Chill
  {
    id: 'sound-lofi-1',
    title: 'Karachi Chai Stall Lo-Fi',
    artist: 'Chai & Beats PK',
    category: 'lofi',
    bpm: 80,
    durationSec: 30,
    tags: ['chai', 'rain', 'relax', 'study'],
    vibeColor: '#3B82F6',
    scale: [261.63, 311.13, 349.23, 392.0, 466.16],
    bassNote: 65.41,
  },
  {
    id: 'sound-lofi-2',
    title: 'Sunset Rooftop Chills',
    artist: 'Mellow Clouds',
    category: 'lofi',
    bpm: 76,
    durationSec: 35,
    tags: ['sunset', 'lofi', 'chillhop', 'coffee'],
    vibeColor: '#F97316',
    scale: [220.0, 261.63, 293.66, 329.63, 392.0],
    bassNote: 55.0,
  },

  // Pop & Dance
  {
    id: 'sound-pop-1',
    title: 'Tokyo Cyber Pop Star',
    artist: 'Harajuku Collective',
    category: 'pop',
    bpm: 124,
    durationSec: 25,
    tags: ['pop', 'dance', 'catchy', 'kpopvibe'],
    vibeColor: '#EC4899',
    scale: [293.66, 329.63, 369.99, 440.0, 493.88, 587.33],
    bassNote: 73.42,
  },
  {
    id: 'sound-pop-2',
    title: 'Golden Sunset Disco Glam',
    artist: 'Studio 54 Revival',
    category: 'pop',
    bpm: 118,
    durationSec: 30,
    tags: ['disco', 'funk', 'groove', 'summer'],
    vibeColor: '#FBBF24',
    scale: [261.63, 293.66, 329.63, 392.0, 440.0],
    bassNote: 65.41,
  },

  // EDM & Trap 808
  {
    id: 'sound-edm-1',
    title: 'Stadium EDM Drop 2026',
    artist: 'Neon Galaxy',
    category: 'edm',
    bpm: 128,
    durationSec: 30,
    tags: ['edm', 'festival', 'rave', 'banger'],
    vibeColor: '#06B6D4',
    scale: [220.0, 261.63, 293.66, 329.63, 440.0],
    bassNote: 55.0,
  },
  {
    id: 'sound-edm-2',
    title: 'Heavy Trap 808 Sub-Glider',
    artist: 'Bassline Syndicate',
    category: 'edm',
    bpm: 140,
    durationSec: 25,
    tags: ['trap', '808', 'subbass', 'drill'],
    vibeColor: '#A855F7',
    scale: [196.0, 233.08, 261.63, 293.66, 392.0],
    bassNote: 49.0,
  },
];

class SoundEngine {
  private ctx: AudioContext | null = null;
  private masterGain: GainNode | null = null;
  private streamDestination: MediaStreamAudioDestinationNode | null = null;
  private isCurrentlyPlaying = false;
  private activeTrack: SoundTrack | null = null;
  private timerId: any = null;
  private step = 0;
  private volume = 0.8;
  private audioElement: HTMLAudioElement | null = null;
  private audioSourceNode: MediaElementAudioSourceNode | null = null;

  private initContext() {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioCtx) return;
      this.ctx = new AudioCtx();
      this.masterGain = this.ctx.createGain();
      this.masterGain.gain.setValueAtTime(this.volume, this.ctx.currentTime);

      // Connect to speakers
      this.masterGain.connect(this.ctx.destination);

      // Connect to media stream destination for mixing into MediaRecorder
      try {
        this.streamDestination = this.ctx.createMediaStreamDestination();
        this.masterGain.connect(this.streamDestination);
      } catch (err) {
        console.warn('MediaStreamDestination not supported:', err);
      }
    }

    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
  }

  public setVolume(vol: number) {
    this.volume = Math.max(0, Math.min(1, vol));
    if (this.masterGain && this.ctx) {
      this.masterGain.gain.setValueAtTime(this.volume, this.ctx.currentTime);
    }
    if (this.audioElement) {
      this.audioElement.volume = this.volume;
    }
  }

  public getVolume(): number {
    return this.volume;
  }

  public playTrack(track: SoundTrack) {
    this.stop();
    this.initContext();
    if (!this.ctx || !this.masterGain) return;

    this.activeTrack = track;
    this.isCurrentlyPlaying = true;

    // Handle user-uploaded MP3 from device gallery
    if (track.customAudioUrl) {
      try {
        const audio = new Audio(track.customAudioUrl);
        audio.loop = true;
        audio.volume = this.volume;
        this.audioElement = audio;

        try {
          const source = this.ctx.createMediaElementSource(audio);
          source.connect(this.masterGain);
          this.audioSourceNode = source;
        } catch {
          // If already connected or restricted
        }
        audio.play().catch(() => {});
      } catch (err) {
        console.warn('Audio playback error:', err);
      }
      return;
    }

    this.step = 0;
    const intervalMs = (60 / (track.bpm || 120) / 4) * 1000; // 16th notes

    this.timerId = setInterval(() => {
      this.tickStep(track);
    }, intervalMs);

    // Initial beat trigger
    this.tickStep(track);
  }

  private tickStep(track: SoundTrack) {
    if (!this.ctx || !this.masterGain || !this.isCurrentlyPlaying) return;
    const now = this.ctx.currentTime;
    const s = this.step % 16;
    this.step++;

    const bassFreq = track.bassNote ?? 55;
    const scale = track.scale && track.scale.length > 0 ? track.scale : [261.63, 293.66, 329.63, 392.0, 440.0];

    // 1. Kick Drum on beats 0, 4, 8, 12 (or drill syncopation)
    const isKick =
      track.category === 'edm'
        ? s % 4 === 0
        : s === 0 || s === 6 || s === 8 || s === 14;
    if (isKick) {
      this.playKick(now, bassFreq);
    }

    // 2. Snare / Clap on beats 4, 12
    if (s === 4 || s === 12) {
      this.playSnare(now);
    }

    // 3. Hi-Hat on every even 16th note, or rapid trap rolls
    if (s % 2 === 0 || (track.category === 'edm' && s >= 12)) {
      this.playHiHat(now, s % 4 === 2 ? 0.35 : 0.2);
    }

    // 4. Bassline
    if (s === 0 || s === 3 || s === 6 || s === 8 || s === 11) {
      this.playBass(now, bassFreq, s);
    }

    // 5. Melodic Synth / Arpeggio
    if (s % 2 === 0 || s % 3 === 0) {
      const noteIdx = (this.step + Math.floor(this.step / 8)) % scale.length;
      const freq = scale[noteIdx];
      this.playSynthNote(now, freq, track.category);
    }
  }

  private playKick(time: number, bassFreq: number) {
    if (!this.ctx || !this.masterGain) return;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(140, time);
    osc.frequency.exponentialRampToValueAtTime(bassFreq * 0.8, time + 0.08);

    gain.gain.setValueAtTime(0.8, time);
    gain.gain.exponentialRampToValueAtTime(0.001, time + 0.28);

    osc.connect(gain);
    gain.connect(this.masterGain);

    osc.start(time);
    osc.stop(time + 0.3);
  }

  private playSnare(time: number) {
    if (!this.ctx || !this.masterGain) return;

    // Noise buffer for snap
    const bufferSize = this.ctx.sampleRate * 0.15;
    const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      data[i] = (Math.random() * 2 - 1) * 0.5;
    }

    const noise = this.ctx.createBufferSource();
    noise.buffer = buffer;

    const noiseFilter = this.ctx.createBiquadFilter();
    noiseFilter.type = 'highpass';
    noiseFilter.frequency.setValueAtTime(1000, time);

    const noiseGain = this.ctx.createGain();
    noiseGain.gain.setValueAtTime(0.4, time);
    noiseGain.gain.exponentialRampToValueAtTime(0.01, time + 0.15);

    noise.connect(noiseFilter);
    noiseFilter.connect(noiseGain);
    noiseGain.connect(this.masterGain);

    noise.start(time);
    noise.stop(time + 0.16);

    // Tone body
    const osc = this.ctx.createOscillator();
    const toneGain = this.ctx.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(200, time);
    osc.frequency.exponentialRampToValueAtTime(90, time + 0.1);

    toneGain.gain.setValueAtTime(0.3, time);
    toneGain.gain.exponentialRampToValueAtTime(0.01, time + 0.1);

    osc.connect(toneGain);
    toneGain.connect(this.masterGain);

    osc.start(time);
    osc.stop(time + 0.12);
  }

  private playHiHat(time: number, vol = 0.2) {
    if (!this.ctx || !this.masterGain) return;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'square';
    osc.frequency.setValueAtTime(8000 + Math.random() * 2000, time);

    gain.gain.setValueAtTime(vol, time);
    gain.gain.exponentialRampToValueAtTime(0.001, time + 0.04);

    osc.connect(gain);
    gain.connect(this.masterGain);

    osc.start(time);
    osc.stop(time + 0.05);
  }

  private playBass(time: number, freq: number, step: number) {
    if (!this.ctx || !this.masterGain) return;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    // Modulate pitch slightly for drift feel
    const noteFreq = step % 4 === 3 ? freq * 1.33 : freq;
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(noteFreq, time);

    const filter = this.ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(320, time);

    gain.gain.setValueAtTime(0.45, time);
    gain.gain.exponentialRampToValueAtTime(0.01, time + 0.22);

    osc.connect(filter);
    filter.connect(gain);
    gain.connect(this.masterGain);

    osc.start(time);
    osc.stop(time + 0.24);
  }

  private playSynthNote(time: number, freq: number, category: string) {
    if (!this.ctx || !this.masterGain) return;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    if (category === 'lofi') {
      osc.type = 'sine';
    } else if (category === 'desi') {
      osc.type = 'triangle';
    } else {
      osc.type = 'square';
    }

    osc.frequency.setValueAtTime(freq, time);

    const filter = this.ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(category === 'lofi' ? 800 : 2400, time);

    gain.gain.setValueAtTime(0.18, time);
    gain.gain.exponentialRampToValueAtTime(0.001, time + 0.28);

    osc.connect(filter);
    filter.connect(gain);
    gain.connect(this.masterGain);

    osc.start(time);
    osc.stop(time + 0.3);
  }

  public stop() {
    this.isCurrentlyPlaying = false;
    if (this.timerId) {
      clearInterval(this.timerId);
      this.timerId = null;
    }
    if (this.audioElement) {
      try {
        this.audioElement.pause();
        this.audioElement.currentTime = 0;
      } catch {}
      this.audioElement = null;
    }
    if (this.audioSourceNode) {
      try {
        this.audioSourceNode.disconnect();
      } catch {}
      this.audioSourceNode = null;
    }
  }

  public isPlaying(): boolean {
    return this.isCurrentlyPlaying;
  }

  public getCurrentTrack(): SoundTrack | null {
    return this.activeTrack;
  }

  /**
   * Get an audio stream track that can be merged with camera video into MediaRecorder
   */
  public getAudioStreamTrack(): MediaStreamTrack | null {
    if (!this.streamDestination) {
      this.initContext();
    }
    if (this.streamDestination && this.streamDestination.stream) {
      return this.streamDestination.stream.getAudioTracks()[0] || null;
    }
    return null;
  }
}

// Global singleton so audio playback is shared across studio preview & recording
export const soundEngine = new SoundEngine();
