export type UserRole = 'user' | 'admin';

export interface UserPrivacySettings {
  isPrivateAccount: boolean;
  lastSeenVisibility: 'everyone' | 'contacts' | 'followers' | 'nobody';
  readReceipts: boolean; // WhatsApp blue ticks
  whoCanMessageMe: 'everyone' | 'followers' | 'nobody';
  whoCanComment: 'everyone' | 'followers' | 'nobody';
  allowVideoDownloads: boolean;
  showOnlineStatus: boolean;
  disappearingMessagesTimer: 'off' | '24h' | '7d' | '90d';
  blockedUserIds: string[];
}

export interface UserProfile {
  uid: string;
  displayName: string;
  email: string;
  phoneNumber?: string;
  photoURL: string;
  username: string;
  bio?: string;
  category?: string;
  role: UserRole;
  isSuspended?: boolean;
  followersCount: number;
  followingCount: number;
  followingIds?: string[];
  savedPostIds?: string[];
  walletBalance?: number;
  totalGiftsEarned?: number;
  coinsBalance?: number; // Sikka / Coins for buying and sending live gifts
  privacySettings?: UserPrivacySettings;
  createdAt: string;
  updatedAt?: string;
}

export interface Post {
  id: string;
  authorId: string;
  authorName: string;
  authorPhoto: string;
  authorUsername: string;
  content: string;
  mediaUrls: string[];
  mediaType: 'none' | 'image' | 'video';
  tags?: string[];
  likesCount: number;
  likedBy?: string[];
  commentsCount: number;
  sharesCount: number;
  groupId?: string;
  groupName?: string;
  createdAt: string;
  updatedAt?: string;
}

export interface PostComment {
  id: string;
  postId: string;
  authorId: string;
  authorName: string;
  authorPhoto: string;
  content: string;
  createdAt: string;
}

export interface ShortVideo {
  id: string;
  creatorId: string;
  creatorName: string;
  creatorPhoto: string;
  creatorUsername: string;
  videoUrl: string;
  caption: string;
  hashtags: string[];
  musicTitle: string;
  musicArtist: string;
  likesCount: number;
  likedBy?: string[];
  commentsCount: number;
  sharesCount: number;
  viewsCount: number;
  createdAt: string;
}

export interface Story {
  id: string;
  authorId: string;
  authorName: string;
  authorPhoto: string;
  mediaUrl: string;
  caption?: string;
  filter?: string;
  viewers?: string[];
  createdAt: string;
  expiresAt: string;
}

export interface Message {
  id: string;
  conversationId: string;
  senderId: string;
  senderName: string;
  senderPhoto: string;
  content: string;
  type: 'text' | 'image' | 'audio' | 'video';
  mediaUrl?: string;
  audioDuration?: number;
  readBy?: string[];
  createdAt: string;
}

export interface Conversation {
  id: string;
  type: 'direct' | 'group';
  name?: string;
  avatarUrl?: string;
  participantIds: string[];
  participantDetails: {
    [uid: string]: {
      displayName: string;
      photoURL: string;
      online?: boolean;
    };
  };
  lastMessage?: string;
  lastMessageTime?: string;
  unreadCount?: number;
}

export interface CallSession {
  id: string;
  callerId: string;
  callerName: string;
  callerPhoto: string;
  receiverId: string;
  receiverName: string;
  receiverPhoto: string;
  type: 'voice' | 'video';
  status: 'calling' | 'active' | 'ended' | 'declined' | 'missed' | 'completed';
  startTime?: string;
  duration?: number;
  createdAt: string;
}

export interface GroupCommunity {
  id: string;
  name: string;
  description: string;
  coverUrl: string;
  avatarUrl: string;
  isPrivate: boolean;
  creatorId: string;
  creatorName: string;
  membersCount: number;
  memberIds: string[];
  rules: string[];
  createdAt: string;
}

export interface NotificationItem {
  id: string;
  recipientId: string;
  senderId: string;
  senderName: string;
  senderPhoto: string;
  type: 'like' | 'comment' | 'follow' | 'friend_request' | 'message' | 'call';
  message: string;
  link?: string;
  isRead: boolean;
  createdAt: string;
}

export interface ReportItem {
  id: string;
  reporterId: string;
  reporterEmail?: string;
  targetType: 'post' | 'video' | 'user' | 'comment';
  targetId: string;
  targetTitle?: string;
  reason: string;
  status: 'pending' | 'resolved' | 'dismissed';
  createdAt: string;
}

export interface LiveGift {
  id: string;
  name: string;
  icon: string;
  coins: number;        // Coins / Sikka cost to send
  costUsd: number;
  creatorShare: number; // 75%
  ownerShare: number;   // 25% to Owner Intekhab Alam
  color: string;
  animationType?: 'shower' | 'zoom' | 'car' | 'lion' | 'galaxy' | 'crown';
}

export interface LiveComment {
  id: string;
  userId: string;
  userName: string;
  userPhoto: string;
  text: string;
  gift?: LiveGift;
  createdAt: string;
}

export interface LiveStreamSession {
  id: string;
  hostId: string;
  hostName: string;
  hostPhoto: string;
  hostUsername: string;
  title: string;
  streamUrl?: string;
  viewersCount: number;
  totalEarningsUsd: number;
  hostEarningsUsd: number;   // 75%
  ownerEarningsUsd: number;  // 25% Platform commission
  isActive: boolean;
  createdAt: string;
}

export type MainViewTab = 
  | 'home' 
  | 'videos' 
  | 'stories' 
  | 'messages' 
  | 'groups' 
  | 'explore' 
  | 'admin' 
  | 'profile';

export interface FounderWithdrawal {
  id: string;
  method: 'jazzcash' | 'easypaisa' | 'bank';
  accountTitle: string;
  accountNumber: string;
  cnic?: string;
  amountUsd: number;
  amountPkr: number;
  exchangeRate: number;
  feePkr: number;
  status: 'pending' | 'processing' | 'completed' | 'successful' | 'failed' | 'retrying';
  transactionId: string;
  timestamp: string;
  note?: string;
  isAutomated?: boolean;
  dailySettlementRef?: string;
  failureReason?: string;
}
export * from '../lib/jazzcashPayoutService';

