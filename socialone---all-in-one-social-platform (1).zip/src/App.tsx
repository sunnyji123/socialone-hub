import React from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { AppProvider, useApp } from './context/AppContext';
import { LoginView } from './components/auth/LoginView';
import { Navbar } from './components/layout/Navbar';
import { Sidebar } from './components/layout/Sidebar';
import { BottomNav } from './components/layout/BottomNav';
import { HomeFeed } from './components/feed/HomeFeed';
import { ShortsFeed } from './components/videos/ShortsFeed';
import { MessagesView } from './components/messages/MessagesView';
import { GroupsView } from './components/groups/GroupsView';
import { ExploreView } from './components/explore/ExploreView';
import { AdminPanel } from './components/admin/AdminPanel';
import { ProfileView } from './components/profile/ProfileView';
import { StoryViewerModal } from './components/stories/StoryViewerModal';
import { WebRTCCallModal } from './components/calls/WebRTCCallModal';
import { CreateContentModal } from './components/modals/CreateContentModal';
import { TikTokStudioModal } from './components/videos/TikTokStudioModal';
import { TikTokLiveModal } from './components/live/TikTokLiveModal';
import { CoinRechargeModal } from './components/modals/CoinRechargeModal';
import { TikTokIdModal } from './components/modals/TikTokIdModal';
import { CreatorCashoutModal } from './components/modals/CreatorCashoutModal';
import { PrivacySettingsModal } from './components/modals/PrivacySettingsModal';
import { Sparkles } from 'lucide-react';

const MainShell: React.FC = () => {
  const { currentUser, loading, darkMode } = useAuth();
  const {
    activeTab,
    isCoinStoreOpen,
    setIsCoinStoreOpen,
    isTikTokIdModalOpen,
    setIsTikTokIdModalOpen,
    isCreatorCashoutOpen,
    setIsCreatorCashoutOpen,
  } = useApp();

  // Loading Splash Screen
  if (loading) {
    return (
      <div className="min-h-screen bg-[#0B0F19] flex flex-col items-center justify-center text-white space-y-4">
        <div className="w-16 h-16 rounded-3xl bg-gradient-to-tr from-blue-600 via-indigo-600 to-teal-400 flex items-center justify-center shadow-2xl shadow-blue-500/30 animate-pulse">
          <span className="text-white font-black text-3xl tracking-tighter">S1</span>
        </div>
        <div className="text-center space-y-1">
          <h2 className="text-xl font-bold bg-gradient-to-r from-blue-400 to-teal-300 bg-clip-text text-transparent">
            SocialOne
          </h2>
          <p className="text-xs text-slate-400 font-medium">
            Intekhab Alam — Founder & CEO
          </p>
        </div>
      </div>
    );
  }

  // Mandatory Google Login Gate
  if (!currentUser) {
    return <LoginView />;
  }

  return (
    <div
      className={`min-h-screen flex flex-col font-sans transition-colors duration-200 ${
        darkMode ? 'bg-[#080C16] text-white' : 'bg-slate-50 text-slate-900'
      }`}
    >
      {/* Top Navbar */}
      <Navbar />

      {/* Main Layout Area */}
      <div className="flex-1 max-w-7xl mx-auto w-full flex">
        {/* Left Sidebar on desktop */}
        <Sidebar />

        {/* Dynamic Main Body Content */}
        <main className="flex-1 p-4 sm:p-6 overflow-x-hidden min-h-[calc(100vh-4rem)]">
          {activeTab === 'home' && <HomeFeed />}
          {activeTab === 'videos' && <ShortsFeed />}
          {activeTab === 'stories' && <HomeFeed />}
          {activeTab === 'messages' && <MessagesView />}
          {activeTab === 'groups' && <GroupsView />}
          {activeTab === 'explore' && <ExploreView />}
          {activeTab === 'admin' && <AdminPanel />}
          {activeTab === 'profile' && <ProfileView />}
        </main>
      </div>

      {/* Mobile Bottom Navigation */}
      <BottomNav />

      {/* Global Modals */}
      <StoryViewerModal />
      <WebRTCCallModal />
      <CreateContentModal />
      <TikTokStudioModal />
      <TikTokLiveModal />
      <CoinRechargeModal
        isOpen={isCoinStoreOpen}
        onClose={() => setIsCoinStoreOpen(false)}
      />
      <TikTokIdModal
        isOpen={isTikTokIdModalOpen}
        onClose={() => setIsTikTokIdModalOpen(false)}
      />
      <CreatorCashoutModal
        isOpen={isCreatorCashoutOpen}
        onClose={() => setIsCreatorCashoutOpen(false)}
      />
      <PrivacySettingsModal />
    </div>
  );
};

export default function App() {
  return (
    <AuthProvider>
      <AppProvider>
        <MainShell />
      </AppProvider>
    </AuthProvider>
  );
}
