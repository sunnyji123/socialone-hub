import React, { createContext, useContext, useEffect, useState } from 'react';
import { User, onAuthStateChanged } from 'firebase/auth';
import { doc, getDoc, setDoc, updateDoc } from 'firebase/firestore';
import { auth, db, googleProvider, signInWithPopup, signOut } from '../lib/firebase';
import { handleFirestoreError, OperationType } from '../lib/error-handler';
import { UserProfile, UserPrivacySettings } from '../types';

export const DEFAULT_USER_PRIVACY: UserPrivacySettings = {
  isPrivateAccount: false,
  lastSeenVisibility: 'everyone',
  readReceipts: true,
  whoCanMessageMe: 'everyone',
  whoCanComment: 'everyone',
  allowVideoDownloads: true,
  showOnlineStatus: true,
  disappearingMessagesTimer: 'off',
  blockedUserIds: [],
};

interface AuthContextType {
  currentUser: User | null;
  userProfile: UserProfile | null;
  loading: boolean;
  isAdmin: boolean;
  darkMode: boolean;
  toggleDarkMode: () => void;
  loginWithGoogle: () => Promise<void>;
  logout: () => Promise<void>;
  updateProfileDetails: (details: Partial<UserProfile>) => Promise<void>;
  updatePrivacySettings: (settings: Partial<UserPrivacySettings>) => Promise<void>;
  loginWithPhoneOTP: (params: {
    phoneNumber: string;
    code: string;
    displayName: string;
    username: string;
    photoURL?: string;
  }) => Promise<boolean>;
  toggleFollowUser: (targetUserId: string) => Promise<void>;
  toggleSavePost: (postId: string) => Promise<void>;
  gainFollowers: (amount?: number) => Promise<void>;
  addEarningsToWallet: (amount: number) => Promise<void>;
  loginAsFounder: () => Promise<void>;
  loginAsDemoUser: () => Promise<void>;
  addCoins: (amount: number) => Promise<void>;
  deductCoins: (amount: number) => Promise<boolean>;
  createTikTokId: (data: {
    displayName: string;
    username: string;
    bio: string;
    category: string;
    photoURL: string;
    phoneNumber?: string;
    age?: number;
  }) => Promise<void>;
  withdrawCreatorEarnings: (params: {
    method: 'jazzcash' | 'easypaisa' | 'bank';
    accountTitle: string;
    accountNumber: string;
    amountUsd: number;
    cnic?: string;
  }) => Promise<{ success: boolean; transaction: any }>;
  loginWithAdminCredentials: (email: string, pass: string) => Promise<boolean>;
  updateAdminPicture: (photoURL: string) => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const ADMIN_BOOTSTRAP_EMAILS = [
  'gulamaftab74@gmail.com',
  'sunnyjiansari456@gmail.com',
  'intekhab@socialone.app',
  'intekhab@socialone.pk',
];

export const OFFICIAL_FOUNDER_PHOTO = '/assets/aistudio/file_00000000a0a08208a8c468d7ead758ff_e2572f23.png';

const getInitialFounderPhoto = () => {
  if (typeof window === 'undefined') return OFFICIAL_FOUNDER_PHOTO;
  const stored = localStorage.getItem('socialone_founder_photo');
  // If stored is an old placeholder from unsplash, discard and use official photo
  if (!stored || stored.includes('unsplash.com')) {
    localStorage.setItem('socialone_founder_photo', OFFICIAL_FOUNDER_PHOTO);
    return OFFICIAL_FOUNDER_PHOTO;
  }
  return stored;
};

const FOUNDER_EXECUTIVE_PHOTO = getInitialFounderPhoto();

const DEFAULT_FOUNDER_USER = {
  uid: 'intekhab-alam-founder',
  email: 'sunnyjiansari456@gmail.com',
  displayName: 'Intekhab Alam',
  photoURL: FOUNDER_EXECUTIVE_PHOTO,
} as User;

const DEFAULT_FOUNDER_PROFILE: UserProfile = {
  uid: 'intekhab-alam-founder',
  displayName: 'Intekhab Alam (Founder & CEO)',
  email: 'sunnyjiansari456@gmail.com',
  photoURL: FOUNDER_EXECUTIVE_PHOTO,
  username: 'intekhab_founder',
  bio: 'Founder & CEO of SocialOne 🚀 Building the ultimate all-in-one social platform. JazzCash & EasyPaisa automated treasury enabled.',
  category: 'Tech & Innovation',
  role: 'admin',
  followersCount: 14200,
  followingCount: 312,
  followingIds: ['user-elena-vance', 'user-marcus-chen'],
  savedPostIds: [],
  walletBalance: 125.0,
  totalGiftsEarned: 160.0,
  coinsBalance: 2500, // 2,500 Coins for testing live gifts
  createdAt: new Date().toISOString(),
};

const DEFAULT_DEMO_USER = {
  uid: 'user-demo-creator',
  email: 'creator@socialone.app',
  displayName: 'Ali Raza Creator',
  photoURL: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=400&auto=format&fit=crop&q=80',
} as User;

const DEFAULT_DEMO_PROFILE: UserProfile = {
  uid: 'user-demo-creator',
  displayName: 'Ali Raza',
  email: 'creator@socialone.app',
  photoURL: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=400&auto=format&fit=crop&q=80',
  username: 'aliraza_pk',
  bio: 'Digital Creator & Video Editor in Karachi 🇵🇰 Loving SocialOne!',
  category: 'Comedy & Entertainment',
  role: 'user',
  followersCount: 120,
  followingCount: 45,
  followingIds: ['intekhab-alam-founder'],
  savedPostIds: [],
  walletBalance: 45.0,
  totalGiftsEarned: 60.0,
  coinsBalance: 500, // 500 Coins
  createdAt: new Date().toISOString(),
};

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<User | null>(() => {
    const saved = localStorage.getItem('socialone_session_type');
    if (saved === 'demo') return DEFAULT_DEMO_USER;
    // Default to Founder Intekhab Alam so owner never gets blocked by popups
    return DEFAULT_FOUNDER_USER;
  });
  const [userProfile, setUserProfile] = useState<UserProfile | null>(() => {
    const saved = localStorage.getItem('socialone_session_type');
    if (saved === 'demo') return DEFAULT_DEMO_PROFILE;
    return DEFAULT_FOUNDER_PROFILE;
  });
  const [loading, setLoading] = useState(false);
  const [darkMode, setDarkMode] = useState<boolean>(() => {
    return localStorage.getItem('socialone_theme') !== 'light';
  });

  const toggleDarkMode = () => {
    setDarkMode((prev) => {
      const next = !prev;
      localStorage.setItem('socialone_theme', next ? 'dark' : 'light');
      if (next) {
        document.documentElement.classList.add('dark');
      } else {
        document.documentElement.classList.remove('dark');
      }
      return next;
    });
  };

  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [darkMode]);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      if (firebaseUser) {
        setCurrentUser(firebaseUser);
        localStorage.setItem('socialone_session_type', 'google');
        await syncUserProfile(firebaseUser);
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const syncUserProfile = async (user: User) => {
    const userDocRef = doc(db, 'users', user.uid);
    try {
      const docSnap = await getDoc(userDocRef);
      const isConfiguredAdmin =
        Boolean(user.email && ADMIN_BOOTSTRAP_EMAILS.includes(user.email.toLowerCase()));

      if (docSnap.exists()) {
        const data = docSnap.data() as UserProfile;
        // Ensure admin status if email matches bootstrap
        if (isConfiguredAdmin && data.role !== 'admin') {
          await updateDoc(userDocRef, { role: 'admin' });
          data.role = 'admin';
        }
        setUserProfile(data);
      } else {
        // Generate friendly username from email or displayName
        const baseName =
          user.displayName?.toLowerCase().replace(/[^a-z0-9]/g, '') ||
          user.email?.split('@')[0].replace(/[^a-z0-9]/g, '') ||
          'user';
        const generatedUsername = `${baseName}_${Math.floor(100 + Math.random() * 900)}`;

        const newProfile: UserProfile = {
          uid: user.uid,
          displayName: user.displayName || 'SocialOne Member',
          email: user.email || '',
          photoURL:
            user.photoURL ||
            `https://api.dicebear.com/7.x/initials/svg?seed=${encodeURIComponent(
              user.displayName || 'User'
            )}`,
          username: generatedUsername,
          bio: 'Exploring the SocialOne all-in-one experience ✨',
          role: isConfiguredAdmin ? 'admin' : 'user',
          followersCount: 1,
          followingCount: 1,
          followingIds: ['intekhab-alam-founder'],
          savedPostIds: [],
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        };

        await setDoc(userDocRef, newProfile);
        setUserProfile(newProfile);
      }
    } catch (error) {
      // In case of any Firestore rule delay or temporary failure, provide offline fallback profile
      console.warn('Profile fetch note: using local session fallback.', error);
      const isConfiguredAdmin =
        Boolean(user.email && ADMIN_BOOTSTRAP_EMAILS.includes(user.email.toLowerCase()));
      setUserProfile({
        uid: user.uid,
        displayName: user.displayName || 'SocialOne Member',
        email: user.email || '',
        photoURL: user.photoURL || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&auto=format&fit=crop&q=80',
        username: user.email?.split('@')[0] || 'member',
        bio: 'Exploring the SocialOne all-in-one experience ✨',
        role: isConfiguredAdmin ? 'admin' : 'user',
        followersCount: 1,
        followingCount: 1,
        followingIds: ['intekhab-alam-founder'],
        savedPostIds: [],
        createdAt: new Date().toISOString(),
      });
    }
  };

  const loginWithGoogle = async () => {
    try {
      await signInWithPopup(auth, googleProvider);
    } catch (err: unknown) {
      const errorMsg = err instanceof Error ? err.message : String(err);
      console.error('Google Sign-In Error:', errorMsg);
      throw err;
    }
  };

  const loginAsFounder = async () => {
    setCurrentUser(DEFAULT_FOUNDER_USER);
    setUserProfile(DEFAULT_FOUNDER_PROFILE);
    localStorage.setItem('socialone_session_type', 'founder');
  };

  const loginWithAdminCredentials = async (email: string, pass: string): Promise<boolean> => {
    const cleanEmail = email.trim().toLowerCase();
    const cleanPass = pass.trim();
    if (
      (cleanEmail === 'gulamaftab74@gmail.com' ||
        cleanEmail === 'sunnyjiansari456@gmail.com' ||
        cleanEmail === 'admin') &&
      cleanPass === '03701220965'
    ) {
      const currentFounderPhoto =
        localStorage.getItem('socialone_founder_photo') || FOUNDER_EXECUTIVE_PHOTO;
      const adminUser = {
        uid: 'admin-gulamaftab',
        email: cleanEmail === 'admin' ? 'gulamaftab74@gmail.com' : cleanEmail,
        displayName: 'Intekhab Alam (Founder & CEO)',
        photoURL: currentFounderPhoto,
      } as User;

      const adminProfile: UserProfile = {
        ...DEFAULT_FOUNDER_PROFILE,
        uid: 'admin-gulamaftab',
        email: adminUser.email || 'gulamaftab74@gmail.com',
        photoURL: currentFounderPhoto,
        role: 'admin',
      };

      setCurrentUser(adminUser);
      setUserProfile(adminProfile);
      localStorage.setItem('socialone_session_type', 'admin_verified');
      localStorage.setItem('socialone_admin_pin_verified', 'true');
      return true;
    }
    return false;
  };

  const loginAsDemoUser = async () => {
    setCurrentUser(DEFAULT_DEMO_USER);
    setUserProfile(DEFAULT_DEMO_PROFILE);
    localStorage.setItem('socialone_session_type', 'demo');
  };

  const logout = async () => {
    try {
      await signOut(auth);
    } catch {}
    localStorage.removeItem('socialone_session_type');
    setCurrentUser(null);
    setUserProfile(null);
  };

  const updateProfileDetails = async (details: Partial<UserProfile>) => {
    if (!currentUser || !userProfile) return;
    const userDocRef = doc(db, 'users', currentUser.uid);
    try {
      await updateDoc(userDocRef, {
        ...details,
        updatedAt: new Date().toISOString(),
      });
      setUserProfile((prev) => (prev ? { ...prev, ...details } : null));
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `users/${currentUser.uid}`);
    }
  };

  const toggleFollowUser = async (targetUserId: string) => {
    if (!currentUser || !userProfile) return;
    const currentFollowing = userProfile.followingIds || [];
    const isFollowing = currentFollowing.includes(targetUserId);
    const updatedFollowing = isFollowing
      ? currentFollowing.filter((id) => id !== targetUserId)
      : [...currentFollowing, targetUserId];

    const updatedProfile = {
      ...userProfile,
      followingIds: updatedFollowing,
      followingCount: Math.max(0, updatedFollowing.length),
    };
    setUserProfile(updatedProfile);

    try {
      const userDocRef = doc(db, 'users', currentUser.uid);
      await updateDoc(userDocRef, {
        followingIds: updatedFollowing,
        followingCount: updatedProfile.followingCount,
      });
    } catch {
      // optimistic update retained
    }
  };

  const toggleSavePost = async (postId: string) => {
    if (!currentUser || !userProfile) return;
    const saved = userProfile.savedPostIds || [];
    const isSaved = saved.includes(postId);
    const updatedSaved = isSaved ? saved.filter((id) => id !== postId) : [...saved, postId];

    setUserProfile((prev) => (prev ? { ...prev, savedPostIds: updatedSaved } : null));
    try {
      const userDocRef = doc(db, 'users', currentUser.uid);
      await updateDoc(userDocRef, {
        savedPostIds: updatedSaved,
      });
    } catch {
      // optimistic
    }
  };

  const gainFollowers = async (amount: number = 25) => {
    if (!currentUser || !userProfile) return;
    const newFollowers = (userProfile.followersCount || 0) + amount;
    const updated = {
      ...userProfile,
      followersCount: newFollowers,
    };
    setUserProfile(updated);
    try {
      const userDocRef = doc(db, 'users', currentUser.uid);
      await updateDoc(userDocRef, {
        followersCount: newFollowers,
        updatedAt: new Date().toISOString(),
      });
    } catch {
      // optimistic update maintained
    }
  };

  const addEarningsToWallet = async (amount: number) => {
    if (!currentUser || !userProfile) return;
    const currentBalance = userProfile.walletBalance || 0;
    const currentTotal = userProfile.totalGiftsEarned || 0;
    const newBalance = Number((currentBalance + amount).toFixed(2));
    const newTotal = Number((currentTotal + amount).toFixed(2));
    const updated = {
      ...userProfile,
      walletBalance: newBalance,
      totalGiftsEarned: newTotal,
    };
    setUserProfile(updated);
    try {
      const userDocRef = doc(db, 'users', currentUser.uid);
      await updateDoc(userDocRef, {
        walletBalance: newBalance,
        totalGiftsEarned: newTotal,
        updatedAt: new Date().toISOString(),
      });
    } catch {
      // optimistic
    }
  };

  const addCoins = async (amount: number) => {
    if (!userProfile) return;
    const current = userProfile.coinsBalance || 0;
    const updatedBalance = current + amount;
    const updated = {
      ...userProfile,
      coinsBalance: updatedBalance,
    };
    setUserProfile(updated);
    if (currentUser) {
      try {
        const userDocRef = doc(db, 'users', currentUser.uid);
        await updateDoc(userDocRef, {
          coinsBalance: updatedBalance,
          updatedAt: new Date().toISOString(),
        });
      } catch {}
    }
  };

  const deductCoins = async (amount: number): Promise<boolean> => {
    if (!userProfile) return false;
    const current = userProfile.coinsBalance || 0;
    if (current < amount) return false;

    const updatedBalance = current - amount;
    const updated = {
      ...userProfile,
      coinsBalance: updatedBalance,
    };
    setUserProfile(updated);
    if (currentUser) {
      try {
        const userDocRef = doc(db, 'users', currentUser.uid);
        await updateDoc(userDocRef, {
          coinsBalance: updatedBalance,
          updatedAt: new Date().toISOString(),
        });
      } catch {}
    }
    return true;
  };

  const createTikTokId = async (data: {
    displayName: string;
    username: string;
    bio: string;
    category: string;
    photoURL: string;
    phoneNumber?: string;
    age?: number;
  }) => {
    const cleanHandle = data.username.toLowerCase().replace(/[^a-z0-9_.]/g, '');
    const uid = `user-tiktok-${Date.now()}`;
    const newProfile: UserProfile = {
      uid,
      displayName: data.displayName || 'TikTok Creator',
      email: `${cleanHandle}@tiktok.socialone.app`,
      phoneNumber: data.phoneNumber,
      photoURL:
        data.photoURL ||
        'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&auto=format&fit=crop&q=80',
      username: cleanHandle,
      bio: data.bio || `TikTok Creator | ${data.category} 🔥 #socialone #foryou`,
      category: data.category || 'General Entertainment',
      role: 'user',
      followersCount: 150, // bonus 150 followers so user is immediately eligible for TikTok Live!
      followingCount: 12,
      followingIds: ['intekhab-alam-founder'],
      savedPostIds: [],
      walletBalance: 25.0, // bonus starting earnings
      totalGiftsEarned: 25.0,
      coinsBalance: 500, // bonus 500 Coins for live stream gifting!
      privacySettings: DEFAULT_USER_PRIVACY,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    const dummyUser = {
      uid,
      displayName: data.displayName,
      email: newProfile.email,
      phoneNumber: data.phoneNumber,
      photoURL: newProfile.photoURL,
    } as User;

    setCurrentUser(dummyUser);
    setUserProfile(newProfile);
    localStorage.setItem('socialone_session_type', 'tiktok_custom');
    localStorage.setItem('socialone_tiktok_profile', JSON.stringify(newProfile));

    try {
      await setDoc(doc(db, 'users', uid), newProfile);
    } catch {}
  };

  const updatePrivacySettings = async (settings: Partial<UserPrivacySettings>) => {
    if (!userProfile) return;
    const current = userProfile.privacySettings || DEFAULT_USER_PRIVACY;
    const updatedPrivacy = { ...current, ...settings };
    const updated = {
      ...userProfile,
      privacySettings: updatedPrivacy,
    };
    setUserProfile(updated);
    if (currentUser) {
      try {
        const userDocRef = doc(db, 'users', currentUser.uid);
        await updateDoc(userDocRef, {
          privacySettings: updatedPrivacy,
          updatedAt: new Date().toISOString(),
        });
      } catch {}
    }
  };

  const loginWithPhoneOTP = async (params: {
    phoneNumber: string;
    code: string;
    displayName: string;
    username: string;
    photoURL?: string;
  }): Promise<boolean> => {
    const cleanPhone = params.phoneNumber.replace(/[^0-9+]/g, '');
    const cleanHandle = (params.username || `user_${cleanPhone.slice(-4)}`).toLowerCase().replace(/[^a-z0-9_.]/g, '');
    const uid = `user-phone-${cleanPhone.replace(/[^0-9]/g, '') || Date.now()}`;

    const newProfile: UserProfile = {
      uid,
      displayName: params.displayName || `Member ${cleanPhone.slice(-4)}`,
      email: `${cleanHandle}@socialone.app`,
      phoneNumber: cleanPhone,
      photoURL:
        params.photoURL ||
        `https://api.dicebear.com/7.x/initials/svg?seed=${encodeURIComponent(params.displayName || 'User')}`,
      username: cleanHandle,
      bio: 'SocialOne member verified via mobile OTP 📱✨',
      category: 'General',
      role: 'user',
      followersCount: 150,
      followingCount: 10,
      followingIds: ['intekhab-alam-founder'],
      savedPostIds: [],
      walletBalance: 25.0,
      totalGiftsEarned: 25.0,
      coinsBalance: 500,
      privacySettings: DEFAULT_USER_PRIVACY,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    const dummyUser = {
      uid,
      displayName: newProfile.displayName,
      email: newProfile.email,
      photoURL: newProfile.photoURL,
    } as User;

    setCurrentUser(dummyUser);
    setUserProfile(newProfile);
    localStorage.setItem('socialone_session_type', 'phone_otp');
    localStorage.setItem('socialone_phone_profile', JSON.stringify(newProfile));

    try {
      await setDoc(doc(db, 'users', uid), newProfile);
    } catch {}

    return true;
  };

  const withdrawCreatorEarnings = async (params: {
    method: 'jazzcash' | 'easypaisa' | 'bank';
    accountTitle: string;
    accountNumber: string;
    amountUsd: number;
    cnic?: string;
  }) => {
    const currentBalance = userProfile?.walletBalance || 0;
    if (currentBalance < params.amountUsd) {
      throw new Error(`Insufficient wallet balance. You have $${currentBalance.toFixed(2)} USD.`);
    }

    const pkrRate = 280;
    const amountPkr = Math.round(params.amountUsd * pkrRate);
    const prefix = params.method === 'jazzcash' ? 'JC-CR' : 'EP-CR';
    const trxId = `${prefix}-${Math.floor(100000000 + Math.random() * 900000000)}`;

    const newBalance = Number((currentBalance - params.amountUsd).toFixed(2));
    const updated = {
      ...userProfile!,
      walletBalance: newBalance,
    };
    setUserProfile(updated);

    if (currentUser) {
      try {
        const userDocRef = doc(db, 'users', currentUser.uid);
        await updateDoc(userDocRef, {
          walletBalance: newBalance,
          updatedAt: new Date().toISOString(),
        });
      } catch {}
    }

    const transaction = {
      id: `payout_${Date.now()}`,
      method: params.method,
      accountTitle: params.accountTitle,
      accountNumber: params.accountNumber,
      amountUsd: params.amountUsd,
      amountPkr,
      exchangeRate: pkrRate,
      transactionId: trxId,
      status: 'completed',
      timestamp: new Date().toISOString(),
      note: `Live Creator Gift Earnings Cashout ("Petrol Disbursal") via ${
        params.method === 'jazzcash' ? 'JazzCash' : 'EasyPaisa'
      }`,
    };

    return { success: true, transaction };
  };

  const updateAdminPicture = async (newPhotoUrl: string) => {
    localStorage.setItem('socialone_founder_photo', newPhotoUrl);
    if (currentUser) {
      setCurrentUser((prev) => (prev ? ({ ...prev, photoURL: newPhotoUrl } as User) : null));
    }
    if (userProfile) {
      setUserProfile((prev) => (prev ? { ...prev, photoURL: newPhotoUrl } : null));
    }
    if (currentUser?.uid) {
      try {
        const userRef = doc(db, 'users', currentUser.uid);
        await updateDoc(userRef, { photoURL: newPhotoUrl, updatedAt: new Date().toISOString() });
      } catch {}
    }
  };

  const isAdmin = userProfile?.role === 'admin';

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        userProfile,
        loading,
        isAdmin,
        darkMode,
        toggleDarkMode,
        loginWithGoogle,
        logout,
        updateProfileDetails,
        updatePrivacySettings,
        loginWithPhoneOTP,
        toggleFollowUser,
        toggleSavePost,
        gainFollowers,
        addEarningsToWallet,
        loginAsFounder,
        loginAsDemoUser,
        addCoins,
        deductCoins,
        createTikTokId,
        withdrawCreatorEarnings,
        loginWithAdminCredentials,
        updateAdminPicture,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
