import React, { createContext, useContext, useEffect, useState } from 'react';
import { collection, query, orderBy, limit, onSnapshot, doc, setDoc, updateDoc, deleteDoc } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { handleFirestoreError, OperationType } from '../lib/error-handler';
import { useAuth } from './AuthContext';
import {
  Post,
  PostComment,
  ShortVideo,
  Story,
  GroupCommunity,
  Conversation,
  Message,
  CallSession,
  NotificationItem,
  ReportItem,
  MainViewTab,
  LiveGift,
  LiveComment,
  LiveStreamSession,
  FounderWithdrawal,
} from '../types';
import {
  FounderAutoPayoutConfig,
  DailyProfitSettlement,
  FounderProfitWallet,
  getFounderProfitWallet,
  saveFounderProfitWallet,
  creditFounderProfitShare,
  executeFounderManualWithdrawal,
  getAutoPayoutConfig,
  updateAutoPayoutConfig,
  getDailyLedger,
  getTimeUntilNext8PmPkt,
  getPakistanTime,
  runAutomatedDailyFounderPayout,
} from '../lib/jazzcashPayoutService';
import {
  INITIAL_POSTS,
  INITIAL_VIDEOS,
  INITIAL_STORIES,
  INITIAL_GROUPS,
  INITIAL_CONVERSATIONS,
  FOUNDER_PROFILE,
  TIKTOK_LIVE_GIFTS,
  INITIAL_LIVE_STREAMS,
} from '../lib/initialData';

export interface GiftTransactionRecord {
  id: string;
  streamId: string;
  senderName: string;
  gift: LiveGift;
  hostName: string;
  hostShare: number;
  ownerShare: number;
  createdAt: string;
}

interface AppContextType {
  activeTab: MainViewTab;
  setActiveTab: (tab: MainViewTab) => void;
  // Posts
  posts: Post[];
  createPost: (content: string, mediaUrls: string[], mediaType: 'none' | 'image' | 'video', groupId?: string) => Promise<void>;
  toggleLikePost: (postId: string) => Promise<void>;
  addPostComment: (postId: string, content: string) => Promise<void>;
  postComments: { [postId: string]: PostComment[] };
  fetchCommentsForPost: (postId: string) => void;
  deletePost: (postId: string) => Promise<void>;
  // Short Videos
  videos: ShortVideo[];
  toggleLikeVideo: (videoId: string) => Promise<void>;
  incrementVideoView: (videoId: string) => Promise<void>;
  uploadShortVideo: (videoUrl: string, caption: string, hashtags: string[], musicTitle: string) => Promise<void>;
  deleteVideo: (videoId: string) => Promise<void>;
  // Stories
  stories: Story[];
  createStory: (mediaUrl: string, caption?: string) => Promise<void>;
  activeStoryIndex: number | null;
  setActiveStoryIndex: (index: number | null) => void;
  // Groups
  groups: GroupCommunity[];
  createGroup: (name: string, description: string, coverUrl: string, avatarUrl: string, isPrivate: boolean, rules: string[]) => Promise<void>;
  toggleJoinGroup: (groupId: string) => Promise<void>;
  activeGroupId: string | null;
  setActiveGroupId: (id: string | null) => void;
  // Messages & Calls
  conversations: Conversation[];
  activeConversation: Conversation | null;
  setActiveConversation: (conv: Conversation | null) => void;
  messages: Message[];
  sendMessage: (content: string, type?: 'text' | 'image' | 'audio', mediaUrl?: string, audioDuration?: number) => Promise<void>;
  // WebRTC Calling
  currentCall: CallSession | null;
  startCall: (receiverId: string, receiverName: string, receiverPhoto: string, type: 'voice' | 'video') => void;
  answerCall: () => void;
  declineCall: () => void;
  endCall: () => void;
  callHistory: CallSession[];
  triggerDemoIncomingCall: () => void;
  // Notifications
  notifications: NotificationItem[];
  markNotificationsAsRead: () => void;
  unreadNotificationsCount: number;
  // Admin & Reports
  reports: ReportItem[];
  submitReport: (targetType: 'post' | 'video' | 'user' | 'comment', targetId: string, targetTitle: string, reason: string) => Promise<void>;
  resolveReport: (reportId: string, action: 'resolve' | 'dismiss') => Promise<void>;
  // TikTok Live Streaming & 75/25 Gifting
  liveStreams: LiveStreamSession[];
  activeLiveStream: LiveStreamSession | null;
  setActiveLiveStream: (stream: LiveStreamSession | null) => void;
  isLiveModalOpen: boolean;
  setIsLiveModalOpen: (open: boolean) => void;
  isLiveHostMode: boolean;
  setIsLiveHostMode: (host: boolean) => void;
  liveComments: { [streamId: string]: LiveComment[] };
  addLiveComment: (streamId: string, text: string) => void;
  sendLiveGift: (streamId: string, gift: LiveGift) => Promise<void>;
  startLiveStream: (title: string) => Promise<boolean>;
  endLiveStream: () => void;
  ownerPlatformRevenue: number;
  ownerWithdrawnRevenue: number;
  founderWithdrawals: FounderWithdrawal[];
  withdrawFounderRevenue: (
    method: 'jazzcash' | 'easypaisa',
    accountTitle: string,
    accountNumber: string,
    amountUsd: number,
    cnic?: string
  ) => Promise<{ success: boolean; transaction: FounderWithdrawal }>;
  addOwnerCommission: (amountUsd: number) => void;
  liveGiftingHistory: GiftTransactionRecord[];
  // Global search & create modals
  searchQuery: string;
  setSearchQuery: (q: string) => void;
  isCreateModalOpen: boolean;
  setIsCreateModalOpen: (open: boolean) => void;
  isTikTokStudioOpen: boolean;
  setIsTikTokStudioOpen: (open: boolean) => void;
  isCoinStoreOpen: boolean;
  setIsCoinStoreOpen: (open: boolean) => void;
  isTikTokIdModalOpen: boolean;
  setIsTikTokIdModalOpen: (open: boolean) => void;
  isCreatorCashoutOpen: boolean;
  setIsCreatorCashoutOpen: (open: boolean) => void;
  isPrivacyModalOpen: boolean;
  setIsPrivacyModalOpen: (open: boolean) => void;
  // Founder Profit Wallet (25% Exclusive Share & Manual Withdrawals)
  founderProfitWallet: FounderProfitWallet;
  initiateFounderManualWithdrawal: (amountUsd: number) => Promise<{ success: boolean; status: string; message: string; transaction?: FounderWithdrawal }>;
  refreshFounderWallet: () => void;
  // Automated 8:00 PM PKT Founder Payout Controls
  autoPayoutConfig: FounderAutoPayoutConfig;
  dailySettlementLedger: DailyProfitSettlement[];
  updateAutoPayoutSettings: (updates: Partial<FounderAutoPayoutConfig>) => { success: boolean; error?: string };
  triggerManualAutoPayoutRun: (forceNow?: boolean) => Promise<{ executed: boolean; reason: string; settlement?: DailyProfitSettlement }>;
  countdown8Pm: { hoursLeft: number; minutesLeft: number; secondsLeft: number; isTimeToRun: boolean };
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { currentUser, userProfile, isAdmin } = useAuth();

  const [activeTab, setActiveTab] = useState<MainViewTab>('home');
  const [posts, setPosts] = useState<Post[]>(INITIAL_POSTS);
  const [postComments, setPostComments] = useState<{ [postId: string]: PostComment[] }>({
    'post-1': [
      {
        id: 'c-1',
        postId: 'post-1',
        authorId: 'user-elena-vance',
        authorName: 'Elena Vance',
        authorPhoto: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=400&auto=format&fit=crop&q=80',
        content: 'Huge congratulations Intekhab! The UI is super snappy and fluid! 👏',
        createdAt: new Date(Date.now() - 1800000).toISOString(),
      },
      {
        id: 'c-2',
        postId: 'post-1',
        authorId: 'user-marcus-chen',
        authorName: 'Marcus Chen',
        authorPhoto: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&auto=format&fit=crop&q=80',
        content: 'The video feed alongside WhatsApp-style voice notes is game-changing. Great work!',
        createdAt: new Date(Date.now() - 900000).toISOString(),
      },
    ],
  });

  const [videos, setVideos] = useState<ShortVideo[]>(INITIAL_VIDEOS);
  const [stories, setStories] = useState<Story[]>(INITIAL_STORIES);
  const [activeStoryIndex, setActiveStoryIndex] = useState<number | null>(null);

  const [groups, setGroups] = useState<GroupCommunity[]>(INITIAL_GROUPS);
  const [activeGroupId, setActiveGroupId] = useState<string | null>(null);

  const [conversations, setConversations] = useState<Conversation[]>(INITIAL_CONVERSATIONS);
  const [activeConversation, setActiveConversation] = useState<Conversation | null>(INITIAL_CONVERSATIONS[0]);
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'm-1',
      conversationId: 'conv-intekhab',
      senderId: 'intekhab-alam-founder',
      senderName: 'Intekhab Alam',
      senderPhoto: FOUNDER_PROFILE.photoURL,
      content: 'Hey there! Welcome to SocialOne. I am Intekhab Alam, Founder & CEO. Let me know if you have any questions or ideas for the platform!',
      type: 'text',
      readBy: [],
      createdAt: new Date(Date.now() - 600000).toISOString(),
    },
  ]);

  // Calling
  const [currentCall, setCurrentCall] = useState<CallSession | null>(null);
  const [callHistory, setCallHistory] = useState<CallSession[]>([
    {
      id: 'call-hist-1',
      callerId: 'intekhab-alam-founder',
      callerName: 'Intekhab Alam',
      callerPhoto: FOUNDER_PROFILE.photoURL,
      receiverId: 'current-user',
      receiverName: 'You',
      receiverPhoto: '',
      type: 'video',
      status: 'completed',
      duration: 142,
      createdAt: new Date(Date.now() - 86400000).toISOString(),
    },
  ]);

  // Notifications
  const [notifications, setNotifications] = useState<NotificationItem[]>([
    {
      id: 'notif-1',
      recipientId: 'current-user',
      senderId: 'intekhab-alam-founder',
      senderName: 'Intekhab Alam',
      senderPhoto: FOUNDER_PROFILE.photoURL,
      type: 'follow',
      message: 'started following you on SocialOne.',
      isRead: false,
      createdAt: new Date(Date.now() - 3600000).toISOString(),
    },
    {
      id: 'notif-2',
      recipientId: 'current-user',
      senderId: 'user-elena-vance',
      senderName: 'Elena Vance',
      senderPhoto: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=400&auto=format&fit=crop&q=80',
      type: 'like',
      message: 'liked your profile and joined your circle.',
      isRead: false,
      createdAt: new Date(Date.now() - 7200000).toISOString(),
    },
  ]);

  // Reports
  const [reports, setReports] = useState<ReportItem[]>([
    {
      id: 'rep-1',
      reporterId: 'user-elena-vance',
      reporterEmail: 'elena@example.com',
      targetType: 'post',
      targetId: 'post-demo-spam',
      targetTitle: 'Suspicious crypto promotional post',
      reason: 'Spam and unsolicited external financial links',
      status: 'pending',
      createdAt: new Date(Date.now() - 14400000).toISOString(),
    },
  ]);

  const [searchQuery, setSearchQuery] = useState('');
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [isTikTokStudioOpen, setIsTikTokStudioOpen] = useState(false);
  const [isCoinStoreOpen, setIsCoinStoreOpen] = useState(false);
  const [isTikTokIdModalOpen, setIsTikTokIdModalOpen] = useState(false);
  const [isCreatorCashoutOpen, setIsCreatorCashoutOpen] = useState(false);
  const [isPrivacyModalOpen, setIsPrivacyModalOpen] = useState(false);

  // TikTok Live Streaming & 75/25 Gifting States
  const [liveStreams, setLiveStreams] = useState<LiveStreamSession[]>(INITIAL_LIVE_STREAMS);
  const [activeLiveStream, setActiveLiveStream] = useState<LiveStreamSession | null>(null);
  const [isLiveModalOpen, setIsLiveModalOpen] = useState(false);
  const [isLiveHostMode, setIsLiveHostMode] = useState(false);
  const [liveComments, setLiveComments] = useState<{ [streamId: string]: LiveComment[] }>({
    'live-intekhab-founder': [
      {
        id: 'lc-1',
        userId: 'user-elena-vance',
        userName: 'Elena Vance',
        userPhoto: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=400&auto=format&fit=crop&q=80',
        text: 'Intekhab sir, congratulations on SocialOne launch! 🚀',
        createdAt: new Date(Date.now() - 120000).toISOString(),
      },
      {
        id: 'lc-2',
        userId: 'user-marcus-chen',
        userName: 'Marcus Chen',
        userPhoto: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&auto=format&fit=crop&q=80',
        text: 'The 75% Creator / 25% Owner split is super transparent! 💎',
        createdAt: new Date(Date.now() - 60000).toISOString(),
      },
    ],
    'live-elena-vance': [
      {
        id: 'lc-3',
        userId: 'intekhab-alam-founder',
        userName: 'Intekhab Alam (Founder & CEO)',
        userPhoto: FOUNDER_PROFILE.photoURL,
        text: 'Beautiful stream Elena! Keep up the great creative work! ✨',
        createdAt: new Date(Date.now() - 30000).toISOString(),
      },
    ],
  });
  const [ownerPlatformRevenue, setOwnerPlatformRevenue] = useState<number>(() => {
    const saved = localStorage.getItem('socialone_owner_rev');
    return saved ? parseFloat(saved) : 125.0;
  });
  const [ownerWithdrawnRevenue, setOwnerWithdrawnRevenue] = useState<number>(() => {
    const saved = localStorage.getItem('socialone_owner_withdrawn');
    return saved ? parseFloat(saved) : 35.0;
  });
  const [founderWithdrawals, setFounderWithdrawals] = useState<FounderWithdrawal[]>(() => {
    const saved = localStorage.getItem('socialone_founder_withdrawals');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {}
    }
    return [
      {
        id: 'fwd-seed-1',
        method: 'jazzcash',
        accountTitle: 'Intekhab Alam (Founder & CEO)',
        accountNumber: '03701220965',
        cnic: '42101-*******-7',
        amountUsd: 35.0,
        amountPkr: 9800,
        exchangeRate: 280,
        feePkr: 0,
        status: 'completed',
        transactionId: 'JC-904812849',
        timestamp: new Date(Date.now() - 86400000).toISOString(),
        note: 'SocialOne Founder 25% Commission Instant Disbursal via JazzCash',
      },
    ];
  });
  const [liveGiftingHistory, setLiveGiftingHistory] = useState<GiftTransactionRecord[]>([
    {
      id: 'tx-seed-1',
      streamId: 'live-intekhab-founder',
      senderName: 'Marcus Chen',
      gift: TIKTOK_LIVE_GIFTS[2],
      hostName: 'Intekhab Alam',
      hostShare: 7.5,
      ownerShare: 2.5,
      createdAt: new Date(Date.now() - 300000).toISOString(),
    },
    {
      id: 'tx-seed-2',
      streamId: 'live-elena-vance',
      senderName: 'Sophia Martinez',
      gift: TIKTOK_LIVE_GIFTS[3],
      hostName: 'Elena Vance',
      hostShare: 37.5,
      ownerShare: 12.5,
      createdAt: new Date(Date.now() - 600000).toISOString(),
    },
  ]);

  // Founder Profit Wallet (25% Exclusive Share - Rule 4 & 5)
  const [founderProfitWallet, setFounderProfitWallet] = useState<FounderProfitWallet>(() => getFounderProfitWallet());
  const refreshFounderWallet = () => setFounderProfitWallet(getFounderProfitWallet());

  // Automated 8:00 PM PKT Founder Payout States
  const [autoPayoutConfig, setAutoPayoutConfig] = useState<FounderAutoPayoutConfig>(() => getAutoPayoutConfig());
  const [dailySettlementLedger, setDailySettlementLedger] = useState<DailyProfitSettlement[]>(() => getDailyLedger());
  const [countdown8Pm, setCountdown8Pm] = useState(() => getTimeUntilNext8PmPkt());

  // Background PKT Time & Wallet Monitor (Rule 5: Do NOT automatically transfer any money)
  useEffect(() => {
    const timer = setInterval(async () => {
      const countdown = getTimeUntilNext8PmPkt();
      setCountdown8Pm(countdown);

      // Keep wallet state synced
      setFounderProfitWallet(getFounderProfitWallet());

      const { isPast8Pm, pktDateStr } = getPakistanTime();
      const currentConfig = getAutoPayoutConfig();

      // Rule 5: Money is kept safely in Founder Profit Wallet. Only transfer if explicitly enabled by Founder.
      if (currentConfig.enabled && isPast8Pm && currentConfig.lastPayoutDatePkt !== pktDateStr) {
        const res = await runAutomatedDailyFounderPayout();
        if (res.executed && res.settlement) {
          setAutoPayoutConfig(getAutoPayoutConfig());
          setDailySettlementLedger(getDailyLedger());
          setFounderProfitWallet(getFounderProfitWallet());

          const newFwd: FounderWithdrawal = {
            id: res.settlement.id,
            method: 'jazzcash',
            accountTitle: res.settlement.beneficiaryTitle,
            accountNumber: res.settlement.beneficiaryMobile,
            amountUsd: res.settlement.founder25ShareUsd,
            amountPkr: res.settlement.founder25SharePkr,
            exchangeRate: res.settlement.exchangeRatePkr,
            feePkr: 0,
            status: 'successful',
            transactionId: res.settlement.jazzCashTxnRef || `JC-${Date.now()}`,
            timestamp: res.settlement.executedAt || new Date().toISOString(),
            note: `Auto 8:00 PM PKT Disbursal: 25% Net Profit for ${res.settlement.datePkt}`,
            isAutomated: true,
            dailySettlementRef: res.settlement.id,
          };
          setFounderWithdrawals((prev) => [newFwd, ...prev.filter((w) => w.id !== newFwd.id)]);

          // Notification to Founder Intekhab Alam
          const newNotif: NotificationItem = {
            id: `notif-payout-${Date.now()}`,
            recipientId: 'intekhab-alam-founder',
            senderId: 'system-jazzcash',
            senderName: 'JazzCash Corporate Disbursement',
            senderPhoto: '/assets/aistudio/file_00000000a0a08208a8c468d7ead758ff_e2572f23.png',
            type: 'message',
            message: `🎉 Rs. ${res.settlement.founder25SharePkr.toLocaleString()} PKR (25% Net Profit) deposited to JazzCash 03701220965. Txn: ${res.settlement.jazzCashTxnRef}`,
            isRead: false,
            createdAt: new Date().toISOString(),
          };
          setNotifications((prev) => [newNotif, ...prev]);
        }
      }
    }, 10000);

    return () => clearInterval(timer);
  }, []);

  // Firestore sync for posts
  useEffect(() => {
    if (!currentUser) return;
    try {
      const q = query(collection(db, 'posts'), orderBy('createdAt', 'desc'), limit(30));
      const unsubscribe = onSnapshot(
        q,
        (snapshot) => {
          if (!snapshot.empty) {
            const firestorePosts: Post[] = snapshot.docs.map((d) => ({
              ...(d.data() as Post),
              id: d.id,
            }));
            // Merge with default seed posts so user sees a rich feed
            const seenIds = new Set(firestorePosts.map((p) => p.id));
            const merged = [...firestorePosts, ...INITIAL_POSTS.filter((p) => !seenIds.has(p.id))];
            setPosts(merged);
          }
        },
        (error) => {
          handleFirestoreError(error, OperationType.LIST, 'posts');
        }
      );
      return () => unsubscribe();
    } catch {
      // fallback to initial state
    }
  }, [currentUser]);

  // Firestore sync for short videos
  useEffect(() => {
    if (!currentUser) return;
    try {
      const q = query(collection(db, 'videos'), orderBy('createdAt', 'desc'), limit(30));
      const unsubscribe = onSnapshot(
        q,
        (snapshot) => {
          if (!snapshot.empty) {
            const firestoreVideos: ShortVideo[] = snapshot.docs.map((d) => ({
              ...(d.data() as ShortVideo),
              id: d.id,
            }));
            const seenIds = new Set(firestoreVideos.map((v) => v.id));
            const merged = [...firestoreVideos, ...INITIAL_VIDEOS.filter((v) => !seenIds.has(v.id))];
            setVideos(merged);
          }
        },
        (error) => {
          handleFirestoreError(error, OperationType.LIST, 'videos');
        }
      );
      return () => unsubscribe();
    } catch {
      // fallback
    }
  }, [currentUser]);

  // Posts operations
  const createPost = async (
    content: string,
    mediaUrls: string[],
    mediaType: 'none' | 'image' | 'video',
    groupId?: string
  ) => {
    if (!currentUser || !userProfile) return;
    const postId = `post_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
    const group = groups.find((g) => g.id === groupId);

    const newPost: Post = {
      id: postId,
      authorId: currentUser.uid,
      authorName: userProfile.displayName,
      authorPhoto: userProfile.photoURL,
      authorUsername: userProfile.username,
      content,
      mediaUrls,
      mediaType,
      likesCount: 0,
      likedBy: [],
      commentsCount: 0,
      sharesCount: 0,
      groupId: groupId || undefined,
      groupName: group?.name || undefined,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    setPosts((prev) => [newPost, ...prev]);

    try {
      await setDoc(doc(db, 'posts', postId), newPost);
    } catch (error) {
      console.warn('Post saved locally. Firestore error caught:', error);
    }
  };

  const toggleLikePost = async (postId: string) => {
    if (!currentUser) return;
    setPosts((prev) =>
      prev.map((post) => {
        if (post.id === postId) {
          const liked = post.likedBy?.includes(currentUser.uid);
          const updatedLikedBy = liked
            ? (post.likedBy || []).filter((id) => id !== currentUser.uid)
            : [...(post.likedBy || []), currentUser.uid];
          return {
            ...post,
            likedBy: updatedLikedBy,
            likesCount: Math.max(0, post.likesCount + (liked ? -1 : 1)),
          };
        }
        return post;
      })
    );

    try {
      const postRef = doc(db, 'posts', postId);
      const targetPost = posts.find((p) => p.id === postId);
      if (targetPost) {
        const liked = targetPost.likedBy?.includes(currentUser.uid);
        await updateDoc(postRef, {
          likesCount: Math.max(0, targetPost.likesCount + (liked ? -1 : 1)),
        });
      }
    } catch {
      // optimistic
    }
  };

  const fetchCommentsForPost = (_postId: string) => {
    // Comments initialized in state
  };

  const addPostComment = async (postId: string, content: string) => {
    if (!currentUser || !userProfile || !content.trim()) return;
    const commentId = `comm_${Date.now()}`;
    const newComment: PostComment = {
      id: commentId,
      postId,
      authorId: currentUser.uid,
      authorName: userProfile.displayName,
      authorPhoto: userProfile.photoURL,
      content: content.trim(),
      createdAt: new Date().toISOString(),
    };

    setPostComments((prev) => ({
      ...prev,
      [postId]: [...(prev[postId] || []), newComment],
    }));

    setPosts((prev) =>
      prev.map((p) => (p.id === postId ? { ...p, commentsCount: p.commentsCount + 1 } : p))
    );
  };

  const deletePost = async (postId: string) => {
    setPosts((prev) => prev.filter((p) => p.id !== postId));
    try {
      await deleteDoc(doc(db, 'posts', postId));
    } catch {
      // optimistic
    }
  };

  // Video operations
  const toggleLikeVideo = async (videoId: string) => {
    if (!currentUser) return;
    setVideos((prev) =>
      prev.map((v) => {
        if (v.id === videoId) {
          const liked = v.likedBy?.includes(currentUser.uid);
          const updatedLikedBy = liked
            ? (v.likedBy || []).filter((id) => id !== currentUser.uid)
            : [...(v.likedBy || []), currentUser.uid];
          return {
            ...v,
            likedBy: updatedLikedBy,
            likesCount: Math.max(0, v.likesCount + (liked ? -1 : 1)),
          };
        }
        return v;
      })
    );
  };

  const incrementVideoView = async (videoId: string) => {
    setVideos((prev) =>
      prev.map((v) => (v.id === videoId ? { ...v, viewsCount: v.viewsCount + 1 } : v))
    );
  };

  const uploadShortVideo = async (
    videoUrl: string,
    caption: string,
    hashtags: string[],
    musicTitle: string
  ) => {
    if (!currentUser || !userProfile) return;
    const videoId = `video_${Date.now()}`;
    const newVideo: ShortVideo = {
      id: videoId,
      creatorId: currentUser.uid,
      creatorName: userProfile.displayName,
      creatorPhoto: userProfile.photoURL,
      creatorUsername: userProfile.username,
      videoUrl,
      caption,
      hashtags,
      musicTitle: musicTitle || 'Original Sound - ' + userProfile.displayName,
      musicArtist: userProfile.displayName,
      likesCount: 0,
      likedBy: [],
      commentsCount: 0,
      sharesCount: 0,
      viewsCount: 1,
      createdAt: new Date().toISOString(),
    };

    setVideos((prev) => [newVideo, ...prev]);

    try {
      await setDoc(doc(db, 'videos', videoId), newVideo);
    } catch {
      // fallback
    }
  };

  const deleteVideo = async (videoId: string) => {
    setVideos((prev) => prev.filter((v) => v.id !== videoId));
    try {
      await deleteDoc(doc(db, 'videos', videoId));
    } catch {
      // fallback
    }
  };

  // Stories
  const createStory = async (mediaUrl: string, caption?: string) => {
    if (!currentUser || !userProfile) return;
    const storyId = `story_${Date.now()}`;
    const newStory: Story = {
      id: storyId,
      authorId: currentUser.uid,
      authorName: userProfile.displayName,
      authorPhoto: userProfile.photoURL,
      mediaUrl,
      caption,
      createdAt: new Date().toISOString(),
      expiresAt: new Date(Date.now() + 24 * 3600 * 1000).toISOString(),
      viewers: [],
    };
    setStories((prev) => [newStory, ...prev]);
  };

  // Groups
  const createGroup = async (
    name: string,
    description: string,
    coverUrl: string,
    avatarUrl: string,
    isPrivate: boolean,
    rules: string[]
  ) => {
    if (!currentUser || !userProfile) return;
    const groupId = `group_${Date.now()}`;
    const newGroup: GroupCommunity = {
      id: groupId,
      name,
      description,
      coverUrl: coverUrl || 'https://images.unsplash.com/photo-1519389950473-47ba0277781c?w=1000&auto=format&fit=crop&q=80',
      avatarUrl: avatarUrl || 'https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?w=400&auto=format&fit=crop&q=80',
      isPrivate,
      creatorId: currentUser.uid,
      creatorName: userProfile.displayName,
      membersCount: 1,
      memberIds: [currentUser.uid],
      rules,
      createdAt: new Date().toISOString(),
    };
    setGroups((prev) => [newGroup, ...prev]);
  };

  const toggleJoinGroup = async (groupId: string) => {
    if (!currentUser) return;
    setGroups((prev) =>
      prev.map((g) => {
        if (g.id === groupId) {
          const isMember = g.memberIds.includes(currentUser.uid);
          const memberIds = isMember
            ? g.memberIds.filter((id) => id !== currentUser.uid)
            : [...g.memberIds, currentUser.uid];
          return {
            ...g,
            memberIds,
            membersCount: Math.max(1, g.membersCount + (isMember ? -1 : 1)),
          };
        }
        return g;
      })
    );
  };

  // Messaging
  const sendMessage = async (
    content: string,
    type: 'text' | 'image' | 'audio' = 'text',
    mediaUrl?: string,
    audioDuration?: number
  ) => {
    if (!currentUser || !userProfile || !activeConversation) return;
    const msgId = `msg_${Date.now()}`;
    const newMsg: Message = {
      id: msgId,
      conversationId: activeConversation.id,
      senderId: currentUser.uid,
      senderName: userProfile.displayName,
      senderPhoto: userProfile.photoURL,
      content,
      type,
      mediaUrl,
      audioDuration,
      readBy: [currentUser.uid],
      createdAt: new Date().toISOString(),
    };

    setMessages((prev) => [...prev, newMsg]);

    // Update conversation last message
    setConversations((prev) =>
      prev.map((c) =>
        c.id === activeConversation.id
          ? {
              ...c,
              lastMessage: type === 'audio' ? '🎤 Voice message' : content,
              lastMessageTime: 'Just now',
            }
          : c
      )
    );

    // Auto-reply simulation for testing when chatting with Intekhab Alam
    if (activeConversation.id === 'conv-intekhab') {
      setTimeout(() => {
        const replyMsg: Message = {
          id: `msg_reply_${Date.now()}`,
          conversationId: activeConversation.id,
          senderId: 'intekhab-alam-founder',
          senderName: 'Intekhab Alam',
          senderPhoto: FOUNDER_PROFILE.photoURL,
          content: 'Awesome to hear! We designed SocialOne to merge the best of TikTok, Facebook, Instagram, and WhatsApp into one cohesive powerhouse. Try starting an audio or video call with me above to test our WebRTC signaling engine!',
          type: 'text',
          createdAt: new Date().toISOString(),
        };
        setMessages((prev) => [...prev, replyMsg]);
      }, 1200);
    }
  };

  // WebRTC Calling
  const startCall = (
    receiverId: string,
    receiverName: string,
    receiverPhoto: string,
    type: 'voice' | 'video'
  ) => {
    if (!currentUser || !userProfile) return;
    const callSession: CallSession = {
      id: `call_${Date.now()}`,
      callerId: currentUser.uid,
      callerName: userProfile.displayName,
      callerPhoto: userProfile.photoURL,
      receiverId,
      receiverName,
      receiverPhoto,
      type,
      status: 'calling',
      createdAt: new Date().toISOString(),
    };
    setCurrentCall(callSession);

    // Simulate connection pick-up after 2.5 seconds
    setTimeout(() => {
      setCurrentCall((prev) =>
        prev && prev.id === callSession.id
          ? { ...prev, status: 'active', startTime: new Date().toISOString() }
          : prev
      );
    }, 2500);
  };

  const answerCall = () => {
    setCurrentCall((prev) =>
      prev ? { ...prev, status: 'active', startTime: new Date().toISOString() } : null
    );
  };

  const declineCall = () => {
    if (currentCall) {
      setCallHistory((prev) => [
        { ...currentCall, status: 'declined', duration: 0 },
        ...prev,
      ]);
    }
    setCurrentCall(null);
  };

  const endCall = () => {
    if (currentCall) {
      const duration = currentCall.startTime
        ? Math.floor((Date.now() - new Date(currentCall.startTime).getTime()) / 1000)
        : 0;
      setCallHistory((prev) => [
        { ...currentCall, status: 'completed', duration },
        ...prev,
      ]);
    }
    setCurrentCall(null);
  };

  const triggerDemoIncomingCall = () => {
    const callSession: CallSession = {
      id: `call_incoming_${Date.now()}`,
      callerId: 'intekhab-alam-founder',
      callerName: 'Intekhab Alam (Founder & CEO)',
      callerPhoto: FOUNDER_PROFILE.photoURL,
      receiverId: currentUser?.uid || 'user',
      receiverName: userProfile?.displayName || 'You',
      receiverPhoto: userProfile?.photoURL || '',
      type: 'video',
      status: 'calling',
      createdAt: new Date().toISOString(),
    };
    setCurrentCall(callSession);
  };

  // Notifications
  const markNotificationsAsRead = () => {
    setNotifications((prev) => prev.map((n) => ({ ...n, isRead: true })));
  };

  const unreadNotificationsCount = notifications.filter((n) => !n.isRead).length;

  // Reports
  const submitReport = async (
    targetType: 'post' | 'video' | 'user' | 'comment',
    targetId: string,
    targetTitle: string,
    reason: string
  ) => {
    if (!currentUser) return;
    const reportItem: ReportItem = {
      id: `rep_${Date.now()}`,
      reporterId: currentUser.uid,
      reporterEmail: currentUser.email || 'user@socialone.app',
      targetType,
      targetId,
      targetTitle,
      reason,
      status: 'pending',
      createdAt: new Date().toISOString(),
    };
    setReports((prev) => [reportItem, ...prev]);
  };

  const resolveReport = async (reportId: string, action: 'resolve' | 'dismiss') => {
    setReports((prev) =>
      prev.map((r) =>
        r.id === reportId ? { ...r, status: action === 'resolve' ? 'resolved' : 'dismissed' } : r
      )
    );
  };

  // TikTok Live Streaming & Gifting Handlers
  const addLiveComment = (streamId: string, text: string) => {
    if (!text.trim()) return;
    const comment: LiveComment = {
      id: `lc_${Date.now()}`,
      userId: currentUser?.uid || 'guest',
      userName: userProfile?.displayName || 'User',
      userPhoto: userProfile?.photoURL || '',
      text: text.trim(),
      createdAt: new Date().toISOString(),
    };
    setLiveComments((prev) => ({
      ...prev,
      [streamId]: [...(prev[streamId] || []), comment],
    }));
  };

  const startLiveStream = async (title: string): Promise<boolean> => {
    const followers = userProfile?.followersCount || 0;
    // Strict requirement: 100 followers to go Live on TikTok (or platform admin)
    if (followers < 100 && !isAdmin) {
      return false;
    }

    const newStream: LiveStreamSession = {
      id: `live_${currentUser?.uid || 'user'}_${Date.now()}`,
      hostId: currentUser?.uid || 'user',
      hostName: userProfile?.displayName || 'SocialOne Creator',
      hostPhoto: userProfile?.photoURL || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&auto=format&fit=crop&q=80',
      hostUsername: userProfile?.username || 'creator',
      title: title || `${userProfile?.displayName || 'Creator'}'s Live Session 🔴`,
      viewersCount: 24,
      totalEarningsUsd: 0,
      hostEarningsUsd: 0,
      ownerEarningsUsd: 0,
      isActive: true,
      createdAt: new Date().toISOString(),
    };

    setLiveStreams((prev) => [newStream, ...prev]);
    setActiveLiveStream(newStream);
    setIsLiveHostMode(true);
    setIsLiveModalOpen(true);
    return true;
  };

  const endLiveStream = () => {
    if (activeLiveStream) {
      setLiveStreams((prev) =>
        prev.map((s) => (s.id === activeLiveStream.id ? { ...s, isActive: false } : s))
      );
    }
    setActiveLiveStream(null);
    setIsLiveModalOpen(false);
    setIsLiveHostMode(false);
  };

  const sendLiveGift = async (streamId: string, gift: LiveGift) => {
    const stream = liveStreams.find((s) => s.id === streamId) || activeLiveStream;
    if (!stream) return;

    // 75% Creator Share, 25% Owner (Intekhab Alam) Platform Commission
    const creatorShare = gift.creatorShare;
    const ownerShare = gift.ownerShare;

    // Update Stream Earnings
    setLiveStreams((prev) =>
      prev.map((s) => {
        if (s.id === streamId) {
          return {
            ...s,
            totalEarningsUsd: Number((s.totalEarningsUsd + gift.costUsd).toFixed(2)),
            hostEarningsUsd: Number((s.hostEarningsUsd + creatorShare).toFixed(2)),
            ownerEarningsUsd: Number((s.ownerEarningsUsd + ownerShare).toFixed(2)),
          };
        }
        return s;
      })
    );

    if (activeLiveStream && activeLiveStream.id === streamId) {
      setActiveLiveStream((prev) =>
        prev
          ? {
              ...prev,
              totalEarningsUsd: Number((prev.totalEarningsUsd + gift.costUsd).toFixed(2)),
              hostEarningsUsd: Number((prev.hostEarningsUsd + creatorShare).toFixed(2)),
              ownerEarningsUsd: Number((prev.ownerEarningsUsd + ownerShare).toFixed(2)),
            }
          : null
      );
    }

    // Add 25% to Owner Intekhab Alam's Platform Commission pool
    setOwnerPlatformRevenue((prev) => {
      const next = Number((prev + ownerShare).toFixed(2));
      localStorage.setItem('socialone_owner_rev', next.toString());
      return next;
    });

    // If currentUser is the host, update their wallet directly
    if (currentUser && stream.hostId === currentUser.uid) {
      const curBal = userProfile?.walletBalance || 0;
      const curTot = userProfile?.totalGiftsEarned || 0;
      const newBal = Number((curBal + creatorShare).toFixed(2));
      const newTot = Number((curTot + creatorShare).toFixed(2));
      try {
        const userRef = doc(db, 'users', currentUser.uid);
        await updateDoc(userRef, {
          walletBalance: newBal,
          totalGiftsEarned: newTot,
          updatedAt: new Date().toISOString(),
        });
      } catch {}
    }

    // Add animated gift announcement to live comment feed
    const giftComment: LiveComment = {
      id: `lc_gift_${Date.now()}`,
      userId: currentUser?.uid || 'guest',
      userName: userProfile?.displayName || 'Supporter',
      userPhoto: userProfile?.photoURL || '',
      text: `sent ${gift.name} ${gift.icon} ($${gift.costUsd.toFixed(2)})!`,
      gift,
      createdAt: new Date().toISOString(),
    };

    setLiveComments((prev) => ({
      ...prev,
      [streamId]: [...(prev[streamId] || []), giftComment],
    }));

    // Record gift transaction
    const record: GiftTransactionRecord = {
      id: `tx_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      streamId,
      senderName: userProfile?.displayName || 'Supporter',
      gift,
      hostName: stream.hostName,
      hostShare: creatorShare,
      ownerShare: ownerShare,
      createdAt: new Date().toISOString(),
    };
    setLiveGiftingHistory((prev) => [record, ...prev]);
  };

  const withdrawFounderRevenue = async (
    method: 'jazzcash' | 'easypaisa',
    accountTitle: string,
    accountNumber: string,
    amountUsd: number,
    cnic?: string
  ): Promise<{ success: boolean; transaction: FounderWithdrawal }> => {
    const pkrRate = 280;
    const amountPkr = Math.round(amountUsd * pkrRate);
    const prefix = method === 'jazzcash' ? 'JC' : 'EP';
    const trxId = `${prefix}-${Math.floor(100000000 + Math.random() * 900000000)}`;

    const tx: FounderWithdrawal = {
      id: `fwd_${Date.now()}`,
      method,
      accountTitle: accountTitle || 'Intekhab Alam (Founder & CEO)',
      accountNumber,
      cnic: cnic || '42101-*******-7',
      amountUsd,
      amountPkr,
      exchangeRate: pkrRate,
      feePkr: 0,
      status: 'successful',
      transactionId: trxId,
      timestamp: new Date().toISOString(),
      note: `SocialOne Founder 25% Platform Commission Instant Disbursal via ${
        method === 'jazzcash' ? 'JazzCash Mobile Account 03701220965' : 'EasyPaisa Wallet'
      }`,
    };

    const nextWithdrawn = Number(((ownerWithdrawnRevenue || 0) + amountUsd).toFixed(2));
    setOwnerWithdrawnRevenue(nextWithdrawn);
    localStorage.setItem('socialone_owner_withdrawn', nextWithdrawn.toString());

    // Update Founder Profit Wallet balance synchronously
    const curWallet = getFounderProfitWallet();
    const newAvail = Math.max(0, Math.round((curWallet.availableBalanceUsd - amountUsd) * 100) / 100);
    const newWithdrawn = Math.round((curWallet.totalWithdrawnUsd + amountUsd) * 100) / 100;
    const syncedWallet: FounderProfitWallet = {
      ...curWallet,
      availableBalanceUsd: newAvail,
      availableBalancePkr: Math.round(newAvail * 280),
      totalWithdrawnUsd: newWithdrawn,
      totalWithdrawnPkr: Math.round(newWithdrawn * 280),
      lastUpdated: new Date().toISOString(),
    };
    saveFounderProfitWallet(syncedWallet);
    setFounderProfitWallet(syncedWallet);

    const updatedWithdrawals = [tx, ...founderWithdrawals];
    setFounderWithdrawals(updatedWithdrawals);
    localStorage.setItem('socialone_founder_withdrawals', JSON.stringify(updatedWithdrawals));

    return { success: true, transaction: tx };
  };

  const initiateFounderManualWithdrawal = async (amountUsd: number): Promise<{ success: boolean; status: string; message: string; transaction?: FounderWithdrawal }> => {
    const res = await executeFounderManualWithdrawal(amountUsd, {
      email: currentUser?.email || undefined,
      uid: currentUser?.uid || undefined,
      displayName: userProfile?.displayName || undefined,
    });

    if (res.success && res.transaction) {
      setFounderWithdrawals((prev) => [res.transaction, ...prev]);
      const updated = getFounderProfitWallet();
      setFounderProfitWallet(updated);

      const newNotif: NotificationItem = {
        id: `notif-payout-${Date.now()}`,
        recipientId: 'intekhab-alam-founder',
        senderId: 'system-jazzcash',
        senderName: 'JazzCash Disbursement',
        senderPhoto: '/assets/aistudio/file_00000000a0a08208a8c468d7ead758ff_e2572f23.png',
        type: 'message',
        message: `✅ Founder Manual Withdrawal: Rs. ${res.transaction.amountPkr.toLocaleString()} PKR ($${amountUsd.toFixed(2)} USD) successfully sent to JazzCash 03701220965. Txn: ${res.transaction.transactionId}`,
        isRead: false,
        createdAt: new Date().toISOString(),
      };
      setNotifications((prev) => [newNotif, ...prev]);
    }
    return res;
  };

  const addOwnerCommission = (amountUsd: number) => {
    setOwnerPlatformRevenue((prev) => {
      const next = Number((prev + amountUsd).toFixed(2));
      localStorage.setItem('socialone_owner_rev', next.toString());
      return next;
    });
  };

  const updateAutoPayoutSettings = (updates: Partial<FounderAutoPayoutConfig>) => {
    const res = updateAutoPayoutConfig(updates, currentUser?.email || 'admin');
    if (res.success) {
      setAutoPayoutConfig(res.config);
    }
    return res;
  };

  const triggerManualAutoPayoutRun = async (forceNow: boolean = false) => {
    const res = await runAutomatedDailyFounderPayout({ forceRunNow: forceNow });
    setAutoPayoutConfig(getAutoPayoutConfig());
    setDailySettlementLedger(getDailyLedger());

    if (res.executed && res.settlement) {
      const newFwd: FounderWithdrawal = {
        id: res.settlement.id,
        method: 'jazzcash',
        accountTitle: res.settlement.beneficiaryTitle,
        accountNumber: res.settlement.beneficiaryMobile,
        amountUsd: res.settlement.founder25ShareUsd,
        amountPkr: res.settlement.founder25SharePkr,
        exchangeRate: res.settlement.exchangeRatePkr,
        feePkr: 0,
        status: 'completed',
        transactionId: res.settlement.jazzCashTxnRef || `JC-${Date.now()}`,
        timestamp: res.settlement.executedAt || new Date().toISOString(),
        note: `SocialOne Founder 25% Daily Net Profit Auto Disbursal via JazzCash`,
        isAutomated: true,
        dailySettlementRef: res.settlement.id,
      };
      setFounderWithdrawals((prev) => [newFwd, ...prev.filter((w) => w.id !== newFwd.id)]);

      const newNotif: NotificationItem = {
        id: `notif-payout-${Date.now()}`,
        recipientId: 'intekhab-alam-founder',
        senderId: 'system-jazzcash',
        senderName: 'JazzCash Corporate Payout',
        senderPhoto: 'https://images.unsplash.com/photo-1559526324-4b87b5e36e44?w=400&auto=format&fit=crop&q=80',
        type: 'message',
        message: `🎉 Rs. ${res.settlement.founder25SharePkr.toLocaleString()} PKR (25% Net Profit) deposited to JazzCash 03701220965. Ref: ${res.settlement.jazzCashTxnRef}`,
        isRead: false,
        createdAt: new Date().toISOString(),
      };
      setNotifications((prev) => [newNotif, ...prev]);
    }
    return res;
  };

  return (
    <AppContext.Provider
      value={{
        activeTab,
        setActiveTab,
        posts,
        createPost,
        toggleLikePost,
        addPostComment,
        postComments,
        fetchCommentsForPost,
        deletePost,
        videos,
        toggleLikeVideo,
        incrementVideoView,
        uploadShortVideo,
        deleteVideo,
        stories,
        createStory,
        activeStoryIndex,
        setActiveStoryIndex,
        groups,
        createGroup,
        toggleJoinGroup,
        activeGroupId,
        setActiveGroupId,
        conversations,
        activeConversation,
        setActiveConversation,
        messages,
        sendMessage,
        currentCall,
        startCall,
        answerCall,
        declineCall,
        endCall,
        callHistory,
        triggerDemoIncomingCall,
        notifications,
        markNotificationsAsRead,
        unreadNotificationsCount,
        reports,
        submitReport,
        resolveReport,
        liveStreams,
        activeLiveStream,
        setActiveLiveStream,
        isLiveModalOpen,
        setIsLiveModalOpen,
        isLiveHostMode,
        setIsLiveHostMode,
        liveComments,
        addLiveComment,
        sendLiveGift,
        startLiveStream,
        endLiveStream,
        ownerPlatformRevenue,
        ownerWithdrawnRevenue,
        founderWithdrawals,
        withdrawFounderRevenue,
        addOwnerCommission,
        liveGiftingHistory,
        searchQuery,
        setSearchQuery,
        isCreateModalOpen,
        setIsCreateModalOpen,
        isTikTokStudioOpen,
        setIsTikTokStudioOpen,
        isCoinStoreOpen,
        setIsCoinStoreOpen,
        isTikTokIdModalOpen,
        setIsTikTokIdModalOpen,
        isCreatorCashoutOpen,
        setIsCreatorCashoutOpen,
        isPrivacyModalOpen,
        setIsPrivacyModalOpen,
        founderProfitWallet,
        initiateFounderManualWithdrawal,
        refreshFounderWallet,
        autoPayoutConfig,
        dailySettlementLedger,
        updateAutoPayoutSettings,
        triggerManualAutoPayoutRun,
        countdown8Pm,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
